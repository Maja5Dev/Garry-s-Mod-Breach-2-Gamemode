
function BR2_Get914Status()
	local skip_ents = {}
	
	for k,v in pairs(ents.GetAll()) do
		if v:GetPos() == Vector(709.000000, -832.000000, -8131.000000) then
			table.ForceInsert(skip_ents, v)
		end
	end
	
	local pos_tab = {
		{
			st = Vector(711.968750, -823.241089, -8130.947754),
			en = Vector(711.968750, -826.715942, -8130.899902)
		},
		{
			st = Vector(711.968750, -825.751526, -8124.646484),
			en = Vector(711.968750, -828.398987, -8127.150391)
		},
		{
			st = Vector(711.968750, -832.023193, -8121.808105),
			en = Vector(711.968750, -831.989441, -8125.920898)
		},
		{
			st = Vector(711.968750, -838.231140, -8124.668457),
			en = Vector(711.968750, -835.565186, -8127.099121)
		},
		{
			st = Vector(711.968750, -840.952881, -8130.949707),
			en = Vector(711.968750, -837.019043, -8130.874512)
		},
	}
	
	for i,v in ipairs(pos_tab) do
		local tr = util.TraceLine({
			start = v.st,
			endpos = v.en,
			mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE,
			filter = skip_ents
		})
		if tr.Hit == true then
			return i
		end
	end
	return 0
end

function BR2_Get_914_Enter_Entities()
	local pos1 = Vector(737,-678,-8190)
	local pos2 = Vector(804,-541,-8080)
	OrderVectors(pos1, pos2)
	local ents_found = {}
	for k,v in pairs(ents.FindInBox(pos1, pos2)) do
		if v.GetBetterOne or v:IsPlayer() then
			table.ForceInsert(ents_found, v)
		end
	end
	return ents_found
end

function BR2_914_End_Stage()
	timer.Create("BR2_914_NextStage", 11, 1, function()
		br2_914_disabled = false
	end)
end

br2_914_disabled = false
function BR2_Handle914_Start()
	if br2_914_disabled == true then
		return false
	else
		br2_914_disabled = true
		timer.Create("BR2_914_NextStage", 4, 1, function()
			br_914status = BR2_Get914Status()
			for k,v in pairs(BR2_Get_914_Enter_Entities()) do
				v:SetPos(Vector(768.773560, -1062.487549, -8190.468750))
				if v:IsPlayer() then
					v:Kill()
				elseif isfunction(v.GetBetterOne) then
					local better_one = v:GetBetterOne()
					if isstring(better_one) then
						local ent = ents.Create(better_one)
						if IsValid(ent) then
							ent:SetPos(v:GetPos())
							ent:Spawn()
							ent:SetNWBool("isDropped", true)
						end
						if isnumber(ent.BatteryLevel) then
							ent.BatteryLevel = 100
						end
						if ent:GetClass() == "item_radio2" then
							for _,bt in pairs(MAPCONFIG.BUTTONS) do
								if ent.Code == nil and isnumber(bt.code) and bt.code_type == "radio" then
									ent.Code = bt.code
								end
							end
						end
					end
					v:Remove()
				end
			end
			BR2_914_End_Stage()
		end)
		return true
	end
end

function BR_SpawnMapNPC(npc, zone)
	local all_players = {}
	for k,v in pairs(player.GetAll()) do
		if v:Alive() == true and v:IsSpectator() == false then
			table.ForceInsert(all_players, v)
		end
	end

	for k,v in pairs(ents.GetAll()) do
		if string.find(v:GetClass(), "npc_cpt_scp") then
			table.ForceInsert(all_players, v)
		end
	end

	local all_suitable_spawns = {}
	for pos_num,pos in ipairs(zone) do
		local pos_available = true
		local pos_points = 0
		for pl_num,pl in pairs(all_players) do
			local dist = pl:GetPos():Distance(pos)
			local trace = util.TraceLine({
				start = pl:GetPos(),
				endpos = pos,
				mask = MASK_SOLID,
				filter = pl
			})
			if dist < 700 and trace.Hit == false then
				pos_available = false
				break
			else
				pos_points = pos_points + dist
			end
		end
		if pos_available == true then
			table.ForceInsert(all_suitable_spawns, {pos, pos_points})
		end
	end
	local best_spawn = nil
	for k,v in pairs(all_suitable_spawns) do
		if best_spawn == nil or best_spawn[2] > v[2] then
			best_spawn = v
		end
	end

	if best_spawn != nil then
		local npc = ents.Create(npc)
		if IsValid(npc) then
			npc:SetPos(best_spawn[1])
			npc:Spawn()
			npc:Activate()
			return true
		end
	end
	return false
end

function SpawnMapNPCs()
	if true then return end
	local npc_tab = {
		--{"npc_cpt_scp_173", Vector(-183.948669, 1345.252441, -8063.968750)},
		--{"npc_cpt_scp_966", Vector(-650.879883, 4119.376953, -7167.968750)},
		--{"npc_cpt_scp_966", Vector(-474.215820, 4124.738281, -7167.968750)},
		--{"npc_cpt_scp_966", Vector(-752.841125, 4201.270020, -7167.968750)},
		--{"npc_cpt_scp_939_b", Vector(6699.372070, -1848.375977, -11551.968750)},
		--{"npc_cpt_scp_939_c", Vector(6929.901367, -885.706116, -11551.968750)},
		--{"npc_cpt_scp_178specs", Vector(658.442383, 1594.945190, -8145.907227)},

		/*
		{"npc_cpt_scp_106", Vector(-2730.027832, 5804.986328, -7166.968750)},
		{"npc_cpt_scp_457", Vector(-2567.378174, 2985.477783, -7167.968750)},
		{"npc_cpt_scp_575", Vector(1232.431885, 1351.772705, -8191.968750)},
		{"npc_cpt_scp_650", Vector(-952.335449, 2317.005615, -6143.968750)},
		*/
		{"npc_cpt_scp_096", Vector(129.172226, 4132.813477, -7167.968750)},
		{"npc_cpt_scp_939_a", Vector(6592.954590, -893.843567, -11551.968750)},
		{"npc_cpt_scp_012", Vector(-1122.385742, -195.140732, -8447.968750)},
		{"npc_cpt_scp_1025", Vector(969.080566, 1265.391113, -8191.968750)},
		{"npc_cpt_scp_513", Vector(-812.415161, 5603.627441, -7167.968750)},
		{"npc_cpt_scp_714", Vector(1518.547607, 1512.050903, -8156.471680)},
		{"npc_cpt_scp_500", Vector(1527.700562, 881.116943, -8159.968750)},
		{"npc_cpt_scp_500", Vector(-402.059509, 39.302795, -8167.887695)},
	}

	for k,v in pairs(npc_tab) do
		local npc = ents.Create(v[1])
		if IsValid(npc) then
			npc:SetPos(v[2])
			npc:Spawn()
			npc:Activate()
		end
	end
	

	timer.Remove("NPC_SPAWN_106_TIMER")
	timer.Create("NPC_SPAWN_106_TIMER", math.random(70, 280), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_106", MAPCONFIG.SPAWNS_HCZ)
	end)

	timer.Remove("NPC_SPAWN_173_TIMER")
	timer.Create("NPC_SPAWN_173_TIMER", math.random(100, 360), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_173", MAPCONFIG.SPAWNS_LCZ)
	end)

	timer.Remove("NPC_SPAWN_1048_TIMER")
	timer.Create("NPC_SPAWN_1048_TIMER", math.random(200, 360), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_1048", MAPCONFIG.SPAWNS_LCZ)
	end)

	timer.Remove("NPC_SPAWN_457_TIMER")
	timer.Create("NPC_SPAWN_457_TIMER", math.random(40, 200), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_457", MAPCONFIG.SPAWNS_HCZ)
	end)

	timer.Remove("NPC_SPAWN_575_TIMER")
	timer.Create("NPC_SPAWN_575_TIMER", math.random(30, 220), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_575", MAPCONFIG.SPAWNS_ENTRANCEZONE)
	end)

	timer.Remove("NPC_SPAWN_066_TIMER")
	timer.Create("NPC_SPAWN_066_TIMER", math.random(120, 300), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_066", MAPCONFIG.SPAWNS_ENTRANCEZONE)
	end)
end

function Breach_Map_Organise()
	print("organising the map...")
	
	br2_914_disabled = false
	br_914status = 1
	
	/*
	br2_914_fix_ent_1 = ents.Create("prop_physics")
	if IsValid(br2_914_fix_ent_1) then
		br2_914_fix_ent_1:SetPos(Vector(783.786865, -610.382507, -8192.000000))
		br2_914_fix_ent_1:SetModel("models/hunter/plates/plate2x3.mdl")
		br2_914_fix_ent_1:SetMaterial("phoenix_storms/metalset_1-2")
		br2_914_fix_ent_1:Spawn()
		local phys = br2_914_fix_ent_1:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
	end
	
	br2_914_fix_ent_2 = ents.Create("prop_physics")
	if IsValid(br2_914_fix_ent_2) then
		br2_914_fix_ent_2:SetPos(Vector(783.786865, -1060.382568, -8192))
		br2_914_fix_ent_2:SetModel("models/hunter/plates/plate2x3.mdl")
		br2_914_fix_ent_2:SetMaterial("phoenix_storms/metalset_1-2")
		br2_914_fix_ent_2:Spawn()
		local phys = br2_914_fix_ent_2:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
	end
	*/
	
	if SafeBoolConVar("br2_testing_mode") == false then
		SpawnMapNPCs()
	end
	
	local button_ents = {}

	--CORPSES
	if istable(MAPCONFIG.STARTING_CORPSES) and round_system.current_scenario.fake_corpses == true then
		local all_corpses = table.Copy(MAPCONFIG.STARTING_CORPSES)
		local corpse_infos = {}

		for i=1, MAPCONFIG.Starting_Corpses_Number() do
			local random_corpse = table.Random(all_corpses)
			table.ForceInsert(corpse_infos, random_corpse)
			table.RemoveByValue(all_corpses, random_corpse)
		end
		
		for k,v in pairs(corpse_infos) do
			local corpse = table.Random(v)
			local rag = ents.Create("prop_ragdoll")
			if IsValid(rag) then
				rag:SetModel(corpse.model)
				rag:SetPos(corpse.ragdoll_pos)
				rag.IsStartingCorpse = true
				rag:Spawn()
				ApplyCorpseInfo(rag, corpse, true)
				rag.CInfo = corpse
				rag.Info = {}
				rag.Info.CorpseID = rag:GetCreationID()
				rag.Info.Victim = NULL
				rag.Info.VictimNick = "Unknown"
				rag.Info.DamageType = DMG_GENERIC
				rag.Info.Time = CurTime() - math.random(20,1400)
				rag:SetNWInt("DeathTime", rag.Info.Time)
				rag:SetNWString("ExamineDmgInfo", " - Cause of death is unknown")
				rag.Info.Loot = {}
				--local random_item = table.Random({"item_radio", "item_medkit", "item_pills", "item_gasmask", "item_nvg", "keycard_level1", "keycard_level2", "kanade_tfa_crowbar"})
				--table.ForceInsert(rag.Info.Loot, form_basic_item_info(random_item))
				rag.RagdollHealth = 0
				rag.nextReviveMove = 0
				
				if isfunction(corpse.setup) then
					corpse.setup(rag)
					if istable(all_fake_corpses) then
						table.ForceInsert(all_fake_corpses, rag)
						rag.Info.notepad = {}
						rag.Info.notepad.people = {
							{
								br_ci_agent = rag.br_ci_agent,
								br_role = rag.br_role,
								br_showname = rag.br_showname,
								health = HEALTH_ALIVE,
								scp = false
							}
						}
					end
				end
			end
		end
	end
	
	timer.Create("BR2_MAPCONFIG_CORPSEINFO", 4, 1, function()
		for k,v in pairs(ents.FindByClass("prop_ragdoll")) do
			if v.CInfo then
				--ApplyCorpseInfo(v, v.CInfo, true)
				for i=0, (v:GetPhysicsObjectCount() - 1) do
					local bone = v:GetPhysicsObjectNum(i)
					if IsValid(bone) then
						bone:EnableMotion(true)
					end
				end
			end
		end
 	end)

	-- BUTTONS
	if istable(MAPCONFIG.BUTTONS) then
		for k,v in pairs(ents.GetAll()) do
			if v:GetClass() == "func_door" and (v:GetPos() == Vector(-3864.000000, 476.000000, -7840.000000) or v:GetPos() == Vector(-3864.000000, 644.000000, -7840.000000)) then
				v:Use(v, v, USE_ON, 1)
				continue
			end
			for k2,butt in pairs(MAPCONFIG.BUTTONS) do
				if v:GetPos() == butt.pos then
					--print("Found a button with pos (" .. tostring(butt.pos) .. ")  and level " .. butt.level)
					v.br_info = butt
					table.ForceInsert(button_ents, v)
				end
			end
		end
	else
		print("[Breach2] No buttons found...")
		return
	end
	
	-- TERMINALS
	BR2_TERMINALS = table.Copy(MAPCONFIG.BUTTONS_2D.TERMINALS.buttons)
	for k,v in pairs(BR2_TERMINALS) do
		v.Info = {
			tab_set = "TERMINAL_INFO_GENERIC",
			software = {
				scom_cameras = false
			}
		}
		if math.random(1,2) == 1 then
			v.Info.software.scom_cameras = true
			v.Authorization = {
				login = "admin",
				password = "admin",
				currentlyLogged = false,
			}
		end
	end


	-- OUTFITS
	local outfit_groups = {}
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.OUTFITTERS.buttons) do
		outfit_groups[v.item_gen_group] = outfit_groups[v.item_gen_group] or {}
		table.ForceInsert(outfit_groups[v.item_gen_group], v)
		v.items = {}
	end
	
	for k_outfit_group,outfit_group in pairs(outfit_groups) do
		if istable(MAPCONFIG.OUTFIT_GENERATION_GROUPS[k_outfit_group]) then
			local gen_groups = table.Copy(MAPCONFIG.OUTFIT_GENERATION_GROUPS[k_outfit_group])
			local all_outfitters = {}
			for i = 1, table.Count(gen_groups) do
				local rnd_outfitter = table.Random(gen_groups)
				table.ForceInsert(all_outfitters, rnd_outfitter)
				table.RemoveByValue(gen_groups, rnd_outfitter)
			end
			for k_item, item in pairs(all_outfitters) do
				local rnd_outfitter = table.Random(outfit_group)
				if istable(rnd_outfitter) then
					for i = 1, item[2] do
						table.ForceInsert(rnd_outfitter.items, item[1])
					end
					table.RemoveByValue(outfit_group, rnd_outfitter)
				end
			end
		end
	end

	-- ITEMS
	local container_groups = {}
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS.buttons) do
		container_groups[v.item_gen_group] = container_groups[v.item_gen_group] or {}
		table.ForceInsert(container_groups[v.item_gen_group], v)
		v.items = {}
	end
	for k_cont_group,cont_group in pairs(container_groups) do
		if istable(MAPCONFIG.ITEM_GENERATION_GROUPS[k_cont_group]) then
			local all_items = {}
			for k_item, item in pairs(MAPCONFIG.ITEM_GENERATION_GROUPS[k_cont_group]) do
				for i = 1, item[2] do
					table.ForceInsert(all_items, item[1])
				end
			end
			for k_button,button in pairs(cont_group) do
				if table.Count(button.items) == 0 and table.Count(all_items) > 0 then
					local rnd_item = table.Random(all_items)
					if rnd_item != nil then
						table.ForceInsert(button.items, form_basic_item_info(rnd_item))
						table.RemoveByValue(all_items, rnd_item)
					end
				end
			end
			for k_item,item in pairs(all_items) do
				local rnd_cont = table.Random(cont_group)
				if item != nil then
					table.ForceInsert(rnd_cont.items, form_basic_item_info(item))
				end
			end
		end
	end
	
	-- CAMERAS
	if istable(MAPCONFIG.CAMERAS) then
		for k,v in pairs(MAPCONFIG.CAMERAS) do
			local camera = ents.Create("br2_camera")
			if IsValid(camera) then
				camera:SetModel("models/props/cs_assault/camera.mdl")
				camera:SetPos(v.pos)
				camera:SetAngles(v.ang)
				camera:Spawn()
				camera.CameraInfo = table.Copy(v)
				camera.CameraName = v.name
				camera:SetNWString("CameraName", v.name)
			end
		end
	else
		print("[Breach2] No cameras found...")
		return
	end
	
	-- BUTTON CODES
	for k,v in pairs(button_ents) do
		if v.br_info.code != nil then
			local oldcode = v.br_info.code
			v.br_info.code = (math.random(1,9) * 1000) + (math.random(1,9) * 100) + (math.random(1,9) * 10) + math.random(1,9)
			print("Found a code button ("..oldcode..") changing to a random one ("..v.br_info.code..")")
			v.br_info.code_type = "radio"
		end
	end
end
