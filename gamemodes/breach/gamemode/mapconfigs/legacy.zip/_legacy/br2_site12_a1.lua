
MAPCONFIG = {}

// lua_run_cl LocalPlayer():GetActiveWeapon().SecondPos = MAPCONFIG.ZONES.HCZ[1][3]

local music_lcz =           "sound/breach2/music/The Dread.ogg"
local music_hcz =           "sound/breach2/music/HeavyContainment.ogg"
local music_049 =           "sound/breach2/music/Room049.ogg"
local music_ez =            "sound/breach2/music/EntranceZone.ogg"
local music_end =           "sound/breach2/music/SatiateStrings.mp3"
local music_pd =            "sound/breach2/music/Night_Trench.ogg"

//lua_run_cl EmitSound( Sound( "breach2/ambient/general/Ambient1.ogg" ), Entity( 1 ):GetPos(), 1, CHAN_AUTO, 1, 75, 0, 100 )
local ambient_general = {
	"breach2/ambient/general/Ambient1.ogg",
	"breach2/ambient/general/Ambient2.ogg",
	"breach2/ambient/general/Ambient3.ogg",
	"breach2/ambient/general/Ambient4.ogg",
	"breach2/ambient/general/Ambient5.ogg",
	"breach2/ambient/general/Ambient6.ogg",
	"breach2/ambient/general/Ambient7.ogg",
	"breach2/ambient/general/Ambient8.ogg",
	"breach2/ambient/general/Ambient9.ogg",
	"breach2/ambient/general/Ambient10.ogg",
	"breach2/ambient/general/Ambient11.ogg",
	"breach2/ambient/general/Ambient12.ogg",
	"breach2/ambient/general/Ambient13.ogg",
	"breach2/ambient/general/Ambient14.ogg",
	"breach2/ambient/general/Ambient15.ogg",
}

local ambient_lcz = {
	"breach2/ambient/zone1/Ambient1.ogg",
	"breach2/ambient/zone1/Ambient2.ogg",
	"breach2/ambient/zone1/Ambient3.ogg",
	"breach2/ambient/zone1/Ambient4.ogg",
	"breach2/ambient/zone1/Ambient5.ogg",
	"breach2/ambient/zone1/Ambient6.ogg",
	"breach2/ambient/zone1/Ambient7.ogg",
	"breach2/ambient/zone1/Ambient8.ogg",
}

local ambient_hcz = {
	"breach2/ambient/zone2/Ambient1.ogg",
	"breach2/ambient/zone2/Ambient2.ogg",
	"breach2/ambient/zone2/Ambient3.ogg",
	"breach2/ambient/zone2/Ambient4.ogg",
	"breach2/ambient/zone2/Ambient5.ogg",
	"breach2/ambient/zone2/Ambient6.ogg",
	"breach2/ambient/zone2/Ambient7.ogg",
	"breach2/ambient/zone2/Ambient8.ogg",
	"breach2/ambient/zone2/Ambient9.ogg",
	"breach2/ambient/zone2/Ambient10.ogg",
	"breach2/ambient/zone2/Ambient11.ogg",
}

local ambient_ez = {
	"breach2/ambient/zone3/Ambient1.ogg",
	"breach2/ambient/zone3/Ambient2.ogg",
	"breach2/ambient/zone3/Ambient3.ogg",
	"breach2/ambient/zone3/Ambient4.ogg",
	"breach2/ambient/zone3/Ambient5.ogg",
	"breach2/ambient/zone3/Ambient6.ogg",
	"breach2/ambient/zone3/Ambient7.ogg",
	"breach2/ambient/zone3/Ambient8.ogg",
	"breach2/ambient/zone3/Ambient9.ogg",
	"breach2/ambient/zone3/Ambient10.ogg",
	"breach2/ambient/zone3/Ambient11.ogg",
	"breach2/ambient/zone3/Ambient12.ogg",
}

local ambient_pd = {

}

MAPCONFIG.EnableGamemodeMusic = true
MAPCONFIG.EnableAmbientSounds = true
MAPCONFIG.GeneralAmbientSounds = ambient_general
MAPCONFIG.CommotionSounds = {
	"breach2/intro/Commotion/Commotion1.ogg",
	"breach2/intro/Commotion/Commotion2.ogg",
	"breach2/intro/Commotion/Commotion3.ogg",
	"breach2/intro/Commotion/Commotion4.ogg",
	"breach2/intro/Commotion/Commotion5.ogg",
	"breach2/intro/Commotion/Commotion6.ogg",
	"breach2/intro/Commotion/Commotion7.ogg",
	"breach2/intro/Commotion/Commotion8.ogg",
	"breach2/intro/Commotion/Commotion9.ogg",
	"breach2/intro/Commotion/Commotion10.ogg",
	"breach2/intro/Commotion/Commotion11.mp3",
	"breach2/intro/Commotion/Commotion12.ogg",
	"breach2/intro/Commotion/Commotion13.mp3",
	"breach2/intro/Commotion/Commotion14.mp3",
	"breach2/intro/Commotion/Commotion15.mp3",
	"breach2/intro/Commotion/Commotion16.ogg",
	"breach2/intro/Commotion/Commotion17.ogg",
	"breach2/intro/Commotion/Commotion18.ogg",
	"breach2/intro/Commotion/Commotion19.ogg",
	"breach2/intro/Commotion/Commotion20.ogg",
	"breach2/intro/Commotion/Commotion21.ogg",
	"breach2/intro/Commotion/Commotion22.mp3",
	"breach2/intro/Commotion/Commotion23.ogg",
	"breach2/intro/Bang2.ogg",
	"breach2/intro/Bang3.ogg",
}
/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/Alarm2_1.ogg", 6},
	{"breach2/alarm/Alarm2_2.ogg", 5},
	{"breach2/alarm/Alarm2_3.ogg", 7},
	{"breach2/alarm/Alarm2_4.ogg", 10},
	{"breach2/alarm/Alarm2_5.ogg", 6},
	{"breach2/alarm/Alarm2_6.ogg", 8},
	{"breach2/alarm/Alarm2_7.ogg", 7},
	{"breach2/alarm/Alarm2_8.ogg", 4},
	{"breach2/alarm/Alarm2_9.ogg", 4},
	{"breach2/alarm/Alarm2_10.ogg", 15}
}
*/
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/breach_alarm.ogg", 72},
}
MAPCONFIG.FirstSoundsLength = 72 // length of all of FirstSounds in seconds

MAPCONFIG.ZONES = {}
MAPCONFIG.Lockdown = function(initiate)
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "func_rot_button" then
			if v:GetPos() == Vector(-2164, 24, 310) then
				local rnd_ply = table.Random(team.GetPlayers(TEAM_ALIVE))
				if IsValid(rnd_ply) == false then return end
				//if initiate == true then
					print("Site lockdown Initiated")
					v:Use( rnd_ply, rnd_ply, USE_ON, 1 )
					return true
				//else
				//	print("Site unlockdown Initiated")
				//	v:Use( rnd_ply, rnd_ply, USE_OFF, 1 )
				//	return true
				//end
			end
		end
	end
	return nil
end

//  name                       First Position          Second Position         Color                music       fog     ambient       use general ambient
MAPCONFIG.ZONES.LCZ = {
	{"Light Containment Zone", Vector(-3190,2686,256), Vector(751,-1351,-128), Color(0,255,0,10),   music_lcz,  true,   ambient_lcz,  true},
	{"Light Containment Zone", Vector(3266,1968,385),  Vector(773,-501,0),     Color(0,255,0,15),   music_lcz,  true,   ambient_lcz,  true},
}
MAPCONFIG.ZONES.HCZ = {
	{"HCZ Tunnels",            Vector(831,367,-91),    Vector(4345,4592,-383), Color(0,0,150,10),   music_049,  true,   ambient_hcz,  true},
	{"Heavy Containment Zone", Vector(3307,-520,224),  Vector(6354,2040,-64),  Color(0,0,255,10),   music_hcz,  true,   ambient_hcz,  true},
	{"Heavy Containment Zone", Vector(2436,4832,157),  Vector(6354,2100,-64),  Color(0,0,255,10),   music_hcz,  true,   ambient_hcz,  true},
}
MAPCONFIG.ZONES.ENTRANCEZONE = {
	{"Entrance Zone",          Vector(2418,5794,128),  Vector(760,2563,0),     Color(255,255,0,10), music_ez,   true,   ambient_ez,   true},
	{"Entrance Zone",          Vector(-1289,5432,182), Vector(720,2803,-170),  Color(255,255,0,10), music_ez,   true,   ambient_ez,   true},
	{"Outside Gate A",         Vector(-2174,6932,-43), Vector(69,5408,272),    Color(255,0,0,10),   music_ez,   true},
}
MAPCONFIG.ZONES.POCKETDIMENSION = {
	{"Pocket Dimension",       Vector(2755,8133,3287), Vector(4295,9675,2911), Color(0,150,0,15),   music_pd,   true,   ambient_pd,   false},
}
MAPCONFIG.ZONES.OUTSIDE = {
	{"Outside Gate A",         Vector(-2187,6781,-52), Vector(-3331,6016,506), Color(255,0,255,10), music_end,  false},
}

//lua_run Entity(1):SetPos(SPAWNS_LCZ[1])

// Spawns in Class D's cells
MAPCONFIG.SPAWNS_CLASSD_CELLS = {
	Vector(-1472.8682861328, 2304.3510742188, 153.03125),
	Vector(-1603.5228271484, 2303.8044433594, 153.03125),
	Vector(-1728.9290771484, 2304.6140136719, 153.03125),
	Vector(-1858.0599365234, 2297.8603515625, 153.03125),
	Vector(-1988.6087646484, 2297.6596679688, 153.03125),
	Vector(-2116.4689941406, 2306.8798828125, 153.03125),
	Vector(-2238.5412597656, 2299.9497070313, 153.03125),
	Vector(-2369.7082519531, 2296.1213378906, 153.03125),
	Vector(-2495.8386230469, 2299.6984863281, 153.03125),
	Vector(-2622.3361816406, 2297.4470214844, 153.03125),
	Vector(-2750.3217773438, 2296.005859375, 153.03125),
	Vector(-2878.0368652344, 2300.9709472656, 153.03125),
	Vector(-3004.7822265625, 2300.9465332031, 153.03125),
	Vector(-3139.5556640625, 2297.2939453125, 153.03125),
	Vector(-3132.3266601563, 2561.517578125, 153.03125),
	Vector(-3007.439453125, 2562.9230957031, 153.03125),
	Vector(-2875.3029785156, 2557.4360351563, 153.03125),
	Vector(-2745.8603515625, 2565.1623535156, 153.03125),
	Vector(-2621.4812011719, 2572.03125, 153.03125),
	Vector(-2489.2673339844, 2567.5939941406, 153.03125),
	Vector(-2374.6806640625, 2557.9123535156, 153.03125),
	Vector(-2232.1892089844, 2566.7421875, 153.03125),
	Vector(-2105.8041992188, 2557.4194335938, 153.03125),
	Vector(-1975.9204101563, 2559.1140136719, 153.03125),
	Vector(-1849.4787597656, 2560.2619628906, 153.03125),
	Vector(-1725.6564941406, 2557.8095703125, 153.03125),
	Vector(-1600.3157958984, 2555.5881347656, 153.03125),
	Vector(-1465.4018554688, 2562.2399902344, 153.03125),
}

// Spawns in Light Containment Zone
MAPCONFIG.SPAWNS_LCZ = {
	Vector(2079.3503417969, 1519.4934082031, 25.031257629395),
	Vector(1678.6258544922, 1057.8756103516, 25.03125),
	Vector(1730.3957519531, -430.38876342773, 25.03125),
	Vector(1469.6827392578, 440.40127563477, 25.03125),
	Vector(3266.3647460938, 628.55426025391, 25.03125),
	Vector(-46.656894683838, 1972.7635498047, 153.03125),
	Vector(808.98382568359, 419.09393310547, 25.03125),
	Vector(-6.858268737793, -423.66802978516, -102.96875),
}

// Spawns in Heavy Containment Zone
MAPCONFIG.SPAWNS_HCZ = {
	Vector(6065.4018554688, 458.03033447266, 26.03125),
	Vector(4780.244140625, 447.16741943359, 25.03125),
	Vector(1868.8209228516, 3596.5693359375, -358.96875),
	Vector(2445.552734375, 1276.1820068359, -358.96875),
	Vector(2929.9255371094, 2188.693359375, 25.03125),
	Vector(5185.5654296875, 3055.1872558594, 25.031257629395),
	Vector(3445.78515625, 3402.41796875, 25.03125),
	Vector(2907.7563476563, 4289.1372070313, 26.03125),
	Vector(2051.4020996094, 941.00128173828, -166.96875),
}

// Spawns in Entrance Zone
MAPCONFIG.SPAWNS_ENTRANCEZONE = {
	Vector(1582.3991699219, 5083.8359375, 26.03125),
	Vector(-231.66033935547, 4911.8828125, -102.96875),
	Vector(-727.87866210938, 3422.451171875, 25.03125),
	Vector(299.23199462891, 3262.1740722656, 25.03125),
	Vector(897.25152587891, 3663.7866210938, 25.03125),
	Vector(2165.3293457031, 2998.5627441406, 25.03125),
	Vector(108.28215026855, 4104.3627929688, -38.968742370605),
	Vector(843.86236572266, 4284.462890625, 25.03125),
}

// Where Chaos Insurgency spawns at the beginning of the round
MAPCONFIG.SPAWNS_CHAOSINSURGENCY = {
	Vector(-1630.8168945313, 6269.6215820313, 25.031242370605),
	Vector(-1658.7874755859, 6179.8681640625, 25.031242370605),
	Vector(-1868.0627441406, 6177.255859375, 25.03125),
	Vector(-1915.8591308594, 6270.1694335938, 25.03125),
	Vector(-1932.6715087891, 6203.9877929688, 25.03125),
	Vector(-1814.9829101563, 6286.669921875, 25.03125),
	Vector(-1709.5361328125, 6316.2602539063, 25.03125),
	Vector(-1773.2979736328, 6213.76953125, 25.03125),
}

// SCP 173's spawns
MAPCONFIG.SPAWNS_SCP_173 = {
	Vector(1214.2551269531, 1727.2866210938, 153.03125),
	Vector(1205.5510253906, 1586.5300292969, 153.03125),
	Vector(1107.4619140625, 1690.3304443359, 153.03125),
	Vector(1088.9841308594, 1562.4237060547, 153.03125),
}

// SCP 049's spawns
MAPCONFIG.SPAWNS_SCP_049 = {
	Vector(2251.0981445313, 2844.5578613281, -358.96875),
	Vector(2239.9201660156, 2942.2705078125, -358.96875),
	Vector(2256.1826171875, 3118.6040039063, -358.96875),
}

// SCP 106's spawn`
MAPCONFIG.SPAWNS_SCP_106 = {
	Vector(2829.3684082031, 4889.8637695313, -422.96875),
	Vector(2805.7155761719, 4967.0703125, -422.96875),
	Vector(2795.5476074219, 5039.4697265625, -422.96875),
}

// SCP 457's spawn
MAPCONFIG.SPAWNS_SCP_457 = {
	Vector(4400.1372070313, 1720.6042480469, 25.03125),
	Vector(4277.8618164063, 1580.0657958984, -54.96875),
}

// SCP 966's spawn
MAPCONFIG.SPAWNS_SCP_966 = {
	Vector(2958.7956542969, 3010.966796875, 25.03125),
	Vector(3036.5441894531, 3029.7307128906, 25.03125),
	Vector(3029.5427246094, 2950.2456054688, 25.031257629395),
	Vector(2943.4038085938, 2941.2277832031, 25.03125),
}

// Spawns for other SCPs
MAPCONFIG.SPAWNS_SCP_OTHERS = {
	Vector(3503.2019042969, 3131.4350585938, 25.03125),
	Vector(3573.8725585938, 3114.5197753906, 25.03125),
	Vector(3423.3481445313, 3131.9501953125, 25.03125),
}

// Where Mobile Task Force spawns when they arrive in the facility
MAPCONFIG.SPAWNS_MTF = {
	Vector(-2381.4770507813, 6582.6596679688, 17.03125),
	Vector(-2389.5932617188, 6511.0981445313, 17.03125),
	Vector(-2475.4885253906, 6488.34375, 17.031242370605),
	Vector(-2450.8845214844, 6561.8374023438, 17.031257629395),
	Vector(-2543.849609375, 6524.529296875, 17.03125),
	Vector(-2512.2526855469, 6591.1538085938, 17.03125),
	Vector(-2455.0300292969, 6614.2426757813, 17.03125),
}

//Where Chaos Insurgency Support spawns when they arrive in the facility
MAPCONFIG.SPAWNS_CI_SUPPORT = {
	Vector(-2381.4770507813, 6582.6596679688, 17.03125),
	Vector(-2389.5932617188, 6511.0981445313, 17.03125),
	Vector(-2475.4885253906, 6488.34375, 17.031242370605),
	Vector(-2450.8845214844, 6561.8374023438, 17.031257629395),
	Vector(-2543.849609375, 6524.529296875, 17.03125),
	Vector(-2512.2526855469, 6591.1538085938, 17.03125),
	Vector(-2455.0300292969, 6614.2426757813, 17.03125),
}

print("[Breach2] MAP CONFIGURATION loaded!")