
MAPCONFIG = {}

function form_basic_item_info(class, amount)
	for k,v in pairs(BR2_DOCUMENTS) do
		if v.class == class then
			return {class = class, ammo = 0, name = v.name}
		end
	end
	for k,v in pairs(BR2_SPECIAL_ITEMS) do
		if v.class == class then
			return {class = class, ammo = 0, v.name}
		end
	end
	return {class = class, ammo = amount or 0, name = weapons.Get(class).PrintName}
end

MAPCONFIG.ITEM_GENERATION_GROUPS = {
	["LCZ_FIRST_LOOT"] = {
		{"keycard_level1", 4},
		{"keycard_playing", 1},
		{"keycard_master", 1},
		{"item_battery_9v", 3},
		{"item_radio", 1},

		{"flashlight", 3},
		{"coin", 4},
	},
	["LCZ_SECOND_LOOT"] = {
		{"keycard_level2", 4},
		{"keycard_playing", 1},
		{"keycard_master", 1},
		{"item_battery_9v", 1},

		{"flashlight", 1},
		{"coin", 2},
		{"device_cameras", 1},
	},
	["LCZ_THIRD_LOOT"] = {
		{"keycard_level3", 3},
		{"item_pills", 1},
		{"item_nvg", 1},
		{"kanade_tfa_crowbar", 1},

		{"device_cameras", 1},
	},
	["LCZ_WEAPON_LOOT"] = {
		{"kanade_tfa_pipe", 1},
		{"kanade_tfa_crowbar", 1},
		{"kanade_tfa_axe", 1},
	},
	["LCZ_ARMORY_LOOT"] = {
		{"kanade_tfa_m1911", 1},
		{"item_medkit", 1},
		{"item_gasmask", 1},
	},
	["LCZ_ADDITIONAL_LOOT"] = {
		{"item_gasmask", 1},
		{"item_nvg", 1},
		{"item_medkit", 1},
		{"item_radio", 1},
		{"item_pills", 1},
	},
	["LCZ_012_LOOT"] = {
		{"item_medkit", 1}
	},
	["LCZ_EARLIEST"] = {
		{"keycard_level1", 1},
	},
	["LCZ_DOC_173"] = {
		{"doc_scp173", 1},
	},

	["HCZ_FIRST"] = {
		{"keycard_level2", 2},
		{"keycard_level3", 2},
		{"item_gasmask", 1},
		{"item_medkit", 1},
		{"item_radio", 1},
		{"item_pills", 1},
		{"item_battery_9v", 3},

		{"flashlight", 1},
		{"coin", 2},
	},
	["HCZ_SECOND"] = {
		{"keycard_level4", 2},
		{"item_nvg", 1},
		{"item_medkit", 1},
		{"kanade_tfa_axe", 1},

		{"flashlight", 3},
		{"device_cameras", 1},
	},
	["HCZ_GUNS"] = {
		{"kanade_tfa_m590", 1},
		{"kanade_tfa_ump45", 1},
		{"kanade_tfa_beretta", 1},
	},
	["HCZ_035"] = {
		{"kanade_tfa_mp5k", 1},
		{"kanade_tfa_beretta", 1},
		{"item_c4", 1},
		{"item_medkit", 1},
	},

	["EZ"] = {
		{"keycard_level4", 3},
		{"kanade_tfa_beretta", 1},
		{"item_c4", 1},
		{"item_medkit", 1},
		{"item_radio", 1},

		{"flashlight", 3},
		{"coin", 3},
	},
	["EZ_SPECIAL"] = {
		{"kanade_tfa_m4a1", 1},
		{"kanade_tfa_mk18", 1},
		{"kanade_tfa_beretta", 1},
		{"kanade_tfa_ump45", 1},
	},
	["EZ_OFFICES"] = {
		{"keycard_level5", 1},

		{"flashlight", 1},
	},
	["EZ_MEDBAY"] = {
		{"item_medkit", 3},
		{"item_pills", 2},
	},
}

MAPCONFIG.OUTFIT_GENERATION_GROUPS = {
	["LCZ"] = {
		{"class_d", 4},
		{"scientist", 3},
		{"janitor", 2},
		{"medic", 1},
	},
	["LCZ_ARMORY"] = {
		{"guard", 2},
	},
	["HCZ"] = {
		{"guard", 1},
		{"hazmat", 1},
	},
	["EZ"] = {
		{"guard", 3},
		{"scientist", 1},
	},
}

MAPCONFIG.BUTTONS = {
	{
		name = "lcz_yellow_room_small",
		pos = Vector(1336.000000, 1931.000000, -8126.200195),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_armory_room",
		pos = Vector(752, -1515, -8144),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_yellow_room_big",
		pos = Vector(1128, -757, -8126.2001953125),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_914",
		pos = Vector(384, -958.5, -8155),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_scare_item_room",
		pos = Vector(504, 547, -8144),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_hand_scp_room",
		pos = Vector(680, 809, -8144),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_offices_1_1",
		pos = Vector(1096, 805, -8144),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_offices_1_2",
		pos = Vector(1336, 837, -8144),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_offices_2_1",
		pos = Vector(1040, 1221, -8144),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_offices_2_2",
		pos = Vector(1432, 1405, -8144),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_offices_door_1",
		pos = Vector(1307, 992, -8126.2001953125),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_offices_door_2",
		pos = Vector(1307, 1184, -8126.2001953125),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_checkpoint_1_near_offices",
		pos = Vector(1928, 1088, -8144),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_checkpoint_2_near_start",
		pos = Vector(-688, 504, -8144),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_item_room_near_checkpoint_2",
		pos = Vector(-409, -104, -8144),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_scp_372_room",
		pos = Vector(-1824, -705.5, -8155),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_vent_room",
		pos = Vector(1723, -88, -8144),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_scp_205",
		pos = Vector(1552, -1515, -8144),
		level = 1,
		sounds = true
	},


	-- HCZ
	{
		name = "hcz_early_armory",
		pos = Vector(-1096.0100097656, 1016, -7114.75),
		level = 4,
		sounds = true
	},
	{
		name = "hcz_scp_457",
		pos = Vector(-2495.6201171875, 2848, -7114.75),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_toxic_room_switch",
		pos = Vector(1367, 1698.5, -7367),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_toxic_room1",
		pos = Vector(680, 2208, -7114.75),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_toxic_room2",
		pos = Vector(757, 2304, -7115.25),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_near_checkpoint_item_room",
		pos = Vector(1448, 576, -7114.75),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_near_ez_checkpoint_item_room",
		pos = Vector(1520.3800048828, 2847.8798828125, -7114.75),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_scp_035",
		pos = Vector(512, 1112, -7114.75),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_storage_room_code",
		pos = Vector(-3049.1201171875, 3943.9299316406, -7114.75),
		level = 0,
		code = 1234,
		sounds = true
	},
	{
		name = "hcz_green_room",
		pos = Vector(3024, 4012, -8549),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_966_1",
		pos = Vector(-839.61999511719, 4127.9799804688, -7114.75),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_966_2",
		pos = Vector(-703.96997070313, 4264.2202148438, -7114.75),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_scp_079_exit1",
		pos = Vector(-3583.6201171875, 4127.9799804688, -7114.75),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_scp_079_inside",
		pos = Vector(-4031.0100097656, 4251.009765625, -7115),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_scp_079_exit2",
		pos = Vector(-3808.0100097656, 4932.990234375, -7259),
		level = 2,
		sounds = true
	},
	{
		name = "hcz_scp_079",
		pos = Vector(-3661.0100097656, 4567.990234375, -7259),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_scp_682",
		pos = Vector(1930, 4958, -8939.25),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_double_stairs_code",
		pos = Vector(-2208.1201171875, 4767.9399414063, -7114.75),
		level = 0,
		code = 1234,
		sounds = true
	},
	{
		name = "hcz_035_stash",
		pos = Vector(408, 704, -7114.75),
		level = 0,
		code = 1234,
		sounds = true
	},
	{
		name = "hcz_checkpoint_1",
		pos = Vector(-688, 504, -7120),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_checkpoint_2",
		pos = Vector(1928, 1088, -7120),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_scp_106",
		pos = Vector(-2624.1201171875, 5895.9399414063, -7114.75),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_tunnels_scp_049",
		pos = Vector(4318, -6568, -8555),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_049_doors",
		pos = Vector(4169, 1704, -8555),
		level = 0,
		code = 1234,
		sounds = true
	},




	-- EZ
	{
		name = "ez_dark_room",
		pos = Vector(2105, 6366, -7114.75),
		level = 1,
		sounds = true
	},
	{
		name = "ez_shared_conf_room",
		pos = Vector(2650, 4706, -7115),
		level = 3,
		sounds = true
	},
	{
		name = "ez_server_hub",
		pos = Vector(5524, 5097, -7371),
		level = 3,
		sounds = true
	},
	{
		name = "ez_gateb",
		pos = Vector(6432.1098632813, 5073.009765625, -7115),
		level = 3,
		sounds = true
	},
	{
		name = "ez_security_gateway",
		pos = Vector(5758, 5895, -7115),
		level = 3,
		sounds = true
	},
	{
		name = "ez_head_office",
		pos = Vector(5207, 6472, -7050.75),
		level = 5,
		sounds = true
	},
	{
		name = "ez_checkpoint1_back",
		pos = Vector(448, 4893, -7115),
		level = 3,
		sounds = true
	},
	{
		name = "ez_checkpoint1",
		pos = Vector(640.25, 5400, -7115),
		level = 3,
		sounds = true
	},
	{
		name = "ez_2level_office2",
		pos = Vector(1471, 6363, -7115),
		level = 2,
		sounds = true
	},
	{
		name = "ez_lockroom",
		pos = Vector(1356.9899902344, 6952.1098632813, -7247),
		level = 3,
		sounds = true
	},
	{
		name = "ez_gatea",
		pos = Vector(2682.5500488281, 7402.2998046875, -7114),
		level = 3,
		sounds = true
	},
	{
		name = "ez_office1a",
		pos = Vector(2056, 4144, -7115),
		level = 0,
		code = 1234,
		personal_office = true,
		sounds = true
	},
	{
		name = "ez_office1b",
		pos = Vector(1756, 4144, -7115),
		level = 0,
		code = 1234,
		personal_office = true,
		sounds = true
	},
	{
		name = "ez_checkpoint2",
		pos = Vector(1200, 3544.25, -7115),
		level = 3,
		sounds = true
	},
	{
		name = "ez_office2a",
		pos = Vector(2126, 5798, -7115),
		level = 0,
		code = 1234,
		personal_office = true,
		sounds = true
	},
	{
		name = "ez_office2b",
		pos = Vector(1826, 5798, -7115),
		level = 0,
		code = 1234,
		personal_office = true,
		sounds = true
	},
	{
		name = "ez_evac_shelter",
		pos = Vector(4354.1098632813, 5258.009765625, -7115),
		level = 1,
		sounds = true
	},
	{
		name = "ez_actual_evac_shelter",
		pos = Vector(4677.009765625, 5423, -7115),
		level = 0,
		code = 1234,
		evac_shelter = true,
		sounds = true
	},
	{
		name = "ez_conf_room",
		pos = Vector(5306, 7498, -7115),
		level = 5,
		sounds = true
	},
	{
		name = "ez_electrical_center",
		pos = Vector(5202, 7818, -7115),
		level = 4,
		sounds = true
	},
	{
		name = "ez_medbay",
		pos = Vector(1328, 5202, -7115),
		level = 2,
		sounds = true
	},
	/*
	{
		name = "YYYYYYYYYYYYYYYYYYYYYY",
		pos = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
		level = 1,
		sounds = true
	},
	*/
}

function MAP_ResetGasZones()
	MAPCONFIG.GAS_ZONES = {
		{pos1 = Vector(28,4964,-7184), pos2 = Vector(-144,4598,-7024)},
		{pos1 = Vector(5653,-247,-11574), pos2 = Vector(5416,-81,-11405)},
		{pos1 = Vector(681,195,-8204), pos2 = Vector(514,384,-8056)},
		{pos1 = Vector(-3165,5083,-7491), pos2 = Vector(-3262,5299,-7325)},
	}
end
MAP_ResetGasZones()

function MAP_EvacShelter1()
	local evac_shelter_1 = {pos1 = Vector(4859,5126,-7190), pos2 = Vector(4687,4947,-7033)}

	for k,v in pairs(player.GetAll()) do
		if v:IsInZone(evac_shelter_1) then
			print(v:Nick() .. " is in the evac shelter")
		end
	end
end

function MAP_GasLeak1()
	table.ForceInsert(MAPCONFIG.GAS_ZONES, {name = "gasleak1", pos1 = Vector(432,-2032,-8199), pos2 = Vector(752,-2192,-8055)})
	timer.Remove("GasLeak1")
	timer.Create("GasLeak1", 5, 1, function()
		for k,v in pairs(MAPCONFIG.GAS_ZONES) do
			if v.name == "gasleak1" then
				table.RemoveByValue(MAPCONFIG.GAS_ZONES, v)
			end
		end
	end)
end

function MAP_GasLeak2()
	table.ForceInsert(MAPCONFIG.GAS_ZONES, {name = "gasleak2", pos1 = Vector(4355,7019,-7189), pos2 = Vector(4680,6935,-7000)})
	timer.Remove("GasLeak2")
	timer.Create("GasLeak2", 5, 1, function()
		for k,v in pairs(MAPCONFIG.GAS_ZONES) do
			if v.name == "gasleak2" then
				table.RemoveByValue(MAPCONFIG.GAS_ZONES, v)
			end
		end
	end)
end

function MAP_GasLeak3()
	table.ForceInsert(MAPCONFIG.GAS_ZONES, {name = "gasleak2", pos1 = Vector(6052,6062,-7181), pos2 = Vector(5963,5732,-7019)})
	timer.Remove("GasLeak3")
	timer.Create("GasLeak3", 5, 1, function()
		for k,v in pairs(MAPCONFIG.GAS_ZONES) do
			if v.name == "gasleak3" then
				table.RemoveByValue(MAPCONFIG.GAS_ZONES, v)
			end
		end
	end)
end

local pd_spawn_height = -15469
MAPCONFIG.POCKETDIMENSION_SPAWNS = {
	Vector(23.301473617554, -10.723201751709, pd_spawn_height),
	Vector(-18.240295410156, -42.02742767334, pd_spawn_height),
	Vector(-15.765701293945, 1.2051422595978, pd_spawn_height),
	Vector(42.893028259277, -56.13041305542, pd_spawn_height),
	Vector(28.208240509033, 38.836673736572, pd_spawn_height),
	Vector(79.399269104004, -18.306934356689, pd_spawn_height),
	Vector(-14.227056503296, 60.410781860352, pd_spawn_height),
	Vector(-45.420238494873, 35.765735626221, pd_spawn_height),
	Vector(-54.177387237549, -14.005828857422, pd_spawn_height),
	Vector(-54.228298187256, -57.058036804199, pd_spawn_height),
	Vector(3.9432487487793, -88.955764770508, pd_spawn_height),
	Vector(-90.107643127441, -16.603729248047, pd_spawn_height),
	Vector(-80.204605102539, 37.095993041992, pd_spawn_height),
	Vector(-46.530025482178, 85.437194824219, pd_spawn_height),
	Vector(68.469787597656, 35.14973449707, pd_spawn_height),
}

MAPCONFIG.SCP_294_CUP = {pos = Vector(3421.650635, 4728.646484, -7266.223633), ang = Angle(0, 0, 0)}

br2_914_on_map = true

include("corpses.lua")
include("functions.lua")
--include("mapconfigs/br2_testing_3/init.lua")

print("[Breach2] Serverside mapconfig loaded!")
