
local ambient_general = {
	"breach2/ambient/general/Ambient1.ogg",
	"breach2/ambient/general/Ambient2.ogg",
	"breach2/ambient/general/Ambient3.ogg",
	"breach2/ambient/general/Ambient4.ogg",
	"breach2/ambient/general/Ambient5.ogg",
	"breach2/ambient/general/Ambient6.ogg",
	"breach2/ambient/general/Ambient7.ogg",
	"breach2/ambient/general/Ambient8.ogg",
	"breach2/ambient/general/Ambient9.ogg",
	"breach2/ambient/general/Ambient10.ogg",
	"breach2/ambient/general/Ambient11.ogg",
	"breach2/ambient/general/Ambient12.ogg",
	"breach2/ambient/general/Ambient13.ogg",
	"breach2/ambient/general/Ambient14.ogg",
	"breach2/ambient/general/Ambient15.ogg",
}

local ambient_lcz = {
	"breach2/ambient/zone1/Ambient1.ogg",
	"breach2/ambient/zone1/Ambient2.ogg",
	"breach2/ambient/zone1/Ambient3.ogg",
	"breach2/ambient/zone1/Ambient4.ogg",
	"breach2/ambient/zone1/Ambient5.ogg",
	"breach2/ambient/zone1/Ambient6.ogg",
	"breach2/ambient/zone1/Ambient7.ogg",
	"breach2/ambient/zone1/Ambient8.ogg",
}

local ambient_hcz = {
	"breach2/ambient/zone2/Ambient1.ogg",
	"breach2/ambient/zone2/Ambient2.ogg",
	"breach2/ambient/zone2/Ambient3.ogg",
	"breach2/ambient/zone2/Ambient4.ogg",
	"breach2/ambient/zone2/Ambient5.ogg",
	"breach2/ambient/zone2/Ambient6.ogg",
	"breach2/ambient/zone2/Ambient7.ogg",
	"breach2/ambient/zone2/Ambient8.ogg",
	"breach2/ambient/zone2/Ambient9.ogg",
	"breach2/ambient/zone2/Ambient10.ogg",
	"breach2/ambient/zone2/Ambient11.ogg",
}

local ambient_ez = {
	"breach2/ambient/zone3/Ambient1.ogg",
	"breach2/ambient/zone3/Ambient2.ogg",
	"breach2/ambient/zone3/Ambient3.ogg",
	"breach2/ambient/zone3/Ambient4.ogg",
	"breach2/ambient/zone3/Ambient5.ogg",
	"breach2/ambient/zone3/Ambient6.ogg",
	"breach2/ambient/zone3/Ambient7.ogg",
	"breach2/ambient/zone3/Ambient8.ogg",
	"breach2/ambient/zone3/Ambient9.ogg",
	"breach2/ambient/zone3/Ambient10.ogg",
	"breach2/ambient/zone3/Ambient11.ogg",
	"breach2/ambient/zone3/Ambient12.ogg",
}

MAPCONFIG.EnableGamemodeMusic = true
MAPCONFIG.EnableAmbientSounds = true
MAPCONFIG.GeneralAmbientSounds = ambient_general
MAPCONFIG.CommotionSounds = {
	"breach2/intro/Commotion/Commotion1.ogg",
	"breach2/intro/Commotion/Commotion2.ogg",
	"breach2/intro/Commotion/Commotion3.ogg",
	"breach2/intro/Commotion/Commotion4.ogg",
	"breach2/intro/Commotion/Commotion5.ogg",
	"breach2/intro/Commotion/Commotion6.ogg",
	"breach2/intro/Commotion/Commotion7.ogg",
	"breach2/intro/Commotion/Commotion8.ogg",
	"breach2/intro/Commotion/Commotion9.ogg",
	"breach2/intro/Commotion/Commotion10.ogg",
	"breach2/intro/Commotion/Commotion11.mp3",
	"breach2/intro/Commotion/Commotion12.ogg",
	"breach2/intro/Commotion/Commotion13.mp3",
	"breach2/intro/Commotion/Commotion14.mp3",
	"breach2/intro/Commotion/Commotion15.mp3",
	"breach2/intro/Commotion/Commotion16.ogg",
	"breach2/intro/Commotion/Commotion17.ogg",
	"breach2/intro/Commotion/Commotion18.ogg",
	"breach2/intro/Commotion/Commotion19.ogg",
	"breach2/intro/Commotion/Commotion20.ogg",
	"breach2/intro/Commotion/Commotion21.ogg",
	"breach2/intro/Commotion/Commotion22.mp3",
	"breach2/intro/Commotion/Commotion23.ogg",
	"breach2/intro/Bang2.ogg",
	"breach2/intro/Bang3.ogg",
}

/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/Alarm2_1.ogg", 6},
	{"breach2/alarm/Alarm2_2.ogg", 5},
	{"breach2/alarm/Alarm2_3.ogg", 7},
	{"breach2/alarm/Alarm2_4.ogg", 10},
	{"breach2/alarm/Alarm2_5.ogg", 6},
	{"breach2/alarm/Alarm2_6.ogg", 8},
	{"breach2/alarm/Alarm2_7.ogg", 7},
	{"breach2/alarm/Alarm2_8.ogg", 4},
	{"breach2/alarm/Alarm2_9.ogg", 4},
	{"breach2/alarm/Alarm2_10.ogg", 15}
}
*/

MAPCONFIG.FirstSounds = {
	{"breach2/alarm/breach_alarm.ogg", 72},
}
MAPCONFIG.FirstSoundsLength = 72 -- length of all of FirstSounds in seconds

MAPCONFIG.CAMERAS = {
	{name = "lcz_corridor_1", pos = Vector(1444,-112,-8020), ang = Angle(0,180,0)},
	{name = "lcz_corridor_2", pos = Vector(1581,-272,-8034), ang = Angle(0,0,0)},
	{name = "lcz_corridor_3", pos = Vector(1148,-1940,-8036), ang = Angle(0,263,0)},
	{name = "lcz_corridor_4", pos = Vector(48,219,-8025), ang = Angle(0,90,0)},
	{name = "lcz_corridor_5", pos = Vector(166,2576,-8026), ang = Angle(0,180,0)},
	{name = "lcz_corridor_6", pos = Vector(-499,-768,-7991), ang = Angle(0,180,0)},
	{name = "lcz_corridor_7", pos = Vector(1446,1168,-8040), ang = Angle(0,180,0)},
	{name = "lcz_office_room_1", pos = Vector(-944,864,-7974), ang = Angle(0,90,0)},
	{name = "lcz_storage_room_1", pos = Vector(912,-585,-7967), ang = Angle(0,-90,0)},
	{name = "lcz_cont_room_scp012", pos = Vector(-1068,224,-8286), ang = Angle(0,180,0)},
	{name = "lcz_cont_room_scp173", pos = Vector(-56,1230,-7924), ang = Angle(0,90,0)},

	{name = "hcz_corridor_1", pos = Vector(-376,5011,-7048), ang = Angle(0,-90,0)},
	{name = "hcz_corridor_2", pos = Vector(-1424,1084,-7016), ang = Angle(0,-90,0)},
	{name = "hcz_corridor_3", pos = Vector(-1265,4224,-7034), ang = Angle(0,180,0)},
	{name = "hcz_corridor_4", pos = Vector(-768,2441,-7055), ang = Angle(0,-90,0)},
	{name = "hcz_water_room", pos = Vector(960,2238,-7014), ang = Angle(0,-90,0)},
	{name = "hcz_cont_room_scp682", pos = Vector(-376,5011,-7048), ang = Angle(0,-90,0)},
	{name = "hcz_cont_room_scp457", pos = Vector(-2680,3083,-7014), ang = Angle(0,-90,0)},
	{name = "hcz_cont_room_scp106", pos = Vector(-2143,6712,-6962), ang = Angle(0,180,0)},
	{name = "hcz_cont_room_scp008", pos = Vector(-1610,4520,-7061), ang = Angle(0,0,0)},
	{name = "hcz_cont_room_scp682", pos = Vector(-1610,4520,-7061), ang = Angle(0,0,0)},
}

MAPCONFIG.BUTTONS_2D = {}

MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS = {
	on_open = function(button)
		TryToOpenContainer(button)
	end,
	buttons = {
		{pos = Vector(-2525,-579,-8163), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(1088,-576,-8145), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(252,396,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(1499,1326,-8136), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(498,-1103,-8144), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(246,540,-8131), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(2212,-1755,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-915,-633,-8162), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(494,2138,-8145), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(954,1467,-8137), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-290,-1190,-8142), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-673,-639,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-541,-53,-8173), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(847,817,-8177), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(1489,1770,-8142), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(-975,1035,-8139), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(2525,-710,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(1599,-64,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(958,812,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-1046,77,-8413), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-657,1968,-7901), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(1450,813,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},

		{pos = Vector(440,-1422,-8135), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(713,-1683,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},

		{pos = Vector(184,5043,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-4017,4209,-7115), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-2369,4444,-7131), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-2896,4321,-7122), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-1183,1096,-7132), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(376,639,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"},
		{pos = Vector(332,634,-7156), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"},
		{pos = Vector(292,641,-7155), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"},
		{pos = Vector(-1495,3649,-7122), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-1172,1103,-7113), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1691,2824,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1521,544,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},

		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
	}
}

MAPCONFIG.BUTTONS_2D.SIMPLE = {
	on_open = function(button)
		SimpleButtonUse(button)
		surface.PlaySound("breach2/pickitem2.ogg")
	end,
	buttons = {
		{name = "SCP-1162", pos = Vector(903,882,-8143), canSee = DefaultItemContainerCanSee, func_sv = function(ply)
			local weps = {}
			for k,v in pairs(ply:GetWeapons()) do
				if v.Pickupable == true or v.droppable == true then
					table.ForceInsert(weps, v)
				end
			end
			if table.Count(weps) == 0 then
				ply:TakeDamage(20, ply, ply)
			else
				local rnd_wep = table.Random(weps)
				local ent = ents.Create(table.Random({"keycard_master", "keycard_playing", "item_battery_9v", "item_pills", "item_radio", "keycard_level1", "item_gasmask"}))
				if IsValid(ent) then
					ent:SetPos(Vector(893,882,-8144))
					ent:SetNWBool("isDropped", true)
					ent:Spawn()
					ply:StripWeapon(rnd_wep:GetClass())
				end
			end
		end},
	}
}

MAPCONFIG.BUTTONS_2D.OUTFITTERS = {
	on_open = function(button)
		if LocalPlayer():GetOutfit().can_change_outfits == false then
			--chat.AddText(Color(255, 255, 255), "You cannot change your outfit")
			chat.AddText(Color(255, 255, 255), "You couldn't find anything useful...")

			return
		end
		net.Start("br_use_outfitter")
			net.WriteVector(button.pos)
		net.SendToServer()
	end,
	-- setpos -789.450562 -652.576416 -8168.468750;setang 11.656787 -83.756401 0.000000
	buttons = {
		{pos = Vector(-777,-707,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(960,-1089,-8156), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(465,256,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-330,-1263,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(959,912,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(504,-1682,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ_ARMORY"},
		{pos = Vector(-3520,5473,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1521,512,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-350,446,-6094), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		{pos = Vector(-229,3757,-6109), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},

	}
}

MAPCONFIG.BUTTONS_2D.TERMINALS = {
	on_open = function(button)
		BR_Access_Terminal(button)
	end,
	buttons = {
	-- LCZ
		-- OFFICES
		{name = "lcz_office_1_1", pos = Vector(-959,908,-8143), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_2", pos = Vector(-1012,1165,-8124), canSee = function() return CanSeeFrom(Vector(-1012,1151,-8125)) end},
		{name = "lcz_office_1_3", pos = Vector(-972,1165,-8124), canSee = function() return CanSeeFrom(Vector(-971,1151,-8125)) end},
		{name = "lcz_office_1_4", pos = Vector(-1034,1224,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_5", pos = Vector(-1034,1375,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_6", pos = Vector(-1213,1373,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_7", pos = Vector(-1214,1220,-8143), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_8", pos = Vector(-1213,1056,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_9", pos = Vector(-1249,1056,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_10", pos = Vector(-1249,1373,-8142), canSee = DefaultTerminalCanSee},
		
		-- STORAGE ROOMS
		{name = "lcz_storage_room_1", pos = Vector(1027,-559,-8141), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_1", pos = Vector(743,2156,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_1", pos = Vector(763,2001,-8139), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_2", pos = Vector(763,1980,-8139), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_3", pos = Vector(744,2051,-8112), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_4", pos = Vector(744,2028,-8112), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_3", pos = Vector(880,-1614,-8142), canSee = DefaultTerminalCanSee},
		
		-- CONTAINMENT ROOMS
		{name = "lcz_cont_room_1_1", pos = Vector(-1980,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1981,-529,-8124)) end},
		{name = "lcz_cont_room_1_2", pos = Vector(-1940,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1940,-528,-8124)) end},
		{name = "lcz_cont_room_2_1", pos = Vector(494,212,-8123), canSee = function() return CanSeeFrom(Vector(478,212,-8124)) end},
		{name = "lcz_cont_room_2_2", pos = Vector(494,172,-8123), canSee = function() return CanSeeFrom(Vector(480,173,-8124)) end},
		{name = "lcz_cont_room_3_1", pos = Vector(1940,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1941,-1504,-8123)) end},
		{name = "lcz_cont_room_3_2", pos = Vector(1900,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1900,-1504,-8123)) end},
		{name = "lcz_cont_room_4", pos = Vector(860,798,-8142), canSee = DefaultTerminalCanSee},

		-- CHECKPOINTS
		{name = "lcz_checkpoint_1_1", pos = Vector(-430,430,-8124), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_1_2", pos = Vector(-430,466,-8124), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_2_1", pos = Vector(-429,430,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_2_2", pos = Vector(-429,466,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_3_1_1", pos = Vector(1890,829,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_3_1_2", pos = Vector(-2666,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_3_2_1", pos = Vector(-2736,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2735,5388,-7357)) end},
		{name = "lcz_checkpoint_3_2_2", pos = Vector(-2697,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2697,5392,-7356)) end},

	--HCZ
		-- CONTAINMENT ROOMS
		{name = "hcz_cont_room_1_1", pos = Vector(605,923,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_1_2", pos = Vector(605,887,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_2_1", pos = Vector(838,2301,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_2_2", pos = Vector(874,2301,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_1_1", pos = Vector(-2526,2724,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_1_2", pos = Vector(-2561,2724,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_2_1", pos = Vector(-2659,3156,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_2_2", pos = Vector(-2623,3156,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_4_1", pos = Vector(-3004,3722,-7108), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_4_2", pos = Vector(-3004,3686,-7107), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_5_1", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_5_2", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
		
		-- CHECKPOINTS
		{name = "hcz_checkpoint_1_1", pos = Vector(-428,430,-7099), canSee = DefaultTerminalCanSee},
		{name = "hcz_checkpoint_1_2", pos = Vector(-428,466,-7099), canSee = DefaultTerminalCanSee},

	--EZ
		-- CHECKPOINTS
		{name = "ez_checkpoint_1_1_1", pos = Vector(1458,3470,-6076), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_1_1_2", pos = Vector(1458,3506,-6076), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_1_2", pos = Vector(633,3292,-6094), canSee = DefaultTerminalCanSee},
		
		-- OFFICES
		{name = "ez_office_1", pos = Vector(459,4178,-6078), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2", pos = Vector(219,1253,-6094), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_1", pos = Vector(-784,1860,-6029), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_2", pos = Vector(-790,1998,-6030), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_3", pos = Vector(-662,2001,-6030), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_4", pos = Vector(-664,1531,-6030), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4_1", pos = Vector(705,2800,-6190), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4_2", pos = Vector(751,2671,-6189), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4_3", pos = Vector(619,2571,-6190), canSee = DefaultTerminalCanSee},


		
		-- STORAGE ROOMS
		{name = "ez_storage_room_1", pos = Vector(-410,318,-5998), canSee = DefaultTerminalCanSee},
		{name = "ez_storage_room_2", pos = Vector(-367,3838,-6094), canSee = DefaultTerminalCanSee},
	}
}
-- ulx strip ^ ; give breach_tool_terminalplacer
-- lua_run Entity(1):SetPos(xxxxxxxxxxxxxxxxxxxxxx)

MAPCONFIG.ZONES = {}

MAPCONFIG.SPECIAL_MUSIC_ZONES = {
	{pos1 = Vector(465,-1144,-8222), pos2 = Vector(903,-520,-8065), sound = "breach2/music/914.ogg", length = 29.05, volume = 0.8}, -- 914
	{pos1 = Vector(1592,-901,-8229), pos2 = Vector(2314,-1787,-8026), sound = "breach2/music/205.ogg", length = 40.5, volume = 0.8}, -- 205
	{pos1 = Vector(3400,-7035,-8653), pos2 = Vector(4969,-5453,-8394), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, -- 049 TUNNELS
	{pos1 = Vector(3637,261,-7459), pos2 = Vector(4658,-1082,-6809), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, -- WARHEADS
	{pos1 = Vector(5370,366,-11672), pos2 = Vector(7569,-2400,-11324), sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 0.8}, -- HCZ TUNNELS
	{pos1 = Vector(-912,2139,-16175), pos2 = Vector(2016,-899,-14578), sound = "breach2/music/PD.ogg", length = 27.03, volume = 1}, -- PD
	--{pos1 = Vector(14907,-15883,-2283), pos2 = Vector(10162,-10690,99), sound = "breach2/music/1499.ogg", length = 50, volume = 0.7}, -- 1499
	{pos1 = Vector(-1003,-397,-8475), pos2 = Vector(-1592,235,-8317), sound = "breach2/music/012.ogg", length = 25.5, volume = 0.7}, -- 012
}

MAPCONFIG.ESCAPE_ZONES = {
	{ pos1 = Vector(-6526,3309,-1615), pos2 = Vector(-7232,1660,-667) },
	{ pos1 = Vector(2618,-394,237), pos2 = Vector(2137,-1307,515) },
}

MAPCONFIG.GAS_ZONES = {
	{ pos1 = Vector(28,4964,-7184), pos2 = Vector(-144,4598,-7024) },
	{ pos1 = Vector(5653,-247,-11574), pos2 = Vector(5416,-81,-11405) },
}

--  name                       	First Position          	Second Position         	Color                music       fog     NVGmul		ambient       use general ambient
MAPCONFIG.ZONES.LCZ = {
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(-3999,-2473,-8672),
		pos2 						= Vector(3302,3060,-7732),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(2466,2818,-7720),
		pos2 						= Vector(1830,2170,-6653),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.HCZ = {
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(1786,7123,-7625),
		pos2 						= Vector(-4100,10,-6658),
		--music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(2517,807,-7697),
		pos2 						= Vector(1806,1350,-7015),
		--music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "SCP-049's Tunnels",
		pos1 						= Vector(3400,-7035,-8653),
		pos2 						= Vector(4969,-5453,-8394),
		--music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		music 						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in SCP-049's Tunnels",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "HCZ Tunnels",
		pos1 						= Vector(5370,366,-11672),
		pos2 						= Vector(7569,-2400,-11324),
		music 						= {sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Tunnel system",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "HCZ Warheads",
		pos1 						= Vector(3637,261,-7459),
		pos2 						= Vector(4658,-1082,-6809),
		music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Warhead Control Room",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.ENTRANCEZONE = {
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(3961,5828,-6625),
		pos2 						= Vector(-2735,-2100,-4503),
		--music 						= {sound = "breach2/music/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.POCKETDIMENSION = {
	{
		name 						= "Pocket Dimension",
		pos1 						= Vector(-912,2139,-16175),
		pos2 						= Vector(2016,-899,-14578),
		music 						= {sound = "breach2/music/PD.ogg", length = 27.03, volume = 1},
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(0,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in the Pocket Dimension",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.OUTSIDE = {
	{
		name 						= "Outside",
		pos1 						= Vector(4797,-2801,-1771),
		pos2 						= Vector(-7418,5765,1983),
		--music 						= {sound = "breach2/music/withinsight.ogg", length = 60.44, volume = 0.5},
		music						= nil,
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(255,0,255,50),
		sanity 						= 1,
		examine_info 				= "You are outside of the facility",
		zone_temp 					= ZONE_TEMP_VERYCOLD,
		scp_106_can_tp 				= false,
	},
} 
MAPCONFIG.ZONES.FOREST = {
	{
		name 						= "Forest",
		pos1 						= Vector(12061,-15943,-3792),
		pos2 						= Vector(15048,-13022,-2633),
		music 						= nil,
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(70,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in a forest",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= false,
	},
}
/*
MAPCONFIG.ZONES.SCP_1499 = {
	{
		name 						= "SCP-1499",
		pos1 						= Vector(14907,-15883,-2283),
		pos2 						= Vector(10162,-10690,99),
		music 						= {sound = "breach2/music/1499.ogg", length = 50, volume = 1},
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(150,0,0,50),
		sanity 						= -1,
		examine_info 				= "You are in an unknown world",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= false,
	},
}
*/

-- Spawns in Class D's cells
MAPCONFIG.SPAWNS_CLASSD_CELLS = {
	Vector(-3602.939453125, 832.32720947266, -8046.96875),
	Vector(-3818.6428222656, 836.63403320313, -8046.96875),
	Vector(-3391.6364746094, 826.951171875, -8046.96875),
	Vector(-3187.87109375, 819.77954101563, -8046.96875),
	Vector(-2978.2719726563, 818.99493408203, -8046.96875),
	Vector(-2767.869140625, 823.73364257813, -8046.96875),
	Vector(-2764.4208984375, 300.34832763672, -8046.96875),
	Vector(-2968.7724609375, 301.01162719727, -8046.96875),
	Vector(-3186.3063964844, 296.73794555664, -8046.96875),
	Vector(-3385.3439941406, 298.82928466797, -8046.96875),
	Vector(-3605.9470214844, 293.82122802734, -8046.96875),
	Vector(-3811.1315917969, 294.30609130859, -8046.96875),
	Vector(-3706.0673828125, 464.80758666992, -8046.96875),
	Vector(-3604.4721679688, 461.24993896484, -8046.96875),
	Vector(-3711.3837890625, 665.58489990234, -8046.96875),
	Vector(-3573.3332519531, 689.86108398438, -8046.96875),
	Vector(-3482.9926757813, 469.52133178711, -8046.96875),
	Vector(-3445.1513671875, 665.87170410156, -8046.96875),
	Vector(-3348.6916503906, 464.94454956055, -8046.96875),
	Vector(-3307.9562988281, 655.20361328125, -8046.96875),
}

-- Spawns in Light Containment Zone
MAPCONFIG.SPAWNS_LCZ = {
	Vector(-533.94122314453, 1869.1693115234, -7905.96875),
	Vector(-1341.4820556641, 2493.8188476563, -8161.96875),
	Vector(587.75256347656, 2363.97265625, -8161.96875),
	Vector(1232.884765625, 1661.8000488281, -8161.96875),
	Vector(-1857.3309326172, 1092.9927978516, -8033.96875),
	Vector(-1162.1278076172, 917.470703125, -8161.96875),
	Vector(-1321.6896972656, -856.57196044922, -8161.96875),
	Vector(-44.114860534668, -663.82232666016, -8161.96875),
	Vector(-657.43664550781, -145.09915161133, -8161.96875),
	Vector(0.71955490112305, 630.56677246094, -8161.96875),
	Vector(601.30651855469, 19.127395629883, -8161.96875),
	Vector(1221.8041992188, -1493.4887695313, -8161.96875),
	Vector(2514.998046875, -66.075012207031, -8161.96875),
	Vector(1787.1489257813, -187.2525177002, -8161.96875),
	Vector(-275.55505371094, -1479.5308837891, -8161.96875),
	Vector(627.23950195313, -2319.5812988281, -8161.96875),	
}

-- Spawns in Heavy Containment Zone
MAPCONFIG.SPAWNS_HCZ = {
	Vector(583.91583251953, 2192.056640625, -7137.96875),
	Vector(-672.67742919922, 1585.462890625, -7137.96875),
	Vector(-52.506637573242, 2867.2775878906, -7137.96875),
	Vector(-696.39196777344, 3640.2463378906, -7137.96875),
	Vector(-2203.0905761719, 4525.5053710938, -7137.96875),
	Vector(-718.07312011719, 4795.6030273438, -7137.96875),
	Vector(-1989.7225341797, 5278.11328125, -7137.96875),
	Vector(-3240.7717285156, 5407.3735351563, -7137.96875),
	Vector(-3296.470703125, 4111.7993164063, -7137.96875),
	Vector(-1407.0133056641, 4064.7700195313, -7137.96875),
	Vector(1648.1843261719, 2895.0822753906, -7137.96875),
	Vector(-65.262420654297, 5334.828125, -7137.96875),	
}

-- Spawns in Entrance Zone
MAPCONFIG.SPAWNS_ENTRANCEZONE = {
	Vector(1790.5290527344, 4263.55859375, -7137.96875),
	Vector(1204.6691894531, 4398.087890625, -7137.96875),
	Vector(577.63647460938, 4801.080078125, -7137.96875),
	Vector(3209.4875488281, 4250.0961914063, -7137.96875),
	Vector(2561.0180664063, 5077.4575195313, -7137.96875),
	Vector(1732.5205078125, 5231.57421875, -7137.96875),
	Vector(1205.2709960938, 5123.599609375, -7137.96875),
	Vector(3830.884765625, 4389.4912109375, -7137.96875),
	Vector(4283.1147460938, 4791.533203125, -7265.96875),
	Vector(4242.3310546875, 5446.0283203125, -7137.96875),
	Vector(3076.1342773438, 5386.8486328125, -7137.96875),
}


-- Where Chaos Insurgency spawns at the beginning of the round
MAPCONFIG.SPAWNS_CHAOSINSURGENCY = {
	{
		name = "Gate A",
		spawns = {
			Vector(2522.6052246094, 7854.08984375, -7137.96875),
			Vector(2685.439453125, 7798.673828125, -7137.96875),
			Vector(2568.2150878906, 7706.0610351563, -7137.96875),
			Vector(2431.9326171875, 7660.4897460938, -7137.96875),
			Vector(2464.5893554688, 7547.900390625, -7137.96875),
			Vector(2598.1091308594, 7569.9682617188, -7137.96875),
		}
	},
	{
		name = "Gate B",
		spawns = {
			Vector(6913.294921875, 5231.9653320313, -7137.96875),
			Vector(6910.4458007813, 5099.150390625, -7137.96875),
			Vector(6906.1025390625, 4955.39453125, -7137.96875),
			Vector(6694.1342773438, 4870.3662109375, -7137.96875),
			Vector(6695.5122070313, 5032.0366210938, -7137.96875),
			Vector(6743.4887695313, 5206.8090820313, -7137.96875),
			Vector(6585.6704101563, 5178.7290039063, -7137.96875),
			Vector(6989.125, 5340.41015625, -7137.96875),
			Vector(7092.05859375, 4863.5317382813, -7137.96875),
		}
	},
	{
		name = "Office",
		spawns = {
			Vector(4379.166015625, 5907.3515625, -7137.96875),
			Vector(4379.0166015625, 6021.5693359375, -7137.96875),
			Vector(4393.7329101563, 6150.0166015625, -7137.96875),
			Vector(4550.5541992188, 6138.7387695313, -7137.96875),
			Vector(4553.208984375, 5877.4926757813, -7137.96875),
			Vector(4208.1850585938, 5997.0493164063, -7137.96875),
			Vector(4241.4770507813, 5823.6787109375, -7137.96875),
			Vector(4407.0356445313, 5773.7036132813, -7137.96875),
			Vector(4547.32421875, 6005.8852539063, -7137.96875),
		}
	}
}

-- SCP 035's spawns
MAPCONFIG.SPAWNS_SCP_035 = {
	Vector(765.39086914063, 1020.7515258789, -7137.96875)
}

-- SCP 173's spawns
MAPCONFIG.SPAWNS_SCP_173 = {
	Vector(-189.662064, 1955.437500, -8063.968750)
}

-- SCP 049's spawns
MAPCONFIG.SPAWNS_SCP_049 = {
	Vector(4180.052734375, -6376.6708984375, -8582.96875),
	Vector(4086.451171875, -6439.6264648438, -8582.96875),
	Vector(4181.0200195313, -6440.6103515625, -8582.96875),
	Vector(4256.5708007813, -6396.4174804688, -8582.96875)
}

-- SCP 106's spawn
MAPCONFIG.SPAWNS_SCP_106 = {
	Vector(-263.70867919922, 1420.8409423828, -8033.96875),
	Vector(-152.89517211914, 1459.5327148438, -8033.96875),
	Vector(-141.37690734863, 1299.3089599609, -8033.96875),
	Vector(-258.21087646484, 1247.1650390625, -8033.96875),
	Vector(-333.30120849609, 1307.2036132813, -8033.96875)
}

-- SCP 457's spawn
MAPCONFIG.SPAWNS_SCP_457 = {
	Vector(-2557.9653320313, 2914.3310546875, -7142.96875),
	Vector(-2605.4235839844, 2929.216796875, -7142.96875),
	Vector(-2541.8579101563, 2977.3583984375, -7142.96875),
	Vector(-2609.3569335938, 3002.3344726563, -7142.96875)
}

-- SCP 966's spawn
MAPCONFIG.SPAWNS_SCP_966 = {
	Vector(-641.97521972656, 4187.5517578125, -7137.96875),
	Vector(-649.57940673828, 4098.4736328125, -7137.96875),
	Vector(-777.77038574219, 4117.9116210938, -7137.96875),
	Vector(-733.60302734375, 4192.3076171875, -7137.96875)	
}

-- Where Mobile Task Force spawns when they arrive in the facility
MAPCONFIG.SPAWNS_MTF = {
	{
		name = "Gate A",
		spawns = {
			Vector(2730.416015625, 7862.8862304688, -7137.96875),
			Vector(2740.3139648438, 7750.8129882813, -7137.96875),
			Vector(2488.8137207031, 7869.9287109375, -7137.96875),
			Vector(2348.0471191406, 7735.3061523438, -7137.96875),
			Vector(2404.8051757813, 7679.7036132813, -7137.96875),
			Vector(2380.7648925781, 7573.5913085938, -7137.96875),
			Vector(2673.6123046875, 7802.0688476563, -7137.96875),
			Vector(2664.3566894531, 7518.4125976563, -7137.96875),
			Vector(2591.5432128906, 7870.9462890625, -7137.96875),				
		},
		available = function()
			local pos1 = Vector(3001,7166,-7205)
			local pos2 = Vector(2212,7990,-6680)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "Gate B",
		spawns = {
			Vector(6529.130859375, 4920.9926757813, -7137.96875),
			Vector(6527.5874023438, 5003.4536132813, -7137.96875),
			Vector(6613.9057617188, 4848.7416992188, -7137.96875),
			Vector(6608.0512695313, 4961.4155273438, -7137.96875),
			Vector(6708.1938476563, 4840.4189453125, -7137.96875),
			Vector(6685.6499023438, 4921.6499023438, -7137.96875),
			Vector(6903.8999023438, 5410.58984375, -7137.96875),
			Vector(6535.7124023438, 5413.1123046875, -7137.96875),
			Vector(6630.0131835938, 5412.7358398438, -7137.96875),						
		},
		available = function()
			local pos1 = Vector(6210,5521,-7203)
			local pos2 = Vector(7515,4601,-6915)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "Gate C",
		spawns = {
			Vector(1434.0267333984, 7431.97265625, -7269.96875),
			Vector(1413.7924804688, 7346.2729492188, -7269.96875),
			Vector(1372.0592041016, 7400.08203125, -7269.96875),
			Vector(1093.5893554688, 7374.0913085938, -7269.96875),
			Vector(1162.5906982422, 7392.7475585938, -7269.96875),
			Vector(1038.8153076172, 7444.4252929688, -7269.96875),
			Vector(1424.8541259766, 7145.6098632813, -7269.96875),
			Vector(1049.4576416016, 7161.4428710938, -7269.96875),
			Vector(1118.4812011719, 7449.1137695313, -7269.96875),			
		},
		available = function()
			local pos1 = Vector(1509,6738,-7368)
			local pos2 = Vector(940,7533,-7175)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "Evacuation Shelter",
		spawns = {
			Vector(4767.8813476563, 5605.5122070313, -7137.96875),
			Vector(4810.5913085938, 5565.3549804688, -7137.96875),
			Vector(4734.400390625, 5521.2973632813, -7137.96875),
			Vector(4851.3388671875, 5491.0551757813, -7137.96875),
			Vector(4791.626953125, 5505.1416015625, -7137.96875),
			Vector(4810.5341796875, 5350.126953125, -7137.96875),
			Vector(4766.8427734375, 5434.111328125, -7137.96875),
			Vector(4832.2900390625, 5418.2563476563, -7137.96875),
			Vector(4754.4052734375, 5185.4721679688, -7137.96875),					
		},
		available = function()
			local pos1 = Vector(4407,4936,-7166)
			local pos2 = Vector(4934,5671,-6620)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "LCZ Entrance",
		spawns = {
			Vector(4767.8813476563, 5605.5122070313, -7137.96875),
			Vector(4810.5913085938, 5565.3549804688, -7137.96875),
			Vector(4734.400390625, 5521.2973632813, -7137.96875),
			Vector(4851.3388671875, 5491.0551757813, -7137.96875),
			Vector(4791.626953125, 5505.1416015625, -7137.96875),
			Vector(4810.5341796875, 5350.126953125, -7137.96875),
			Vector(4766.8427734375, 5434.111328125, -7137.96875),
			Vector(4832.2900390625, 5418.2563476563, -7137.96875),
			Vector(4754.4052734375, 5185.4721679688, -7137.96875),					
		},
		available = function()
			local pos1 = Vector(-992,-590,-8355)
			local pos2 = Vector(-383,-1863,-7908)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
}

function BR2_Get_914_1_Pos()
	return Vector(709.000000, -832.000000, -8131.000000)
end

function BR2_Get_914_2_Pos()
	return Vector(710.289978, -832.000000, -8149.000000)
end

print("[Breach2] Shared mapconfig loaded!")
