
MAPCONFIG = {}

local music_lcz =           "sound/breach2/music/The Dread.ogg"
local music_hcz =           "sound/breach2/music/HeavyContainment.ogg"
local music_049 =           "sound/breach2/music/Room049.ogg"
local music_ez =            "sound/breach2/music/EntranceZone.ogg"
local music_end =           "sound/breach2/music/SatiateStrings.mp3"
local music_pd =            "sound/breach2/music/Night_Trench.ogg"

//lua_run_cl EmitSound(Sound("breach2/ambient/general/Ambient1.ogg"), Entity(1):GetPos(), 1, CHAN_AUTO, 1, 75, 0, 100)
local ambient_general = {
	"breach2/ambient/general/Ambient1.ogg",
	"breach2/ambient/general/Ambient2.ogg",
	"breach2/ambient/general/Ambient3.ogg",
	"breach2/ambient/general/Ambient4.ogg",
	"breach2/ambient/general/Ambient5.ogg",
	"breach2/ambient/general/Ambient6.ogg",
	"breach2/ambient/general/Ambient7.ogg",
	"breach2/ambient/general/Ambient8.ogg",
	"breach2/ambient/general/Ambient9.ogg",
	"breach2/ambient/general/Ambient10.ogg",
	"breach2/ambient/general/Ambient11.ogg",
	"breach2/ambient/general/Ambient12.ogg",
	"breach2/ambient/general/Ambient13.ogg",
	"breach2/ambient/general/Ambient14.ogg",
	"breach2/ambient/general/Ambient15.ogg",
}

local ambient_lcz = {
	"breach2/ambient/zone1/Ambient1.ogg",
	"breach2/ambient/zone1/Ambient2.ogg",
	"breach2/ambient/zone1/Ambient3.ogg",
	"breach2/ambient/zone1/Ambient4.ogg",
	"breach2/ambient/zone1/Ambient5.ogg",
	"breach2/ambient/zone1/Ambient6.ogg",
	"breach2/ambient/zone1/Ambient7.ogg",
	"breach2/ambient/zone1/Ambient8.ogg",
}

local ambient_hcz = {
	"breach2/ambient/zone2/Ambient1.ogg",
	"breach2/ambient/zone2/Ambient2.ogg",
	"breach2/ambient/zone2/Ambient3.ogg",
	"breach2/ambient/zone2/Ambient4.ogg",
	"breach2/ambient/zone2/Ambient5.ogg",
	"breach2/ambient/zone2/Ambient6.ogg",
	"breach2/ambient/zone2/Ambient7.ogg",
	"breach2/ambient/zone2/Ambient8.ogg",
	"breach2/ambient/zone2/Ambient9.ogg",
	"breach2/ambient/zone2/Ambient10.ogg",
	"breach2/ambient/zone2/Ambient11.ogg",
}

local ambient_ez = {
	"breach2/ambient/zone3/Ambient1.ogg",
	"breach2/ambient/zone3/Ambient2.ogg",
	"breach2/ambient/zone3/Ambient3.ogg",
	"breach2/ambient/zone3/Ambient4.ogg",
	"breach2/ambient/zone3/Ambient5.ogg",
	"breach2/ambient/zone3/Ambient6.ogg",
	"breach2/ambient/zone3/Ambient7.ogg",
	"breach2/ambient/zone3/Ambient8.ogg",
	"breach2/ambient/zone3/Ambient9.ogg",
	"breach2/ambient/zone3/Ambient10.ogg",
	"breach2/ambient/zone3/Ambient11.ogg",
	"breach2/ambient/zone3/Ambient12.ogg",
}

local ambient_pd = {

}

MAPCONFIG.EnableGamemodeMusic = true
MAPCONFIG.EnableAmbientSounds = true
MAPCONFIG.GeneralAmbientSounds = ambient_general
MAPCONFIG.CommotionSounds = {
	"breach2/intro/Commotion/Commotion1.ogg",
	"breach2/intro/Commotion/Commotion2.ogg",
	"breach2/intro/Commotion/Commotion3.ogg",
	"breach2/intro/Commotion/Commotion4.ogg",
	"breach2/intro/Commotion/Commotion5.ogg",
	"breach2/intro/Commotion/Commotion6.ogg",
	"breach2/intro/Commotion/Commotion7.ogg",
	"breach2/intro/Commotion/Commotion8.ogg",
	"breach2/intro/Commotion/Commotion9.ogg",
	"breach2/intro/Commotion/Commotion10.ogg",
	"breach2/intro/Commotion/Commotion11.mp3",
	"breach2/intro/Commotion/Commotion12.ogg",
	"breach2/intro/Commotion/Commotion13.mp3",
	"breach2/intro/Commotion/Commotion14.mp3",
	"breach2/intro/Commotion/Commotion15.mp3",
	"breach2/intro/Commotion/Commotion16.ogg",
	"breach2/intro/Commotion/Commotion17.ogg",
	"breach2/intro/Commotion/Commotion18.ogg",
	"breach2/intro/Commotion/Commotion19.ogg",
	"breach2/intro/Commotion/Commotion20.ogg",
	"breach2/intro/Commotion/Commotion21.ogg",
	"breach2/intro/Commotion/Commotion22.mp3",
	"breach2/intro/Commotion/Commotion23.ogg",
	"breach2/intro/Bang2.ogg",
	"breach2/intro/Bang3.ogg",
}
/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/Alarm2_1.ogg", 6},
	{"breach2/alarm/Alarm2_2.ogg", 5},
	{"breach2/alarm/Alarm2_3.ogg", 7},
	{"breach2/alarm/Alarm2_4.ogg", 10},
	{"breach2/alarm/Alarm2_5.ogg", 6},
	{"breach2/alarm/Alarm2_6.ogg", 8},
	{"breach2/alarm/Alarm2_7.ogg", 7},
	{"breach2/alarm/Alarm2_8.ogg", 4},
	{"breach2/alarm/Alarm2_9.ogg", 4},
	{"breach2/alarm/Alarm2_10.ogg", 15}
}
*/

/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/breach_alarm.ogg", 72},
}
MAPCONFIG.FirstSoundsLength = 72 // length of all of FirstSounds in seconds
*/

function DefaultTerminalCanSee(terminal)
	return (util.TraceLine({start = terminal.pos, endpos = terminal.pos + (EyePos() - terminal.pos):Angle():Forward() * 150}).Entity == LocalPlayer())
end

function CanSeeFrom(pos)
	return (util.TraceLine({start = pos, endpos = pos + (EyePos() - pos):Angle():Forward() * 150}).Entity == LocalPlayer())
end

MAPCONFIG.CAMERAS = {
	{name = "lcz_corridor_1", pos = Vector(1444,-112,-8020), ang = Angle(0,180,0)},
	{name = "lcz_corridor_2", pos = Vector(1581,-272,-8034), ang = Angle(0,0,0)},
	{name = "lcz_storage_room_1", pos = Vector(912,-585,-7967), ang = Angle(0,-90,0)},
	{name = "lcz_cont_room_scp012", pos = Vector(-1068,224,-8286), ang = Angle(0,180,0)},
	{name = "ez_checkpoint_1", pos = Vector(-179,-1500,-5977), ang = Angle(0,-32,0)},
	{name = "ez_cont_room_scp860", pos = Vector(1360,1613,-5999), ang = Angle(0,90,0)},

}

MAPCONFIG.TERMINALS = {
	/*
	{name = "t1", pos = Vector(2951,3032,-6094), canSee = DefaultTerminalCanSee},
	{name = "ez_cells_2_1", pos = Vector(-2562,2722,-7100), canSee = DefaultTerminalCanSee},
	{name = "ez_cells_2_2", pos = Vector(-2526,2722,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_1_1", pos = Vector(-2658,3158,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_1_2", pos = Vector(-2622,3158,-7100), canSee = DefaultTerminalCanSee},
	*/
	
// LCZ
	// OFFICES
	{name = "lcz_office_1_1", pos = Vector(-959,908,-8143), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_2", pos = Vector(-1012,1165,-8124), canSee = function() return CanSeeFrom(Vector(-1012,1151,-8125)) end},
	{name = "lcz_office_1_3", pos = Vector(-972,1165,-8124), canSee = function() return CanSeeFrom(Vector(-971,1151,-8125)) end},
	{name = "lcz_office_1_4", pos = Vector(-1034,1224,-8142), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_5", pos = Vector(-1034,1375,-8142), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_6", pos = Vector(-1213,1373,-8142), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_7", pos = Vector(-1214,1220,-8143), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_8", pos = Vector(-1213,1056,-8142), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_9", pos = Vector(-1249,1056,-8142), canSee = DefaultTerminalCanSee},
	{name = "lcz_office_1_10", pos = Vector(-1249,1373,-8142), canSee = DefaultTerminalCanSee},
	
	// STORAGE ROOMS
	{name = "lcz_storage_room_1", pos = Vector(1027,-559,-8141), canSee = DefaultTerminalCanSee},
	{name = "lcz_storage_room_2_1", pos = Vector(743,2156,-8142), canSee = DefaultTerminalCanSee},
	{name = "lcz_storage_room_2_2_1", pos = Vector(763,2001,-8139), canSee = DefaultTerminalCanSee},
	{name = "lcz_storage_room_2_2_2", pos = Vector(763,1980,-8139), canSee = DefaultTerminalCanSee},
	{name = "lcz_storage_room_2_2_3", pos = Vector(744,2051,-8112), canSee = DefaultTerminalCanSee},
	{name = "lcz_storage_room_2_2_4", pos = Vector(744,2028,-8112), canSee = DefaultTerminalCanSee},
	{name = "lcz_storage_room_3", pos = Vector(880,-1614,-8142), canSee = DefaultTerminalCanSee},
	
	// CONTAINMENT ROOMS
	{name = "lcz_cont_room_1_1", pos = Vector(-1980,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1981,-529,-8124)) end},
	{name = "lcz_cont_room_1_2", pos = Vector(-1940,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1940,-528,-8124)) end},
	{name = "lcz_cont_room_2_1", pos = Vector(494,212,-8123), canSee = function() return CanSeeFrom(Vector(478,212,-8124)) end},
	{name = "lcz_cont_room_2_2", pos = Vector(494,172,-8123), canSee = function() return CanSeeFrom(Vector(480,173,-8124)) end},
	{name = "lcz_cont_room_3_1", pos = Vector(1940,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1941,-1504,-8123)) end},
	{name = "lcz_cont_room_3_2", pos = Vector(1900,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1900,-1504,-8123)) end},
	{name = "lcz_cont_room_4", pos = Vector(720,796,-8142), canSee = DefaultTerminalCanSee},

	// CHECKPOINTS
	{name = "lcz_checkpoint_1_1", pos = Vector(-430,430,-8124), canSee = DefaultTerminalCanSee},
	{name = "lcz_checkpoint_1_2", pos = Vector(-430,466,-8124), canSee = DefaultTerminalCanSee},
	{name = "lcz_checkpoint_2_1", pos = Vector(-429,430,-8123), canSee = DefaultTerminalCanSee},
	{name = "lcz_checkpoint_2_2", pos = Vector(-429,466,-8123), canSee = DefaultTerminalCanSee},
	{name = "lcz_checkpoint_3_1_1", pos = Vector(1890,829,-8123), canSee = DefaultTerminalCanSee},
	{name = "lcz_checkpoint_3_1_2", pos = Vector(-2666,5155,-7355), canSee = DefaultTerminalCanSee},
	{name = "lcz_checkpoint_3_2_1", pos = Vector(-2736,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2735,5388,-7357)) end},
	{name = "lcz_checkpoint_3_2_2", pos = Vector(-2697,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2697,5392,-7356)) end},

//HCZ
	// CONTAINMENT ROOMS
	{name = "hcz_cont_room_1_1", pos = Vector(605,923,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_1_2", pos = Vector(605,887,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_2_1", pos = Vector(838,2301,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_2_2", pos = Vector(874,2301,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_3_1_1", pos = Vector(-2526,2724,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_3_1_2", pos = Vector(-2561,2724,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_3_2_1", pos = Vector(-2659,3156,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_3_2_2", pos = Vector(-2623,3156,-7100), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_4_1", pos = Vector(-3004,3722,-7108), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_4_2", pos = Vector(-3004,3686,-7107), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_5_1", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
	{name = "hcz_cont_room_5_2", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
	
	// CHECKPOINTS
	{name = "hcz_checkpoint_1_1", pos = Vector(-428,430,-7099), canSee = DefaultTerminalCanSee},
	{name = "hcz_checkpoint_1_2", pos = Vector(-428,466,-7099), canSee = DefaultTerminalCanSee},

//EZ
	// CHECKPOINTS
	{name = "ez_checkpoint_1_1_1", pos = Vector(1458,3470,-6076), canSee = DefaultTerminalCanSee},
	{name = "ez_checkpoint_1_1_2", pos = Vector(1458,3506,-6076), canSee = DefaultTerminalCanSee},
	{name = "ez_checkpoint_1_2", pos = Vector(633,3292,-6094), canSee = DefaultTerminalCanSee},
	
	// OFFICES
	{name = "ez_office_1", pos = Vector(459,4178,-6078), canSee = DefaultTerminalCanSee},
	{name = "ez_office_2", pos = Vector(219,1253,-6094), canSee = DefaultTerminalCanSee},
	{name = "ez_office_3_1", pos = Vector(-784,1860,-6029), canSee = DefaultTerminalCanSee},
	{name = "ez_office_3_2", pos = Vector(-790,1998,-6030), canSee = DefaultTerminalCanSee},
	{name = "ez_office_3_3", pos = Vector(-662,2001,-6030), canSee = DefaultTerminalCanSee},
	{name = "ez_office_3_4", pos = Vector(-664,1531,-6030), canSee = DefaultTerminalCanSee},
	{name = "ez_office_4_1", pos = Vector(705,2800,-6190), canSee = DefaultTerminalCanSee},
	{name = "ez_office_4_2", pos = Vector(751,2671,-6189), canSee = DefaultTerminalCanSee},
	{name = "ez_office_4_3", pos = Vector(619,2571,-6190), canSee = DefaultTerminalCanSee},


	
	// STORAGE ROOMS
	{name = "ez_storage_room_1", pos = Vector(-410,318,-5998), canSee = DefaultTerminalCanSee},
	{name = "ez_storage_room_2", pos = Vector(-367,3838,-6094), canSee = DefaultTerminalCanSee},

	/*
	{name = "xxxxxxx", pos = vvvvvvvvvvvvvvvvvvvv, canSee = DefaultTerminalCanSee},
	*/
}
// ulx strip ^ ; give breach_tool_terminalplacer
// lua_run Entity(1):SetPos(xxxxxxxxxxxxxxxxxxxxxx)

MAPCONFIG.ZONES = {}

MAPCONFIG.SPECIAL_MUSIC_ZONES = {
	{pos1 = Vector(465,-1144,-8222), pos2 = Vector(903,-520,-8065), sound = "breach2/music/914.ogg", length = 29.05, volume = 0.8}, // 914
	{pos1 = Vector(1592,-901,-8229), pos2 = Vector(2314,-1787,-8026), sound = "breach2/music/205.ogg", length = 40.5, volume = 0.8}, // 205
	{pos1 = Vector(3400,-7035,-8653), pos2 = Vector(4969,-5453,-8394), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, // 049 TUNNELS
	{pos1 = Vector(3637,261,-7459), pos2 = Vector(4658,-1082,-6809), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, // WARHEADS
	{pos1 = Vector(5370,366,-11672), pos2 = Vector(7569,-2400,-11324), sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 0.8}, // HCZ TUNNELS
	{pos1 = Vector(-912,2139,-16175), pos2 = Vector(2016,-899,-14578), sound = "breach2/music/PD.ogg", length = 27.03, volume = 1}, // PD
	{pos1 = Vector(14907,-15883,-2283), pos2 = Vector(10162,-10690,99), sound = "breach2/music/1499.ogg", length = 50, volume = 0.7}, // 1499
	{pos1 = Vector(-1003,-397,-8475), pos2 = Vector(-1592,235,-8317), sound = "breach2/music/012.ogg", length = 25.5, volume = 0.7}, // 012
}

//  name                       	First Position          	Second Position         	Color                music       fog     NVGmul		ambient       use general ambient
MAPCONFIG.ZONES.LCZ = {
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(-3999,-2473,-8672),
		pos2 						= Vector(3302,3060,-7732),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
	},
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(2466,2818,-7720),
		pos2 						= Vector(1830,2170,-6653),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
	},
}
MAPCONFIG.ZONES.HCZ = {
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(1786,7123,-7625),
		pos2 						= Vector(-4100,10,-6658),
		//music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
	},
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(2517,807,-7697),
		pos2 						= Vector(1806,1350,-7015),
		//music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
	},
	{
		name 						= "SCP-049's Tunnels",
		pos1 						= Vector(3400,-7035,-8653),
		pos2 						= Vector(4969,-5453,-8394),
		//music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		music 						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in SCP-049's Tunnels",
	},
	{
		name 						= "HCZ Tunnels",
		pos1 						= Vector(5370,366,-11672),
		pos2 						= Vector(7569,-2400,-11324),
		music 						= {sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Tunnel system",
	},
	{
		name 						= "HCZ Warheads",
		pos1 						= Vector(3637,261,-7459),
		pos2 						= Vector(4658,-1082,-6809),
		music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Warhead Control Room",
	},
}
MAPCONFIG.ZONES.ENTRANCEZONE = {
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(3961,5828,-6625),
		pos2 						= Vector(-2735,-2100,-4503),
		//music 						= {sound = "breach2/music/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
	},
}
MAPCONFIG.ZONES.POCKETDIMENSION = {
	{
		name 						= "Pocket Dimension",
		pos1 						= Vector(-912,2139,-16175),
		pos2 						= Vector(2016,-899,-14578),
		music 						= {sound = "breach2/music/PD.ogg", length = 27.03, volume = 1},
		ambients 					= ambient_pd,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(0,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in the Pocket Dimension",
	},
}
MAPCONFIG.ZONES.OUTSIDE = {
	{
		name 						= "Outside",
		pos1 						= Vector(4797,-2801,-1771),
		pos2 						= Vector(-7418,5765,1983),
		//music 						= {sound = "breach2/music/withinsight.ogg", length = 60.44, volume = 0.5},
		music						= nil,
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(255,0,255,50),
		sanity 						= 1,
		examine_info 				= "You are outside of the facility",
	},
}
MAPCONFIG.ZONES.FOREST = {
	{
		name 						= "Forest",
		pos1 						= Vector(12061,-15943,-3792),
		pos2 						= Vector(15048,-13022,-2633),
		music 						= nil,
		ambients 					= ambient_pd,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(70,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in a forest",
	},
}
MAPCONFIG.ZONES.SCP_1499 = {
	{
		name 						= "SCP-1499",
		pos1 						= Vector(14907,-15883,-2283),
		pos2 						= Vector(10162,-10690,99),
		music 						= {sound = "breach2/music/1499.ogg", length = 50, volume = 1},
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(150,0,0,50),
		sanity 						= -1,
		examine_info 				= "You are in an unknown world",
	},
}

MAPCONFIG.BUTTONS = {
//LCZ
	// skull
	{
		pos = Vector(-343.000000, -1591.000000, -8155.000000),
		level = 2,
		sounds = true
	},
	// 914
	{
		pos = Vector(384.000000, -958.500000, -8155.000000),
		level = 2,
		sounds = true
	},
	// 314
	{
		pos = Vector(-1824.000000, -705.500000, -8155.000000),
		level = 2,
		sounds = true
	},
	// checkpoint
	{
		pos = Vector(-688.000000, 504.000000, -8144.000000),
		level = 3,
		sounds = true
	},
	// checkpoint
	{
		pos = Vector(1928.000000, 1088.000000, -8144.000000),
		level = 3,
		sounds = true
	},
	// item room
	{
		pos = Vector(1128.000000, -757.000000, -8126.200195),
		level = 2,
		sounds = true
	},
	// item room
	{
		pos = Vector(1336.000000, 1931.000000, -8126.200195),
		level = 1,
		sounds = true
	},
	// item room
	{
		pos = Vector(1723.000000, -88.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	// item room
	{
		pos = Vector(-409.000000, -104.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	// item room
	{
		pos = Vector(2427.000000, -648.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	// armory room
	{
		pos = Vector(752.000000, -1515.000000, -8144.000000),
		level = 1,
		sounds = true
	},
	// checkpoint doors
	{
		pos = Vector(1835.000000, 696.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	// 13 room
	{
		pos = Vector(504.000000, 547.000000, -8144.000000),
		level = 1,
		sounds = true
	},
	// SCP 079
	{
		pos = Vector(-3952.000000, 4328.000000, -7107.500000),
		level = 3,
		sounds = true
	},
	//near SCP-173 doors
	{
		pos = Vector(-696.000000, 1685.000000, -7888.000000),
		level = 0,
		sounds = false,
		customcheck = function() return (game_state != GAMESTATE_PREPARING) end,
		
	},
	//914 1
	{
		pos = Vector(709.000000, -832.000000, -8131.000000),
		level = 0,
		sounds = false,
		customcheck = function()
			return false
		end,
	},
	//914 2
	{
		pos = Vector(710.289978, -832.000000, -8149.000000),
		level = 0,
		sounds = false,
		customcheck = function()
			return false
			//return BR2_Handle914_Start()
		end,
	},
	{
		pos = Vector(2795.000000, -680.000000, -8144.000000),
		level = 1,
		sounds = true
	},
//HCZ
	{
		pos = Vector(4169.000000, 1704.000000, -8555.000000),
		level = 0,
		code = 1234,
		sounds = false
	},
	//armory
	{
		pos = Vector(-2768.000000, 4248.000000, -7123.500000),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(-2408.000000, 2997.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(811.000000, 1896.000000, -7120.000000),
		level = 4,
		sounds = true
	},
	{
		pos = Vector(1491.000000, 576.000000, -7120.000000),
		level = 1,
		sounds = true
	},
	//682
	{
		pos = Vector(1930.000000, 4956.000000, -8939.250000),
		level = 1,
		sounds = true
	},
	//008
	{
		pos = Vector(3081.000000, 5032.000000, -8555.000000),
		level = 1,
		sounds = true
	},
	//checkpoint
	{
		pos = Vector(1200.000000, 3544.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	//checkpoint
	{
		pos = Vector(1928.000000, 1088.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(-1139.000000, 1016.000000, -7120.000000),
		level = 2,
		sounds = true
	},
	//checkpoint
	{
		pos = Vector(632.000000, 5408.000000, -7120.000000),
		level = 3,
		sounds = true
	},

//EZ
	//checkpoint
	{
		pos = Vector(1200.000000, 3544.000000, -6096.000000),
		level = 3,
		sounds = true
	},
	//checkpoint elevator
	{
		pos = Vector(1240.000000, 3808.000000, -6213.779785),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(699.000000, 3200.000000, -6096.000000),
		level = 1,
		sounds = true
	},
	{
		pos = Vector(277.000000, 4280.000000, -6080.000000),
		level = 2,
		sounds = true
	},
	{
		pos = Vector(-808.000000, 1515.000000, -6032.000000),
		level = 2,
		sounds = true
	},
	{
		pos = Vector(-357.000000, 4040.000000, -6096.000000),
		level = 1,
		sounds = true
	},
	{
		pos = Vector(-283.510010, 4040.000000, -6096.000000),
		level = 1,
		sounds = true
	},

	// big doors
	{
		pos = Vector(160.000000, -488.000000, -6099.250000),
		level = 3,
		sounds = true
	},
//OUTSIDE
	{
		pos = Vector(-1749.000000, -2440.000000, 560.000000),
		level = 2,
		sounds = true
	},
}

local pd_spawn_height = -15469
MAPCONFIG.POCKETDIMENSION_SPAWNS = {
	Vector(23.301473617554, -10.723201751709, pd_spawn_height),
	Vector(-18.240295410156, -42.02742767334, pd_spawn_height),
	Vector(-15.765701293945, 1.2051422595978, pd_spawn_height),
	Vector(42.893028259277, -56.13041305542, pd_spawn_height),
	Vector(28.208240509033, 38.836673736572, pd_spawn_height),
	Vector(79.399269104004, -18.306934356689, pd_spawn_height),
	Vector(-14.227056503296, 60.410781860352, pd_spawn_height),
	Vector(-45.420238494873, 35.765735626221, pd_spawn_height),
	Vector(-54.177387237549, -14.005828857422, pd_spawn_height),
	Vector(-54.228298187256, -57.058036804199, pd_spawn_height),
	Vector(3.9432487487793, -88.955764770508, pd_spawn_height),
	Vector(-90.107643127441, -16.603729248047, pd_spawn_height),
	Vector(-80.204605102539, 37.095993041992, pd_spawn_height),
	Vector(-46.530025482178, 85.437194824219, pd_spawn_height),
	Vector(68.469787597656, 35.14973449707, pd_spawn_height),
}


// Spawns in Class D's cells
MAPCONFIG.SPAWNS_CLASSD_CELLS = {
	Vector(-3602.939453125, 832.32720947266, -8046.96875),
	Vector(-3818.6428222656, 836.63403320313, -8046.96875),
	Vector(-3391.6364746094, 826.951171875, -8046.96875),
	Vector(-3187.87109375, 819.77954101563, -8046.96875),
	Vector(-2978.2719726563, 818.99493408203, -8046.96875),
	Vector(-2767.869140625, 823.73364257813, -8046.96875),
	Vector(-2764.4208984375, 300.34832763672, -8046.96875),
	Vector(-2968.7724609375, 301.01162719727, -8046.96875),
	Vector(-3186.3063964844, 296.73794555664, -8046.96875),
	Vector(-3385.3439941406, 298.82928466797, -8046.96875),
	Vector(-3605.9470214844, 293.82122802734, -8046.96875),
	Vector(-3811.1315917969, 294.30609130859, -8046.96875),
	Vector(2881.419921875, 3539.2512207031, -6118.96875),
	Vector(2656.3898925781, 3538.9228515625, -6118.96875),
	Vector(2450.6579589844, 3540.3696289063, -6118.96875),
	Vector(3355.2131347656, 3542.7080078125, -6118.96875),
	Vector(3743.865234375, 3526.2707519531, -6118.96875),
	Vector(3178.3542480469, 3154.4743652344, -6118.96875),
	Vector(3686.7014160156, 3344.9328613281, -6118.96875),
	Vector(3511.1938476563, 3346.1020507813, -6118.96875),
	Vector(1888.8702392578, 3346.3327636719, -6118.96875),
	Vector(2137.8823242188, 3354.8312988281, -6118.96875),
	Vector(2843.0903320313, 3300.5451660156, -6118.96875),
	Vector(2610.8374023438, 3332.7150878906, -6118.96875),
	Vector(-3706.0673828125, 464.80758666992, -8046.96875),
	Vector(-3604.4721679688, 461.24993896484, -8046.96875),
	Vector(-3711.3837890625, 665.58489990234, -8046.96875),
	Vector(-3573.3332519531, 689.86108398438, -8046.96875),
	Vector(-3482.9926757813, 469.52133178711, -8046.96875),
	Vector(-3445.1513671875, 665.87170410156, -8046.96875),
	Vector(-3348.6916503906, 464.94454956055, -8046.96875),
	Vector(-3307.9562988281, 655.20361328125, -8046.96875),
}

// Spawns in Light Containment Zone
MAPCONFIG.SPAWNS_LCZ = {
	Vector(-1847.2550048828, 694.06427001953, -8294.96875),
	Vector(-2252.6943359375, 1087.2055664063, -8038.96875),
	Vector(-1140.3791503906, 1241.3851318359, -8166.96875),
	Vector(-1192.3406982422, 930.40454101563, -8166.96875),
	Vector(-1362.9724121094, -162.78018188477, -8166.96875),
	Vector(-1429.1767578125, -844.38153076172, -8166.96875),
	Vector(-642.28723144531, -1212.1612548828, -8294.96875),
	Vector(-538.47265625, -830.07446289063, -8166.96875),
	Vector(-34.431125640869, -958.25274658203, -8166.96875),
	Vector(25.617729187012, -114.19427490234, -8166.96875),
	Vector(635.38543701172, -112.50624847412, -8166.96875),
	Vector(1164.5394287109, -279.38793945313, -8166.96875),
	Vector(1234.5776367188, 615.72033691406, -8166.96875),
	Vector(1790.9327392578, 588.81854248047, -8166.96875),
	Vector(497.71002197266, 670.62561035156, -8166.96875),
	Vector(-28.656272888184, 480.24255371094, -8166.96875),
	Vector(1302.3918457031, -1454.5146484375, -8166.96875),
	Vector(2098.9230957031, -1436.2882080078, -8166.96875),
	Vector(2467.4304199219, -115.8934173584, -8166.96875),
	Vector(1240.8343505859, -2214.7170410156, -8166.96875),
	Vector(-25.500885009766, -2156.1408691406, -8166.96875),
	Vector(-64.191612243652, -1528.6021728516, -8166.96875),
	Vector(-2230.0556640625, -607.42901611328, -8166.96875),
	Vector(-2312.0654296875, 642.35620117188, -8294.96875),
	Vector(-106.84334564209, 2610.0305175781, -8166.96875),
	Vector(667.28894042969, 2543.8637695313, -8166.96875),
	Vector(1249.8482666016, 2309.6809082031, -8166.96875),
	Vector(1089.7720947266, 1098.8056640625, -8166.96875),
	Vector(1237.0960693359, -1039.1477050781, -8166.96875),
	Vector(1996.7291259766, -1661.2569580078, -8166.96875),
	Vector(-778.05279541016, 2479.8603515625, -8166.96875),
	Vector(-1313.7080078125, 2505.2956542969, -8166.96875),
	Vector(-1145.7430419922, 1856.6237792969, -8166.96875),
}

// Spawns in Heavy Containment Zone
MAPCONFIG.SPAWNS_HCZ = {
	Vector(-229.45164489746, 5415.6357421875, -7142.96875),
	Vector(-34.579574584961, 4513.8549804688, -7142.9389648438),
	Vector(-65.567283630371, 3390.0900878906, -7142.96875),
	Vector(-242.3719329834, 2844.0532226563, -7142.96875),
	Vector(-727.64440917969, 2816.0270996094, -7142.96875),
	Vector(-640.83166503906, 2224.185546875, -7142.96875),
	Vector(-201.98260498047, 1564.6809082031, -7142.96875),
	Vector(-1340.513671875, 1556.2530517578, -7142.96875),
	Vector(-1328.5539550781, 300.65124511719, -7142.96875),
	Vector(1450.7679443359, 760.37139892578, -7142.96875),
	Vector(1449.0362548828, 1592.6616210938, -7142.96875),
	Vector(604.404296875, 1570.8133544922, -7142.96875),
	Vector(567.86090087891, 2208.0112304688, -7142.96875),
	Vector(1227.8106689453, 2854.2604980469, -7142.96875),
	Vector(599.8828125, 2835.3422851563, -7142.96875),
	Vector(-1456.8861083984, 2848.2329101563, -7142.96875),
	Vector(-1980.6506347656, 2894.2614746094, -7142.96875),
	Vector(-2005.0480957031, 3544.7360839844, -7142.96875),
	Vector(-1986.2637939453, 3985.7663574219, -7142.96875),
	Vector(-1297.5765380859, 4072.9167480469, -7142.96875),
	Vector(-714.16741943359, 4703.5786132813, -7142.96875),
	Vector(-683.48034667969, 5385.6171875, -7142.96875),
	Vector(-1334.5980224609, 5414.2983398438, -7142.96875),
	Vector(-1839.6965332031, 5403.45703125, -7142.96875),
	Vector(-2198.4543457031, 4964.2260742188, -7142.96875),
	Vector(-1691.0745849609, 4810.9208984375, -7222.9692382813),
	Vector(-2639.7568359375, 5442.1455078125, -7142.96875),
	Vector(-3248.5053710938, 5403.7099609375, -7142.96875),
	Vector(-697.38262939453, 3702.6547851563, -7142.96875),
}

// Spawns in Entrance Zone
MAPCONFIG.SPAWNS_ENTRANCEZONE = {
	Vector(-1565.7836914063, 4175.3637695313, -6116.96875),
	Vector(-1763.7423095703, 3452.2993164063, -6118.96875),
	Vector(-796.27001953125, 3603.15234375, -6454.96875),
	Vector(-1673.060546875, 2939.4575195313, -6118.96875),
	Vector(-1379.9200439453, 2340.6953125, -6118.96875),
	Vector(-998.01910400391, 1716.4814453125, -6116.96875),
	Vector(-365.74566650391, 2325.5678710938, -6116.96875),
	Vector(-156.95542907715, 1730.7175292969, -6116.96875),
	Vector(-487.99609375, 1119.5129394531, -6116.96875),
	Vector(-941.61828613281, 579.30517578125, -6116.96875),
	Vector(-479.76049804688, -88.985885620117, -6118.96875),
	Vector(345.12316894531, -143.07070922852, -6118.96875),
	Vector(344.85858154297, 1085.8997802734, -6116.96875),
	Vector(884.58813476563, 427.58923339844, -6116.96875),
	Vector(-819.69287109375, 2919.2250976563, -6118.96875),
	Vector(-932.40069580078, 4285.6020507813, -6118.96875),
	Vector(-333.63018798828, 4892.689453125, -6118.96875),
	Vector(335.54641723633, 3543.4794921875, -6116.96875),
	Vector(381.77563476563, 2953.4262695313, -6116.96875),
	Vector(903.72497558594, 2213.0893554688, -6116.96875),
	Vector(1540.0699462891, 2342.8303222656, -6116.96875),
	Vector(1659.8101806641, 2939.5070800781, -6116.96875),
	Vector(898.251953125, 2747.8112792969, -6116.96875),
	Vector(383.72244262695, 2298.6142578125, -6116.96875),
	Vector(381.57489013672, 1717.4852294922, -6116.96875),
	Vector(1501.6190185547, 1228.6151123047, -6118.96875),
}

// Where Chaos Insurgency spawns at the beginning of the round
MAPCONFIG.SPAWNS_CHAOSINSURGENCY = {
	Vector(-2099.0185546875, -1344.994140625, 537.03125),
	Vector(-2229.0087890625, -1331.1219482422, 537.03125),
	Vector(-2231.9868164063, -1163.3917236328, 537.03125),
	Vector(-2124.3815917969, -1208.7913818359, 537.03125),
	Vector(-2213.6059570313, -1012.6979370117, 537.03125),
	Vector(-2118.2182617188, -1026.197265625, 537.03125),
	Vector(-2206.7045898438, -858.07464599609, 537.03125),
	Vector(-2089.7861328125, -806.54547119141, 537.03125),
	Vector(-2217.3076171875, -686.15570068359, 537.03125),
	Vector(-2103.2646484375, -644.27142333984, 537.03125),
	Vector(-1961.6408691406, -204.6852722168, 529.03125),
	Vector(-1780.8138427734, -214.21249389648, 529.03125),
	Vector(-1751.7730712891, -403.45465087891, 529.03125),
	Vector(-1885.3139648438, -350.78588867188, 529.03125),
	Vector(-1957.9162597656, -438.12219238281, 529.03125),
	Vector(-1851.7183837891, -467.14834594727, 529.03125),
	Vector(-1750.6444091797, -651.08081054688, 529.03125),
	Vector(-1948.6833496094, -657.30352783203, 529.03125),
	Vector(-1610.1857910156, -739.37475585938, 537.03125),
	Vector(-1606.4963378906, -901.81842041016, 537.03125),
	Vector(-1611.0314941406, -1051.2098388672, 537.03125),
}

// SCP 173's spawns
MAPCONFIG.SPAWNS_SCP_173 = {
	Vector(-189.662064, 1955.437500, -8063.968750),
}

// SCP 049's spawns
MAPCONFIG.SPAWNS_SCP_049 = {
	Vector(4180.052734375, -6376.6708984375, -8582.96875),
	Vector(4086.451171875, -6439.6264648438, -8582.96875),
	Vector(4181.0200195313, -6440.6103515625, -8582.96875),
	Vector(4256.5708007813, -6396.4174804688, -8582.96875),
}

// SCP 106's spawn
MAPCONFIG.SPAWNS_SCP_106 = {
	Vector(-2648.6215820313, 5988.0205078125, -7590.96875),
	Vector(-2725.8474121094, 6045.0874023438, -7590.96875),
	Vector(-2653.0478515625, 6108.3359375, -7590.96875),
	Vector(-2737.5017089844, 6180.2817382813, -7590.96875),
	Vector(-2661.3217773438, 6233.98046875, -7590.96875),
}

// SCP 457's spawn
MAPCONFIG.SPAWNS_SCP_457 = {
	Vector(-2557.9653320313, 2914.3310546875, -7142.96875),
	Vector(-2605.4235839844, 2929.216796875, -7142.96875),
	Vector(-2541.8579101563, 2977.3583984375, -7142.96875),
	Vector(-2609.3569335938, 3002.3344726563, -7142.96875),
}

// SCP 966's spawn
MAPCONFIG.SPAWNS_SCP_966 = {
	Vector(-620.36407470703, 4211.275390625, -7142.96875),
	Vector(-621.71295166016, 4155.294921875, -7142.96875),
	Vector(-627.49792480469, 4095.4323730469, -7142.96875),
	Vector(-694.38372802734, 4100.6928710938, -7142.96875),
	Vector(-692.74670410156, 4166.3852539063, -7142.96875),
	Vector(-719.65667724609, 4215.8100585938, -7142.96875),
	Vector(-754.56024169922, 4148.9951171875, -7142.96875),
	Vector(-773.86547851563, 4095.3076171875, -7142.96875),
}

// SCP 035's spawn
MAPCONFIG.SPAWNS_SCP_035 = {
	Vector(775.32934570313, 1026.5482177734, -7142.96875),
}


// Spawns for other SCPs
MAPCONFIG.SPAWNS_SCP_OTHERS = {
	Vector(3503.2019042969, 3131.4350585938, 25.03125),
	Vector(3573.8725585938, 3114.5197753906, 25.03125),
	Vector(3423.3481445313, 3131.9501953125, 25.03125),
}

// Where Mobile Task Force spawns when they arrive in the facility
MAPCONFIG.SPAWNS_MTF = {
	Vector(-2381.4770507813, 6582.6596679688, 17.03125),
	Vector(-2389.5932617188, 6511.0981445313, 17.03125),
	Vector(-2475.4885253906, 6488.34375, 17.031242370605),
	Vector(-2450.8845214844, 6561.8374023438, 17.031257629395),
	Vector(-2543.849609375, 6524.529296875, 17.03125),
	Vector(-2512.2526855469, 6591.1538085938, 17.03125),
	Vector(-2455.0300292969, 6614.2426757813, 17.03125),
}

// Where Chaos Insurgency Support spawns when they arrive in the facility
MAPCONFIG.SPAWNS_CI_SUPPORT = {
	{
		Vector(-3757.8835449219, 1944.2198486328, -993.96875),
		Vector(-3711.6059570313, 1950.0505371094, -993.96875),
		Vector(-3753.4326171875, 1877.7825927734, -993.96875),
		Vector(-3700.7150878906, 1887.1597900391, -993.96875),
		Vector(-3693.6279296875, 1837.2171630859, -993.96875),
		Vector(-3747.2951660156, 1820.1141357422, -993.96875),
		Vector(-3789.1911621094, 1991.3436279297, -986),
		Vector(-3843.2177734375, 2046.4963378906, -986),
		Vector(-3738.1215820313, 2042.1231689453, -993.96875),
		Vector(-3800.9094238281, 2072.2543945313, -986),
		Vector(-3692.2644042969, 2001.1401367188, -993.96875),
	},
	{
		Vector(-6997.2368164063, 5052.294921875, -1185.96875),
		Vector(-6938.3720703125, 5052.9506835938, -1185.96875),
		Vector(-6885.9399414063, 5053.7583007813, -1185.96875),
		Vector(-6836.9033203125, 5056.3525390625, -1185.96875),
		Vector(-6789.0537109375, 5053.4443359375, -1185.96875),
		Vector(-6731.525390625, 5052.9291992188, -1185.96875),
		Vector(-6681.4672851563, 5043.8110351563, -1185.96875),
		Vector(-6686.9536132813, 4981.359375, -1185.96875),
		Vector(-6752.5234375, 4985.537109375, -1185.96875),
		Vector(-6793.2104492188, 4986.5297851563, -1185.96875),
		Vector(-6858.6372070313, 4989.9975585938, -1185.96875),
		Vector(-6908.6596679688, 4986.8334960938, -1185.96875),
		Vector(-6958.2875976563, 4978.224609375, -1185.96875),
		Vector(-6985.4887695313, 4930.4345703125, -1185.96875),
		Vector(-6914.9848632813, 4916.3642578125, -1185.96875),
		Vector(-6852.330078125, 4925.095703125, -1185.96875),
		Vector(-6795.1953125, 4926.0063476563, -1185.96875),
		Vector(-6739.9125976563, 4928.724609375, -1185.96875),
		Vector(-6666.0771484375, 4912.9096679688, -1185.96875),
		Vector(-6662.7534179688, 4856.7065429688, -1185.96875),
		Vector(-6741.4838867188, 4869.775390625, -1185.96875),
		Vector(-6804.4106445313, 4871.4243164063, -1185.96875),
		Vector(-6870.8676757813, 4867.0581054688, -1185.96875),
		Vector(-6919.8579101563, 4865.6630859375, -1185.96875),
		Vector(-6969.8852539063, 4850.3842773438, -1185.96875),
	}
}

MAPCONFIG.Starting_Corpses_Number = function()
	return table.Count(MAPCONFIG.STARTING_CORPSES) - 4 - math.random(0,10)
end

//lua_run Entity(1):SetPos(MAPCONFIG.STARTING_CORPSES[1].ragdoll_pos)
MAPCONFIG.STARTING_CORPSES = {
	//LCZ
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		role = function() return "SD Officer" end,
		ragdoll_pos = Vector(2996.009765625,3031.3657226563,-6136.9877929688),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(2988.7392578125,3034.15625,-6139.0952148438),
				ang = Angle(-12.403450012207,141.86366271973,104.34604644775),
			},
			{
				pos = Vector(2986.0620117188,3036.255859375,-6138.2529296875),
				ang = Angle(1.7282491922379,143.35963439941,102.67205047607),
			},
			{
				pos = Vector(2976.5563964844,3041.3464355469,-6137.0825195313),
				ang = Angle(-2.20818567276,-111.61856079102,184.77702331543),
			},
			{
				pos = Vector(2979.1789550781,3044.3120117188,-6137.9047851563),
				ang = Angle(27.901218414307,82.057762145996,0.21129763126373),
			},
			{
				pos = Vector(2979.6276855469,3049.5883789063,-6140.2045898438),
				ang = Angle(-2.3984019756317,22.825824737549,231.64454650879),
			},
			{
				pos = Vector(2990.2651367188,3054.0681152344,-6140.2397460938),
				ang = Angle(-5.443323135376,137.88751220703,172.39117431641),
			},
			{
				pos = Vector(2981.8891601563,3061.6372070313,-6139.1284179688),
				ang = Angle(37.454532623291,104.99224853516,276.96746826172),
			},
			{
				pos = Vector(2974.3666992188,3035.7995605469,-6136.861328125),
				ang = Angle(21.970205307007,-70.895835876465,258.40728759766),
			},
			{
				pos = Vector(2977.875,3025.6733398438,-6141.0239257813),
				ang = Angle(-0.74489533901215,-67.912803649902,263.90280151367),
			},
			{
				pos = Vector(2982.1389160156,3015.1625976563,-6140.8408203125),
				ang = Angle(0.99295890331268,-66.790008544922,174.6159362793),
			},
			{
				pos = Vector(2994.5358886719,3027.8012695313,-6137.0151367188),
				ang = Angle(8.795654296875,-15.888725280762,269.98797607422),
			},
			{
				pos = Vector(3011.2939453125,3023.0302734375,-6139.6508789063),
				ang = Angle(2.0117328166962,-20.701248168945,269.37268066406),
			},
			{
				pos = Vector(2997.4650878906,3034.9169921875,-6137.4580078125),
				ang = Angle(7.051474571228,-11.405141830444,268.89398193359),
			},
			{
				pos = Vector(3014.6201171875,3031.4565429688,-6139.615234375),
				ang = Angle(2.1852288246155,-16.499919891357,270.02215576172),
			},
			{
				pos = Vector(2974.259765625,3045.7043457031,-6136.3833007813),
				ang = Angle(20.81326675415,140.70384216309,231.27806091309),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(-2398.7629394531,4278.9067382813,-6139.859375),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-2400.0588378906,4283.873046875,-6129.232421875),
				ang = Angle(-77.355598449707,164.34320068359,35.07540512085),
			},
			{
				pos = Vector(-2406.6071777344,4281.2036132813,-6122.0107421875),
				ang = Angle(74.47053527832,-175.22886657715,206.56790161133),
			},
			{
				pos = Vector(-2396.1083984375,4284.6323242188,-6120.0249023438),
				ang = Angle(69.280120849609,-2.9938538074493,6.8846769332886),
			},
			{
				pos = Vector(-2391.9533691406,4284.904296875,-6130.4150390625),
				ang = Angle(67.784606933594,-35.53816986084,336.07431030273),
			},
			{
				pos = Vector(-2388.6193847656,4282.4267578125,-6140.6704101563),
				ang = Angle(13.430978775024,-38.477764129639,93.879539489746),
			},
			{
				pos = Vector(-2409.4931640625,4280.9301757813,-6132.65234375),
				ang = Angle(56.819633483887,-135.55841064453,243.34938049316),
			},
			{
				pos = Vector(-2413.8728027344,4276.6352539063,-6142.0336914063),
				ang = Angle(-12.152237892151,-148.11581420898,93.889114379883),
			},
			{
				pos = Vector(-2402.5161132813,4280.6796875,-6140.5717773438),
				ang = Angle(0.83202230930328,-92.431625366211,338.51654052734),
			},
			{
				pos = Vector(-2402.9301757813,4264.673828125,-6140.8334960938),
				ang = Angle(-1.1796069145203,-95.373115539551,337.74801635742),
			},
			{
				pos = Vector(-2402.3825683594,4283.1689453125,-6115.9194335938),
				ang = Angle(-64.433921813965,-32.240463256836,56.93176651001),
			},
			{
				pos = Vector(-2395.3701171875,4277.2041015625,-6138.4838867188),
				ang = Angle(-13.263107299805,-101.56935882568,295.9573059082),
			},
			{
				pos = Vector(-2398.6928710938,4262.078125,-6135.0122070313),
				ang = Angle(20.155689239502,-84.960708618164,296.02383422852),
			},
			{
				pos = Vector(-2397.2326660156,4245.5170898438,-6141.1147460938),
				ang = Angle(-56.640613555908,-94.461120605469,285.37432861328),
			},
			{
				pos = Vector(-2404.5861816406,4247.0458984375,-6140.6333007813),
				ang = Angle(4.4843783378601,-144.84716796875,351.57485961914),
			},
		},
	},
	{
		items = {},
		model = "models/player/kerry/class_scientist_3.mdl",
		ragdoll_pos = Vector(3126.1013183594,935.50396728516,-6137.4228515625),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(3121.1662597656,925.58050537109,-6133.5791015625),
				ang = Angle(-74.754447937012,-116.58850860596,92.854522705078),
			},
			{
				pos = Vector(3125.9189453125,922.50091552734,-6125.2260742188),
				ang = Angle(77.463897705078,15.971989631653,239.43574523926),
			},
			{
				pos = Vector(3115.4924316406,927.10717773438,-6125.3784179688),
				ang = Angle(78.75284576416,128.60018920898,336.95108032227),
			},
			{
				pos = Vector(3114.1337890625,928.80383300781,-6136.2905273438),
				ang = Angle(33.764972686768,69.045913696289,282.52056884766),
			},
			{
				pos = Vector(3117.4575195313,937.50079345703,-6142.2602539063),
				ang = Angle(-14.624017715454,105.56902313232,59.584339141846),
			},
			{
				pos = Vector(3128.2680664063,923.13012695313,-6136.0424804688),
				ang = Angle(34.64155960083,41.62427520752,262.29626464844),
			},
			{
				pos = Vector(3135.1220703125,929.27276611328,-6142.3291015625),
				ang = Angle(8.6986141204834,55.920246124268,243.76319885254),
			},
			{
				pos = Vector(3129.52734375,934.53179931641,-6135.6381835938),
				ang = Angle(12.106468200684,72.458595275879,258.86135864258),
			},
			{
				pos = Vector(3134.2307128906,949.40606689453,-6138.9814453125),
				ang = Angle(2.8437020778656,74.271423339844,259.11679077148),
			},
			{
				pos = Vector(3120.201171875,923.83044433594,-6120.1953125),
				ang = Angle(-61.205715179443,130.74827575684,30.095951080322),
			},
			{
				pos = Vector(3122.6740722656,936.46978759766,-6139.1513671875),
				ang = Angle(3.4390923976898,82.928161621094,235.20971679688),
			},
			{
				pos = Vector(3124.6311035156,952.25115966797,-6140.0903320313),
				ang = Angle(-1.0351902246475,85.940689086914,235.30732727051),
			},
			{
				pos = Vector(3125.8879394531,969.91033935547,-6139.4418945313),
				ang = Angle(-16.132024765015,128.01330566406,212.41857910156),
			},
			{
				pos = Vector(3139.0256347656,966.43145751953,-6139.8598632813),
				ang = Angle(-32.475891113281,67.979133605957,269.42797851563),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(-59.506031036377,5128.4716796875,-6137.3520507813),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-53.917171478271,5126.0791015625,-6127.66015625),
				ang = Angle(-59.426723480225,90.332298278809,288.47909545898),
			},
			{
				pos = Vector(-51.136772155762,5132.6293945313,-6122.671875),
				ang = Angle(75.874526977539,95.848587036133,205.05407714844),
			},
			{
				pos = Vector(-59.772323608398,5129.7373046875,-6120.3110351563),
				ang = Angle(55.492847442627,-135.17425537109,41.026020050049),
			},
			{
				pos = Vector(-64.331512451172,5125.1977539063,-6129.4223632813),
				ang = Angle(60.328968048096,-147.51956176758,30.58934211731),
			},
			{
				pos = Vector(-68.928153991699,5122.2954101563,-6139.1884765625),
				ang = Angle(19.812965393066,-173.20469665527,111.21530914307),
			},
			{
				pos = Vector(-50.504749298096,5135.3305664063,-6133.3920898438),
				ang = Angle(58.61653137207,140.61682128906,248.91468811035),
			},
			{
				pos = Vector(-55.041084289551,5139.0102539063,-6141.8779296875),
				ang = Angle(-9.5467720031738,121.00373077393,93.927139282227),
			},
			{
				pos = Vector(-56.580787658691,5130.9409179688,-6138.2880859375),
				ang = Angle(7.3436489105225,117.37508392334,281.29827880859),
			},
			{
				pos = Vector(-63.522060394287,5144.552734375,-6139.9189453125),
				ang = Angle(-2.251327753067,116.03591918945,276.24523925781),
			},
			{
				pos = Vector(-54.464809417725,5132.4790039063,-6117.04296875),
				ang = Angle(-28.25609588623,85.16618347168,121.04462432861),
			},
			{
				pos = Vector(-62.201023101807,5125.642578125,-6136.21875),
				ang = Angle(-22.922517776489,126.3314666748,264.67590332031),
			},
			{
				pos = Vector(-70.389678955078,5136.7260742188,-6129.1909179688),
				ang = Angle(33.557109832764,119.94194030762,263.58987426758),
			},
			{
				pos = Vector(-77.755722045898,5149.5141601563,-6138.9799804688),
				ang = Angle(2.1814730167389,125.14196777344,264.40795898438),
			},
			{
				pos = Vector(-71.284851074219,5160.4560546875,-6139.8090820313),
				ang = Angle(-61.216484069824,109.18083953857,280.64352416992),
			},
		},
	},
	//LCZ
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(637.54510498047,-2304.3479003906,-8184.7416992188),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(648.72265625,-2301.6186523438,-8187.5708007813),
				ang = Angle(5.2561612129211,30.903385162354,59.313236236572),
			},
			{
				pos = Vector(652.75897216797,-2292.7041015625,-8189.7114257813),
				ang = Angle(-2.0434975624084,-168.06559753418,339.33416748047),
			},
			{
				pos = Vector(658.21954345703,-2300.8278808594,-8184.380859375),
				ang = Angle(24.859712600708,-27.522806167603,277.61566162109),
			},
			{
				pos = Vector(667.15771484375,-2305.4653320313,-8188.7973632813),
				ang = Angle(6.4799246788025,-29.882139205933,277.15063476563),
			},
			{
				pos = Vector(676.80389404297,-2311.0512695313,-8190.2080078125),
				ang = Angle(9.1264448165894,-34.390453338623,5.8338932991028),
			},
			{
				pos = Vector(641.87847900391,-2294.9816894531,-8189.7387695313),
				ang = Angle(-4.0346755981445,29.337316513062,20.542446136475),
			},
			{
				pos = Vector(651.63189697266,-2289.5212402344,-8188.8872070313),
				ang = Angle(28.759553909302,15.857275009155,241.30589294434),
			},
			{
				pos = Vector(636.53625488281,-2303.7614746094,-8188.6215820313),
				ang = Angle(0.80581188201904,120.91152954102,3.9188158512115),
			},
			{
				pos = Vector(628.32757568359,-2290.0881347656,-8189.099609375),
				ang = Angle(0.64397221803665,126.82075500488,4.6090550422668),
			},
			{
				pos = Vector(659.89288330078,-2293.9829101563,-8187.4096679688),
				ang = Angle(15.130532264709,44.661087036133,216.37094116211),
			},
			{
				pos = Vector(638.55316162109,-2304.9311523438,-8181.05078125),
				ang = Angle(15.406332015991,166.31196594238,346.51623535156),
			},
			{
				pos = Vector(623.64587402344,-2301.2937011719,-8185.4248046875),
				ang = Angle(14.150602340698,161.2109375,345.32391357422),
			},
			{
				pos = Vector(607.38354492188,-2295.7631835938,-8189.4838867188),
				ang = Angle(5.8404836654663,87.006042480469,345.58984375),
			},
			{
				pos = Vector(617.71459960938,-2275.9140625,-8189.119140625),
				ang = Angle(1.9495137929916,74.5751953125,1.7740613222122),
			},
		},
	},
	{
		items = {},
		model = "models/player/group01/male_05.mdl",
		ragdoll_pos = Vector(591.29138183594,1164.9251708984,-8184.2534179688),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(591.73358154297,1163.6568603516,-8188.115234375),
				ang = Angle(-3.837993144989,-121.94661712646,190.50291442871),
			},
			{
				pos = Vector(582.30200195313,1148.5544433594,-8186.8916015625),
				ang = Angle(6.2452139854431,-175.23620605469,189.23017883301),
			},
			{
				pos = Vector(590.16192626953,1166.3099365234,-8180.9008789063),
				ang = Angle(14.400524139404,-165.99238586426,196.43096923828),
			},
			{
				pos = Vector(573.39837646484,1162.1170654297,-8185.3706054688),
				ang = Angle(11.086074829102,-155.55979919434,198.75811767578),
			},
			{
				pos = Vector(558.63598632813,1155.4020996094,-8188.3247070313),
				ang = Angle(6.4265780448914,-127.74687194824,201.45909118652),
			},
			{
				pos = Vector(602.63970947266,1165.9207763672,-8183.3286132813),
				ang = Angle(-27.007614135742,-14.659473419189,178.0284576416),
			},
			{
				pos = Vector(613.38629150391,1161.4197998047,-8186.0454101563),
				ang = Angle(15.03663444519,-50.417881011963,347.93231201172),
			},
			{
				pos = Vector(620.57720947266,1152.7270507813,-8188.8076171875),
				ang = Angle(8.9180469512939,-74.698432922363,343.05004882813),
			},
			{
				pos = Vector(606.60650634766,1163.4987792969,-8172.158203125),
				ang = Angle(21.358768463135,-158.2593536377,150.49920654297),
			},
			{
				pos = Vector(596.49145507813,1159.4653320313,-8176.4169921875),
				ang = Angle(35.822750091553,-98.549324035645,181.45207214355),
			},
			{
				pos = Vector(595.10748291016,1150.2590332031,-8183.13671875),
				ang = Angle(65.71947479248,-119.92518615723,63.528957366943),
			},
			{
				pos = Vector(615.00030517578,1159.9488525391,-8176.361328125),
				ang = Angle(-2.0118939876556,-29.598968505859,24.608106613159),
			},
			{
				pos = Vector(623.57171630859,1141.7777099609,-8190.732421875),
				ang = Angle(-33.843631744385,-72.247848510742,92.83943939209),
			},
			{
				pos = Vector(565.93310546875,1147.1892089844,-8188.5053710938),
				ang = Angle(6.9850997924805,-101.14942169189,187.3893737793),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(7.9047756195068,2100.0532226563,-7932.134765625),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(9.6974067687988,2102.328125,-7920.8559570313),
				ang = Angle(-63.007354736328,-82.743667602539,231.18479919434),
			},
			{
				pos = Vector(4.6543207168579,2100.2143554688,-7912.3828125),
				ang = Angle(67.291275024414,142.47521972656,136.82669067383),
			},
			{
				pos = Vector(13.901361465454,2095.0187988281,-7915.6083984375),
				ang = Angle(71.164093017578,-113.47463989258,259.01266479492),
			},
			{
				pos = Vector(12.648014068604,2091.7231445313,-7926.1279296875),
				ang = Angle(42.456142425537,-107.89792633057,264.2262878418),
			},
			{
				pos = Vector(10.106781959534,2083.8581542969,-7933.4780273438),
				ang = Angle(1.8504493236542,-59.320163726807,54.422622680664),
			},
			{
				pos = Vector(1.1787810325623,2102.8500976563,-7922.6455078125),
				ang = Angle(71.77808380127,160.07315063477,153.22915649414),
			},
			{
				pos = Vector(-2.0742080211639,2104.0341796875,-7933.1567382813),
				ang = Angle(3.4691753387451,147.39013671875,94.111473083496),
			},
			{
				pos = Vector(5.2073636054993,2103,-7931.4096679688),
				ang = Angle(-0.81316941976547,-131.14793395996,312.77731323242),
			},
			{
				pos = Vector(-5.2476496696472,2091.0043945313,-7931.62890625),
				ang = Angle(3.2125968933105,-126.57040405273,309.16098022461),
			},
			{
				pos = Vector(9.616021156311,2095.0529785156,-7909.4453125),
				ang = Angle(-52.072193145752,-44.240612030029,35.724151611328),
			},
			{
				pos = Vector(10.614122390747,2097.1306152344,-7930.2026367188),
				ang = Angle(-1.6060577630997,-120.29285430908,274.64611816406),
			},
			{
				pos = Vector(2.6858849525452,2083.4897460938,-7930.5190429688),
				ang = Angle(8.1966018676758,-118.83068847656,275.98461914063),
			},
			{
				pos = Vector(-5.767795085907,2068.1342773438,-7933.1879882813),
				ang = Angle(-64.162284851074,-112.01744842529,266.6911315918),
			},
			{
				pos = Vector(-15.781659126282,2076.8032226563,-7932.6704101563),
				ang = Angle(-38.879600524902,156.91792297363,345.77206420898),
			},
		},
	},
	{
		items = {},
		model = "models/player/kerry/class_scientist_4.mdl",
		ragdoll_pos = Vector(-1446.5700683594,98.546539306641,-8440.666015625),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-1445.8609619141,86.844505310059,-8442.404296875),
				ang = Angle(3.967437505722,-82.838706970215,32.76123046875),
			},
			{
				pos = Vector(-1440.6525878906,79.624496459961,-8446.1591796875),
				ang = Angle(-3.3196487426758,79.54940032959,2.8535978794098),
			},
			{
				pos = Vector(-1446.7708740234,78.119338989258,-8437.3701171875),
				ang = Angle(-19.13819694519,106.49582672119,356.17822265625),
			},
			{
				pos = Vector(-1449.7551269531,88.19506072998,-8433.7236328125),
				ang = Angle(-2.7446930408478,12.758682250977,19.315351486206),
			},
			{
				pos = Vector(-1438.8360595703,90.667518615723,-8433.1875),
				ang = Angle(44.29615020752,44.81664276123,127.45336151123),
			},
			{
				pos = Vector(-1438.6397705078,90.545402526855,-8445.6953125),
				ang = Angle(-3.6995136737823,67.891120910645,3.8971807956696),
			},
			{
				pos = Vector(-1434.4370117188,100.89678192139,-8444.923828125),
				ang = Angle(27.96332359314,74.211685180664,277.78454589844),
			},
			{
				pos = Vector(-1447.2790527344,98.8544921875,-8444.58203125),
				ang = Angle(1.0306934118271,26.588632583618,2.2532203197479),
			},
			{
				pos = Vector(-1433.0272216797,105.98824310303,-8444.87109375),
				ang = Angle(-0.56283301115036,64.642112731934,2.4126129150391),
			},
			{
				pos = Vector(-1442.8516845703,73.65119934082,-8442.47265625),
				ang = Angle(28.361265182495,-84.27766418457,195.28065490723),
			},
			{
				pos = Vector(-1445.7615966797,98.630126953125,-8436.4990234375),
				ang = Angle(19.120790481567,76.581001281738,359.86245727539),
			},
			{
				pos = Vector(-1442.2668457031,113.27964782715,-8441.720703125),
				ang = Angle(14.581467628479,118.3823928833,12.50622177124),
			},
			{
				pos = Vector(-1450.412109375,128.35903930664,-8446.142578125),
				ang = Angle(1.0933673381805,69.724067687988,353.14526367188),
			},
			{
				pos = Vector(-1425.4450683594,121.99460601807,-8444.6572265625),
				ang = Angle(6.1372232437134,-16.810995101929,359.2785949707),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(-902.65545654297,350.66751098633,-8160.9174804688),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-901.61602783203,354.40493774414,-8161.3818359375),
				ang = Angle(33.641716003418,-9.3754186630249,266.32940673828),
			},
			{
				pos = Vector(-886.93933105469,351.98379516602,-8171.2314453125),
				ang = Angle(86.221015930176,-133.3565826416,144.03857421875),
			},
			{
				pos = Vector(-903.63928222656,346.91995239258,-8160.9116210938),
				ang = Angle(34.345371246338,-12.976126670837,268.13290405273),
			},
			{
				pos = Vector(-889.35150146484,343.6123046875,-8171.1030273438),
				ang = Angle(88.4736328125,-117.03644561768,164.94776916504),
			},
			{
				pos = Vector(-889.54479980469,343.20797729492,-8187.3579101563),
				ang = Angle(33.48263168335,-14.284553527832,270.3063659668),
			},
			{
				pos = Vector(-913.13623046875,353.79644775391,-8157.8989257813),
				ang = Angle(-41.238422393799,127.13764953613,151.28935241699),
			},
			{
				pos = Vector(-915.75524902344,365.41989135742,-8156.5087890625),
				ang = Angle(47.106025695801,-83.635383605957,171.12953186035),
			},
			{
				pos = Vector(-914.95141601563,357.66741943359,-8164.7016601563),
				ang = Angle(2.9964442253113,15.428301811218,226.55680847168),
			},
			{
				pos = Vector(-916.25958251953,353.80477905273,-8146.3388671875),
				ang = Angle(19.84592628479,-0.10962476581335,251.92030334473),
			},
			{
				pos = Vector(-905.01153564453,353.73086547852,-8150.009765625),
				ang = Angle(21.613229751587,-0.42261910438538,251.62576293945),
			},
			{
				pos = Vector(-894.52783203125,353.69522094727,-8154.4111328125),
				ang = Angle(47.650485992432,-1.9889045953751,101.54173278809),
			},
			{
				pos = Vector(-917.65545654297,363.62170410156,-8146.9438476563),
				ang = Angle(-22.812826156616,101.06672668457,8.2220516204834),
			},
			{
				pos = Vector(-903.79534912109,360.62423706055,-8165.552734375),
				ang = Angle(8.9938793182373,16.456817626953,355.45654296875),
			},
			{
				pos = Vector(-887.66979980469,351.19995117188,-8187.3579101563),
				ang = Angle(33.482685089111,3.3252489566803,270.30642700195),
			},
		},
	},
	//HCZ
	{
		items = {},
		model = "models/player/kerry/class_scientist_2.mdl",
		ragdoll_pos = Vector(-491.42666625977,2303.353515625,-7145.0795898438),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-490.0647277832,2304.2016601563,-7141.5234375),
				ang = Angle(0.63982361555099,-54.890106201172,327.599609375),
			},
			{
				pos = Vector(-480.01278686523,2289.7958984375,-7141.603515625),
				ang = Angle(28.506906509399,65.42586517334,15.817079544067),
			},
			{
				pos = Vector(-491.97640991211,2302.1682128906,-7148.8686523438),
				ang = Angle(-2.3065760135651,-58.869342803955,355.77377319336),
			},
			{
				pos = Vector(-483.08840942383,2287.1867675781,-7148.0625),
				ang = Angle(4.0163621902466,23.404880523682,356.65481567383),
			},
			{
				pos = Vector(-467.96615600586,2293.8603515625,-7149.1137695313),
				ang = Angle(-1.13509953022,-35.894561767578,357.70858764648),
			},
			{
				pos = Vector(-501.70443725586,2308.1057128906,-7143.3881835938),
				ang = Angle(-44.833034515381,-135.96417236328,348.57287597656),
			},
			{
				pos = Vector(-500.59170532227,2305.1743164063,-7131.8002929688),
				ang = Angle(28.274583816528,17.15376663208,332.16146850586),
			},
			{
				pos = Vector(-490.69073486328,2308.3354492188,-7137.1772460938),
				ang = Angle(24.413101196289,8.3221206665039,328.47897338867),
			},
			{
				pos = Vector(-509.03381347656,2299.9523925781,-7142.5400390625),
				ang = Angle(28.188409805298,-79.017707824707,238.25196838379),
			},
			{
				pos = Vector(-507.89401245117,2289.6801757813,-7147.7119140625),
				ang = Angle(29.46081161499,-76.57999420166,240.25559997559),
			},
			{
				pos = Vector(-505.57366943359,2280.0939941406,-7153.6171875),
				ang = Angle(63.603618621826,-90.078491210938,80.935989379883),
			},
			{
				pos = Vector(-507.875,2298.5048828125,-7133.068359375),
				ang = Angle(-41.080200195313,-95.500526428223,121.26920318604),
			},
			{
				pos = Vector(-480.38955688477,2309.6708984375,-7142.064453125),
				ang = Angle(67.12230682373,-3.9730355739594,67.016418457031),
			},
			{
				pos = Vector(-473.96670532227,2302.9504394531,-7149.4770507813),
				ang = Angle(5.8625836372375,-6.0021996498108,337.61087036133),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(-3006.1364746094,3422.5251464844,-7168.740234375),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-3013.2470703125,3431.8403320313,-7170.2729492188),
				ang = Angle(2.0708627700806,174.07862854004,19.566465377808),
			},
			{
				pos = Vector(-3021.6467285156,3429.63671875,-7174.3637695313),
				ang = Angle(-14.691973686218,-54.719123840332,9.9616060256958),
			},
			{
				pos = Vector(-3021.5881347656,3433.33984375,-7164.9057617188),
				ang = Angle(10.953682899475,-62.229885101318,10.938424110413),
			},
			{
				pos = Vector(-3016.5620117188,3423.5354003906,-7166.9677734375),
				ang = Angle(14.950093269348,-124.45715332031,355.68646240234),
			},
			{
				pos = Vector(-3022.6228027344,3414.7377929688,-7169.7978515625),
				ang = Angle(59.218803405762,-166.1251373291,35.882595062256),
			},
			{
				pos = Vector(-3015.5070800781,3420.9304199219,-7172.1811523438),
				ang = Angle(0.071497790515423,-115.7091293335,20.333856582642),
			},
			{
				pos = Vector(-3020.2690429688,3410.8020019531,-7171.9794921875),
				ang = Angle(4.4570636749268,-100.27513122559,342.68923950195),
			},
			{
				pos = Vector(-3006.1677246094,3421.8615722656,-7172.5903320313),
				ang = Angle(0.9358948469162,-130.91069030762,359.77655029297),
			},
			{
				pos = Vector(-3016.6311035156,3409.8376464844,-7173.12890625),
				ang = Angle(0.53407824039459,-75.508193969727,0.8479238152504),
			},
			{
				pos = Vector(-3026.7849121094,3431.7216796875,-7170.3515625),
				ang = Angle(23.340379714966,170.08348083496,176.94467163086),
			},
			{
				pos = Vector(-3006.0905761719,3423.1787109375,-7164.9970703125),
				ang = Angle(15.560496330261,-84.099922180176,353.86669921875),
			},
			{
				pos = Vector(-3004.5192871094,3407.9013671875,-7169.2739257813),
				ang = Angle(14.952845573425,-89.286003112793,352.52249145508),
			},
			{
				pos = Vector(-3004.2719726563,3390.7700195313,-7173.5190429688),
				ang = Angle(7.2675156593323,-123.23680114746,346.83184814453),
			},
			{
				pos = Vector(-3012.2312011719,3392.7150878906,-7173.05859375),
				ang = Angle(2.2951791286469,-109.2029800415,1.9513244628906),
			},
		},
	},
	{
		items = {},
		model = "models/player/kerry/class_scientist_6.mdl",
		ragdoll_pos = Vector(-1494.6535644531,4663.2016601563,-7160.9272460938),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-1505.7045898438,4665.1430664063,-7158.7294921875),
				ang = Angle(-6.8955459594727,-113.91299438477,299.71130371094),
			},
			{
				pos = Vector(-1515.1203613281,4658.8115234375,-7162.4423828125),
				ang = Angle(13.549436569214,-156.82066345215,163.91249084473),
			},
			{
				pos = Vector(-1502.4775390625,4654.2138671875,-7155.015625),
				ang = Angle(20.547336578369,-52.286609649658,34.475112915039),
			},
			{
				pos = Vector(-1495.8139648438,4645.4409179688,-7158.9130859375),
				ang = Angle(36.924587249756,-142.0503692627,343.26455688477),
			},
			{
				pos = Vector(-1503.0489501953,4639.8413085938,-7165.6796875),
				ang = Angle(-24.646404266357,-139.85479736328,91.447044372559),
			},
			{
				pos = Vector(-1525.5668945313,4654.3481445313,-7164.6982421875),
				ang = Angle(8.9108982086182,-45.221534729004,196.88034057617),
			},
			{
				pos = Vector(-1517.5905761719,4646.3134765625,-7167.2763671875),
				ang = Angle(-44.019317626953,-45.334045410156,86.693809509277),
			},
			{
				pos = Vector(-1495.4350585938,4664.1176757813,-7164.3896484375),
				ang = Angle(-1.102441906929,-85.344123840332,354.92715454102),
			},
			{
				pos = Vector(-1493.880859375,4646.3090820313,-7164.3110351563),
				ang = Angle(3.7508268356323,4.5544896125793,358.75241088867),
			},
			{
				pos = Vector(-1510.7259521484,4650.6098632813,-7159.1831054688),
				ang = Angle(23.303056716919,-122.83492279053,112.34210968018),
			},
			{
				pos = Vector(-1493.8919677734,4662.2983398438,-7156.7392578125),
				ang = Angle(17.389423370361,-30.702842712402,350.16900634766),
			},
			{
				pos = Vector(-1479.365234375,4653.6049804688,-7162.4360351563),
				ang = Angle(10.880977630615,57.215915679932,16.343151092529),
			},
			{
				pos = Vector(-1470.5715332031,4667.091796875,-7165.4545898438),
				ang = Angle(-1.7178107500076,11.807980537415,356.86926269531),
			},
			{
				pos = Vector(-1477.4432373047,4647.6166992188,-7164.9584960938),
				ang = Angle(3.3025016784668,-54.94486618042,359.79733276367),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(-2060.240234375,4662.9580078125,-7544.25390625),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-2062.9318847656,4651.6806640625,-7546.634765625),
				ang = Angle(2.6416239738464,-138.24143981934,123.83038330078),
			},
			{
				pos = Vector(-2066.5793457031,4643.080078125,-7542.8422851563),
				ang = Angle(31.141906738281,-1.1795741319656,204.74591064453),
			},
			{
				pos = Vector(-2072.6325683594,4650.341796875,-7548.49609375),
				ang = Angle(-1.3537460565567,87.864273071289,212.5525970459),
			},
			{
				pos = Vector(-2072.2102050781,4661.4418945313,-7548.48828125),
				ang = Angle(-6.8061327934265,94.025505065918,213.81207275391),
			},
			{
				pos = Vector(-2072.9892578125,4672.537109375,-7547.1459960938),
				ang = Angle(36.313297271729,137.4660949707,324.66265869141),
			},
			{
				pos = Vector(-2057.0681152344,4642.8793945313,-7548.318359375),
				ang = Angle(-2.0738866329193,50.140739440918,218.09745788574),
			},
			{
				pos = Vector(-2049.8857421875,4651.478515625,-7547.8881835938),
				ang = Angle(9.0826721191406,47.879020690918,93.443969726563),
			},
			{
				pos = Vector(-2057.0583496094,4661.7905273438,-7542.396484375),
				ang = Angle(13.823818206787,67.941589355469,231.41474914551),
			},
			{
				pos = Vector(-2051.2468261719,4676.1420898438,-7546.1064453125),
				ang = Angle(6.6185479164124,73.667755126953,232.1707611084),
			},
			{
				pos = Vector(-2073.5817871094,4643.3618164063,-7546.0180664063),
				ang = Angle(24.363119125366,-147.5223236084,320.43927001953),
			},
			{
				pos = Vector(-2063.4208984375,4664.1372070313,-7546.4638671875),
				ang = Angle(2.7905468940735,72.181976318359,227.17805480957),
			},
			{
				pos = Vector(-2058.5480957031,4679.2963867188,-7547.1025390625),
				ang = Angle(-0.46372440457344,74.96134185791,227.63717651367),
			},
			{
				pos = Vector(-2053.9516601563,4696.3984375,-7547.0776367188),
				ang = Angle(-20.630186080933,140.1282043457,197.69645690918),
			},
			{
				pos = Vector(-2046.3065185547,4693.013671875,-7548.0346679688),
				ang = Angle(-58.195945739746,84.439315795898,247.65950012207),
			},
		},
	},
	{
		items = {},
		model = "models/player/group01/male_09.mdl",
		ragdoll_pos = Vector(-1900.6605224609,4102.2529296875,-7160.1259765625),
		ragdoll_ang = Angle(0,0,0),
		ragdoll_vel = Vector(0,0,-0),
		bones = {
			{
				pos = Vector(-1909.7568359375,4095.7590332031,-7158.2646484375),
				ang = Angle(-58.39860534668,153.49838256836,137.32620239258),

			},
			{
				pos = Vector(-1910.8905029297,4091.5769042969,-7147.0893554688),
				ang = Angle(45.102153778076,-44.934242248535,169.78337097168),

			},
			{
				pos = Vector(-1914.3010253906,4105.2583007813,-7152.7783203125),
				ang = Angle(57.497131347656,45.659660339355,260.00296020508),

			},
			{
				pos = Vector(-1910.3298339844,4109.7626953125,-7162.8364257813),
				ang = Angle(14.030281066895,51.298439025879,264.82357788086),
			},
			{
				pos = Vector(-1903.3621826172,4118.4624023438,-7165.4487304688),
				ang = Angle(-20.183506011963,100.91172790527,34.301895141602),
			},
			{
				pos = Vector(-1905.0443115234,4085.7443847656,-7155.3706054688),
				ang = Angle(44.949771881104,-45.782569885254,168.86233520508),
			},
			{
				pos = Vector(-1899.3581542969,4079.9172363281,-7163.2333984375),
				ang = Angle(30.821075439453,-119.86078643799,326.19088745117),
			},
			{
				pos = Vector(-1898.9178466797,4100.9145507813,-7157.1372070313),
				ang = Angle(15.22790145874,-9.8274841308594,180.85185241699),
			},
			{
				pos = Vector(-1881.9819335938,4098.0048828125,-7161.7856445313),
				ang = Angle(12.603260040283,-42.708808898926,172.03561401367),
			},
			{
				pos = Vector(-1914.3604736328,4100.3447265625,-7144.4106445313),
				ang = Angle(-78.935577392578,56.488925933838,70.139862060547),
			},
			{
				pos = Vector(-1902.4061279297,4103.5834960938,-7164.00390625),
				ang = Angle(2.1381049156189,12.939368247986,188.44848632813),
			},
			{
				pos = Vector(-1884.9993896484,4107.5180664063,-7164.4174804688),
				ang = Angle(3.1143627166748,5.8152523040771,187.7935333252),
			},
			{
				pos = Vector(-1868.5880126953,4109.1953125,-7164.7954101563),
				ang = Angle(4.1855306625366,81.37134552002,182.06855773926),
			},
			{
				pos = Vector(-1870.1351318359,4087.1271972656,-7165.2080078125),
				ang = Angle(0.21913979947567,-6.8567757606506,187.12420654297),
			},
		},
	},
	{
		items = {},
		model = "models/redninja/pmedic02.mdl",
		ragdoll_pos = Vector(2293.67578125,2995.376953125,-7163.1743164063),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(2295.5649414063,2996.8891601563,-7152.083984375),
				ang = Angle(-28.818260192871,177.25630187988,293.54806518555),
			},
			{
				pos = Vector(2285.8620605469,3003.9060058594,-7151.4868164063),
				ang = Angle(12.205494880676,0.64498883485794,88.349411010742),
			},
			{
				pos = Vector(2288.1569824219,2989.6157226563,-7146.09375),
				ang = Angle(58.149971008301,-27.587446212769,28.78479385376),
			},
			{
				pos = Vector(2293.6760253906,2986.6616210938,-7155.943359375),
				ang = Angle(41.697608947754,-122.80651092529,308.51821899414),
			},
			{
				pos = Vector(2288.9494628906,2979.5654296875,-7163.4545898438),
				ang = Angle(6.147647857666,-112.28588867188,83.029006958008),
			},
			{
				pos = Vector(2297.3076171875,3004.078125,-7153.955078125),
				ang = Angle(66.646255493164,-175.03466796875,274.32089233398),
			},
			{
				pos = Vector(2292.7229003906,3003.5822753906,-7163.8774414063),
				ang = Angle(0.8825455904007,154.99263000488,95.835517883301),
			},
			{
				pos = Vector(2291.8044433594,2998.9213867188,-7162.75),
				ang = Angle(6.4080581665039,-162.78018188477,269.98190307617),
			},
			{
				pos = Vector(2274.8920898438,2993.6091308594,-7164.7485351563),
				ang = Angle(-1.3567217588425,-162.94789123535,270.03283691406),
			},
			{
				pos = Vector(2281.0910644531,2996.53515625,-7146.884765625),
				ang = Angle(2.498202085495,168.5198059082,116.99150848389),
			},
			{
				pos = Vector(2295.5405273438,2991.8500976563,-7162.7436523438),
				ang = Angle(6.6159448623657,-144.63961791992,267.57730102539),
			},
			{
				pos = Vector(2281.0502929688,2981.6188964844,-7164.6000976563),
				ang = Angle(0.16213785111904,-144.19996643066,268.18969726563),
			},
			{
				pos = Vector(2267.6418457031,2971.9594726563,-7164.7885742188),
				ang = Angle(-44.086585998535,-143.53053283691,266.22463989258),
			},
			{
				pos = Vector(2259.099609375,2988.7634277344,-7164.5180664063),
				ang = Angle(-37.100280761719,-164.23976135254,273.85614013672),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(-1006.1834106445,5718.6284179688,-7163.2880859375),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-1009.5742797852,5719.1118164063,-7152.517578125),
				ang = Angle(-27.745517730713,-67.963188171387,304.14633178711),
			},
			{
				pos = Vector(-1010.7595825195,5707.2143554688,-7153.1450195313),
				ang = Angle(82.718910217285,-115.99932861328,203.94630432129),
			},
			{
				pos = Vector(-1000.4822387695,5715.7553710938,-7145.4750976563),
				ang = Angle(56.16869354248,37.588459014893,36.511627197266),
			},
			{
				pos = Vector(-995.32653808594,5719.6684570313,-7155.0268554688),
				ang = Angle(26.102445602417,-79.97046661377,299.78485107422),
			},
			{
				pos = Vector(-993.53558349609,5709.5297851563,-7160.029296875),
				ang = Angle(72.184135437012,-133.51118469238,19.918079376221),
			},
			{
				pos = Vector(-1011.5576782227,5705.8530273438,-7164.5576171875),
				ang = Angle(7.2094140052795,-51.200305938721,263.10559082031),
			},
			{
				pos = Vector(-1004.2991333008,5697.0385742188,-7166.0151367188),
				ang = Angle(-30.714405059814,-73.417266845703,113.87232208252),
			},
			{
				pos = Vector(-1008.3532104492,5715.5693359375,-7163.70703125),
				ang = Angle(3.5079638957977,-62.587257385254,279.21255493164),
			},
			{
				pos = Vector(-1000.1426391602,5699.8217773438,-7164.6279296875),
				ang = Angle(1.5862256288528,-63.017311096191,280.76919555664),
			},
			{
				pos = Vector(-1002.7760620117,5706.2827148438,-7147.3989257813),
				ang = Angle(2.9258995056152,-74.422576904297,118.0428314209),
			},
			{
				pos = Vector(-1004.0029907227,5722.154296875,-7162.693359375),
				ang = Angle(6.1433644294739,-23.612203598022,272.28723144531),
			},
			{
				pos = Vector(-987.76666259766,5714.9736328125,-7164.314453125),
				ang = Angle(4.1433272361755,-23.578279495239,272.015625),
			},
			{
				pos = Vector(-972.64892578125,5708.3818359375,-7165.6826171875),
				ang = Angle(-62.466781616211,-17.240867614746,263.84246826172),
			},
			{
				pos = Vector(-992.64764404297,5685.09375,-7165.3212890625),
				ang = Angle(-58.057476043701,-72.359634399414,269.24392700195),
			},
		},
	},
	{
		items = {},
		model = "models/player/kerry/class_scientist_1.mdl",
		ragdoll_pos = Vector(-3032.998046875,6632.75390625,-7416.8129882813),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(-3041.9748535156,6640.0610351563,-7419.5302734375),
				ang = Angle(5.6628699302673,126.37722015381,114.91022491455),
			},
			{
				pos = Vector(-3050.7629394531,6644.2241210938,-7416.7841796875),
				ang = Angle(23.585899353027,-88.766868591309,212.8913269043),
			},
			{
				pos = Vector(-3042.1623535156,6649.9584960938,-7421.1811523438),
				ang = Angle(-0.26221242547035,1.3357691764832,221.25340270996),
			},
			{
				pos = Vector(-3031.0471191406,6650.2114257813,-7421.3715820313),
				ang = Angle(-5.1274046897888,6.9858860969543,221.69458007813),
			},
			{
				pos = Vector(-3019.9711914063,6651.5668945313,-7420.3364257813),
				ang = Angle(34.340202331543,55.389743804932,330.97705078125),
			},
			{
				pos = Vector(-3050.5427246094,6634.0380859375,-7420.9321289063),
				ang = Angle(5.4389462471008,-63.58837890625,218.69146728516),
			},
			{
				pos = Vector(-3045.576171875,6624.044921875,-7422.2631835938),
				ang = Angle(14.356736183167,-113.26078796387,186.82041931152),
			},
			{
				pos = Vector(-3034.3635253906,6632.2583007813,-7413.5224609375),
				ang = Angle(18.190212249756,-65.574478149414,190.51962280273),
			},
			{
				pos = Vector(-3028.09765625,6618.4721679688,-7418.4140625),
				ang = Angle(12.815611839294,-148.74111938477,163.86738586426),
			},
			{
				pos = Vector(-3049.4501953125,6651.3413085938,-7419.2592773438),
				ang = Angle(18.437311172485,111.15252685547,316.58786010742),
			},
			{
				pos = Vector(-3031.6259765625,6633.2568359375,-7420.9458007813),
				ang = Angle(-7.3792471885681,-18.219415664673,185.07211303711),
			},
			{
				pos = Vector(-3016.6096191406,6628.3149414063,-7418.8994140625),
				ang = Angle(6.4454426765442,-119.42559051514,186.20529174805),
			},
			{
				pos = Vector(-3025.2502441406,6612.9868164063,-7420.65625),
				ang = Angle(8.6706638336182,-81.114471435547,186.14169311523),
			},
			{
				pos = Vector(-3042.8552246094,6609.5234375,-7422.2817382813),
				ang = Angle(-1.0966184139252,-105.20430755615,183.33148193359),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(930.53533935547,1917.9123535156,-7161.3359375),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(937.58489990234,1909.9632568359,-7157.5654296875),
				ang = Angle(-66.619522094727,49.083633422852,15.789189338684),
			},
			{
				pos = Vector(941.14697265625,1919.8035888672,-7152.0346679688),
				ang = Angle(79.557113647461,-81.495162963867,74.801605224609),
			},
			{
				pos = Vector(935.85382080078,1907.3498535156,-7146.1254882813),
				ang = Angle(36.629768371582,154.732421875,322.42251586914),
			},
			{
				pos = Vector(927.10858154297,1910.9216308594,-7153.0107421875),
				ang = Angle(36.99337387085,153.69442749023,322.13687133789),
			},
			{
				pos = Vector(919.11767578125,1915.0205078125,-7159.8208007813),
				ang = Angle(66.674255371094,161.30238342285,94.953132629395),
			},
			{
				pos = Vector(941.81970214844,1917.705078125,-7163.5297851563),
				ang = Angle(12.558699607849,113.9090423584,273.32034301758),
			},
			{
				pos = Vector(937.26452636719,1927.9411621094,-7165.8627929688),
				ang = Angle(9.3536071777344,114.54901885986,244.91270446777),
			},
			{
				pos = Vector(933.41772460938,1920.5257568359,-7161.44921875),
				ang = Angle(10.318885803223,132.10456848145,259.53280639648),
			},
			{
				pos = Vector(921.64508056641,1933.5522460938,-7164.5483398438),
				ang = Angle(0.12860982120037,133.98738098145,259.72695922852),
			},
			{
				pos = Vector(939.17114257813,1915.6662597656,-7143.3647460938),
				ang = Angle(-42.15518951416,77.90209197998,148.99374389648),
			},
			{
				pos = Vector(927.65600585938,1915.3018798828,-7161.7182617188),
				ang = Angle(9.4160947799683,132.32774353027,274.09915161133),
			},
			{
				pos = Vector(915.80407714844,1928.318359375,-7164.3505859375),
				ang = Angle(4.2545161247253,131.9402923584,273.79205322266),
			},
			{
				pos = Vector(904.78051757813,1940.5780029297,-7165.6899414063),
				ang = Angle(-62.599803924561,139.00256347656,263.81494140625),
			},
			{
				pos = Vector(910.1748046875,1945.4334716797,-7164.310546875),
				ang = Angle(-30.742967605591,124.87591552734,273.45159912109),
			},
		},
	},
	{
		items = {},
		model = "models/redninja/pmedic01.mdl",
		ragdoll_pos = Vector(4147.5346679688,-6974.3828125,-8601.349609375),
		ragdoll_ang = Angle(0,0,0),
		bones = {
			{
				pos = Vector(4143.8876953125,-6985.1782226563,-8602.7177734375),
				ang = Angle(-67.77897644043,-92.800537109375,101.81086730957),
			},
			{
				pos = Vector(4151.1162109375,-6986.2880859375,-8593.228515625),
				ang = Angle(73.244934082031,11.767335891724,207.95327758789),
			},
			{
				pos = Vector(4135.869140625,-6988.4716796875,-8594.40625),
				ang = Angle(86.186401367188,24.749681472778,189.07446289063),
			},
			{
				pos = Vector(4136.4345703125,-6988.2192382813,-8605.2451171875),
				ang = Angle(-1.018119096756,105.73988342285,265.56185913086),
			},
			{
				pos = Vector(4133.4379882813,-6977.115234375,-8605.3955078125),
				ang = Angle(6.0682525634766,157.53092956543,354.53155517578),
			},
			{
				pos = Vector(4154.4145507813,-6985.6088867188,-8604.375),
				ang = Angle(8.983247756958,70.284248352051,255.06811523438),
			},
			{
				pos = Vector(4158.2451171875,-6974.939453125,-8606.181640625),
				ang = Angle(-35.170181274414,55.756008148193,105.69472503662),
			},
			{
				pos = Vector(4151.0141601563,-6975.693359375,-8600.50390625),
				ang = Angle(13.081686019897,57.157375335693,249.69296264648),
			},
			{
				pos = Vector(4160.4140625,-6961.0805664063,-8604.2841796875),
				ang = Angle(3.7434077262878,60.560882568359,249.99687194824),
			},
			{
				pos = Vector(4143.1669921875,-6988.21484375,-8587.7099609375),
				ang = Angle(-68.640937805176,161.97775268555,3.8866143226624),
			},
			{
				pos = Vector(4144.060546875,-6973.0815429688,-8603.0302734375),
				ang = Angle(5.1192011833191,77.518043518066,241.1385345459),
			},
			{
				pos = Vector(4147.9311523438,-6955.7373046875,-8604.50390625),
				ang = Angle(-0.23854108154774,80.451667785645,241.22625732422),
			},
			{
				pos = Vector(4150.666015625,-6939.4384765625,-8604.48046875),
				ang = Angle(-45.534645080566,85.021240234375,248.85589599609),
			},
			{
				pos = Vector(4168.5209960938,-6946.7124023438,-8605.4248046875),
				ang = Angle(-56.91869354248,45.332885742188,277.52136230469),
			},
		},
	},
	{
		items = {},
		model = "models/fart/ragdolls/css/counter_gign_player.mdl",
		ragdoll_pos = Vector(131.22093200684,4055.638671875,-7163.1850585938),
		ragdoll_ang = Angle(0,0,0),
		ragdoll_vel = Vector(0,0,-0),
		bones = {
			{
				pos = Vector(130.5161895752,4053.0341796875,-7152.1655273438),
				ang = Angle(-29.799089431763,115.57074737549,244.41180419922),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(134.39321899414,4062.4411621094,-7145.8115234375),
				ang = Angle(42.95361328125,-51.931098937988,130.14794921875),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(120.38278198242,4059.4138183594,-7151.6025390625),
				ang = Angle(32.643367767334,-110.11183929443,59.154373168945),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(116.99269104004,4050.1606445313,-7157.9077148438),
				ang = Angle(40.076622009277,111.57874298096,304.31527709961),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(113.76221466064,4058.3212890625,-7164.8081054688),
				ang = Angle(18.506553649902,54.008018493652,322.74160766602),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(139.73599243164,4055.7182617188,-7153.7705078125),
				ang = Angle(61.755958557129,0.57009822130203,173.23263549805),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(145.20210266113,4055.7294921875,-7163.5209960938),
				ang = Angle(47.478481292725,109.56727600098,238.89288330078),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(135.20248413086,4055.2106933594,-7162.7534179688),
				ang = Angle(6.4132885932922,73.851890563965,269.63345336914),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(140.08720397949,4072.2861328125,-7164.7934570313),
				ang = Angle(-1.808101773262,73.692001342773,269.46435546875),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(125.35635375977,4066.4509277344,-7146.6860351563),
				ang = Angle(1.5650831460953,123.64300537109,62.068771362305),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(127.25123596191,4056.0544433594,-7162.728515625),
				ang = Angle(6.3324122428894,97.181022644043,267.75183105469),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(125.09233093262,4073.6279296875,-7164.6557617188),
				ang = Angle(-0.59720343351364,97.552040100098,268.04116821289),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(122.9256362915,4090.0070800781,-7164.5869140625),
				ang = Angle(-38.631484985352,98.052635192871,266.1809387207),
				vel = Vector(0,0,-0),
			},
			{
				pos = Vector(144.7170715332,4088.1350097656,-7164.2431640625),
				ang = Angle(-28.186065673828,73.513496398926,273.15719604492),
				vel = Vector(0,0,-0),
			},
		},
	}
}

br2_914_on_map = true

function BR2_Get_914_1_Pos()
	return Vector(709.000000, -832.000000, -8131.000000)
end

function BR2_Get_914_2_Pos()
	return Vector(710.289978, -832.000000, -8149.000000)
end

function BR2_Get914Status()
	local skip_ents = {}
	
	for k,v in pairs(ents.GetAll()) do
		if v:GetPos() == Vector(709.000000, -832.000000, -8131.000000) then
			table.ForceInsert(skip_ents, v)
		end
	end
	
	local pos_tab = {
		{
			st = Vector(711.968750, -823.241089, -8130.947754),
			en = Vector(711.968750, -826.715942, -8130.899902)
		},
		{
			st = Vector(711.968750, -825.751526, -8124.646484),
			en = Vector(711.968750, -828.398987, -8127.150391)
		},
		{
			st = Vector(711.968750, -832.023193, -8121.808105),
			en = Vector(711.968750, -831.989441, -8125.920898)
		},
		{
			st = Vector(711.968750, -838.231140, -8124.668457),
			en = Vector(711.968750, -835.565186, -8127.099121)
		},
		{
			st = Vector(711.968750, -840.952881, -8130.949707),
			en = Vector(711.968750, -837.019043, -8130.874512)
		},
	}
	
	for i,v in ipairs(pos_tab) do
		local tr = util.TraceLine({
			start = v.st,
			endpos = v.en,
			mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE,
			filter = skip_ents
		})
		if tr.Hit == true then
			return i
		end
	end
	return 0
end

function BR2_Get_914_Enter_Entities()
	local pos1 = Vector(737,-678,-8190)
	local pos2 = Vector(804,-541,-8080)
	OrderVectors(pos1, pos2)
	local ents_found = {}
	for k,v in pairs(ents.FindInBox(pos1, pos2)) do
		if v.GetBetterOne or v:IsPlayer() then
			table.ForceInsert(ents_found, v)
		end
	end
	return ents_found
end

function BR2_914_End_Stage()
	timer.Create("BR2_914_NextStage", 11, 1, function()
		br2_914_disabled = false
	end)
end

br2_914_disabled = false
function BR2_Handle914_Start()
	if br2_914_disabled == true then
		return false
	else
		br2_914_disabled = true
		timer.Create("BR2_914_NextStage", 4, 1, function()
			br_914status = BR2_Get914Status()
			for k,v in pairs(BR2_Get_914_Enter_Entities()) do
				v:SetPos(Vector(768.773560, -1062.487549, -8190.468750))
				if v:IsPlayer() then
					v:Kill()
				elseif isfunction(v.GetBetterOne) then
					local better_one = v:GetBetterOne()
					if isstring(better_one) then
						local ent = ents.Create(better_one)
						if IsValid(ent) then
							ent:SetPos(v:GetPos())
							ent:Spawn()
							ent:SetNWBool("isDropped", true)
						end
						if ent:GetClass() == "item_radio2" then
							for _,bt in pairs(MAPCONFIG.BUTTONS) do
								if ent.Code == nil and isnumber(bt.code) and bt.code_type == "radio" then
									ent.Code = bt.code
								end
							end
						end
					end
					v:Remove()
				end
			end
			BR2_914_End_Stage()
		end)
		return true
	end
end

function SpawnMapNPCs()
	local npc_tab = {
		//{"npc_cpt_scp_173", Vector(-183.948669, 1345.252441, -8063.968750)},
		//{"npc_cpt_scp_096", Vector(129.172226, 4132.813477, -7167.968750)},
		//{"npc_cpt_scp_106", Vector(-2730.027832, 5804.986328, -7166.968750)},
		//{"npc_cpt_scp_012", Vector(-1122.385742, -195.140732, -8447.968750)},
		//{"npc_cpt_scp_966", Vector(-650.879883, 4119.376953, -7167.968750)},
		//{"npc_cpt_scp_966", Vector(-474.215820, 4124.738281, -7167.968750)},
		//{"npc_cpt_scp_966", Vector(-752.841125, 4201.270020, -7167.968750)},
		//{"npc_cpt_scp_457", Vector(-2567.378174, 2985.477783, -7167.968750)},
		//{"npc_cpt_scp_939_a", Vector(6592.954590, -893.843567, -11551.968750)},
		//{"npc_cpt_scp_939_b", Vector(6699.372070, -1848.375977, -11551.968750)},
		//{"npc_cpt_scp_939_c", Vector(6929.901367, -885.706116, -11551.968750)},
		//{"npc_cpt_scp_035", Vector(759.694031, 843.260010, -7167.968750)},
		//{"npc_cpt_scp_513", Vector(-812.415161, 5603.627441, -7167.968750)},
	}
	
	for k,v in pairs(npc_tab) do
		local npc = ents.Create(v[1])
		if IsValid(npc) then
			npc:SetPos(v[2])
			npc:Spawn()
			npc:Activate()
		end
	end
end

function Breach_Map_Organise()
	print("organising the map...")
	
	br2_914_disabled = false
	br_914status = 1
	
	br2_914_fix_ent_1 = ents.Create("prop_physics")
	if IsValid(br2_914_fix_ent_1) then
		br2_914_fix_ent_1:SetPos(Vector(783.786865, -610.382507, -8192.000000))
		br2_914_fix_ent_1:SetModel("models/hunter/plates/plate2x3.mdl")
		br2_914_fix_ent_1:SetMaterial("phoenix_storms/metalset_1-2")
		br2_914_fix_ent_1:Spawn()
		local phys = br2_914_fix_ent_1:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
	end
	
	br2_914_fix_ent_2 = ents.Create("prop_physics")
	if IsValid(br2_914_fix_ent_2) then
		br2_914_fix_ent_2:SetPos(Vector(783.786865, -1060.382568, -8192))
		br2_914_fix_ent_2:SetModel("models/hunter/plates/plate2x3.mdl")
		br2_914_fix_ent_2:SetMaterial("phoenix_storms/metalset_1-2")
		br2_914_fix_ent_2:Spawn()
		local phys = br2_914_fix_ent_2:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
	end

	SpawnMapNPCs()
	
	local button_ents = {}
	
	//CORPSES
	if istable(MAPCONFIG.STARTING_CORPSES) and round_system.current_scenario.fake_corpses == true then
		local all_corpses = table.Copy(MAPCONFIG.STARTING_CORPSES)
		local corpse_infos = {}
		for i=1, MAPCONFIG.Starting_Corpses_Number() do
			local random_corpse = table.Random(all_corpses)
			table.ForceInsert(corpse_infos, random_corpse)
			table.RemoveByValue(all_corpses, random_corpse)
		end
		
		for k,v in pairs(corpse_infos) do
			local rag = ents.Create("prop_ragdoll")
			if IsValid(rag) then
				rag:SetModel(v.model)
				rag:SetPos(v.ragdoll_pos)
				rag:Spawn()
				rag.IsStartingCorpse = true
				ApplyCorpseInfo(rag, v, true)
				rag.Info = {}
				rag.Info.CorpseID = rag:GetCreationID()
				rag.Info.Victim = NULL
				rag.Info.VictimNick = "Unknown"
				rag.Info.DamageType = DMG_GENERIC
				rag.Info.Time = CurTime()
				rag.Info.Loot = {}
				local random_item = table.Random({"item_radio", "item_medkit", "item_pills", "item_gasmask", "item_nvg", "keycard_level1", "keycard_level2", "kanade_tfa_crowbar", "kanade_tfa_knife"})
				table.ForceInsert(rag.Info.Loot, {class = random_item, ammo = 0, name = weapons.Get(random_item).PrintName})
				rag.RagdollHealth = 0
				rag.nextReviveMove = 0
				
				if istable(all_fake_corpses) and isfunction(GetRandomName) and isfunction(v.role) then
					table.ForceInsert(all_fake_corpses, {rag, GetRandomName(), v.role()})
				end
			end
		end
	end
	
	// BUTTONS
	if istable(MAPCONFIG.BUTTONS) then
		for k,v in pairs(ents.GetAll()) do
			if v:GetClass() == "func_door" and (v:GetPos() == Vector(-3864.000000, 476.000000, -7840.000000) or v:GetPos() == Vector(-3864.000000, 644.000000, -7840.000000)) then
				v:Use(v, v, USE_ON, 1)
				continue
			end
			for k2,butt in pairs(MAPCONFIG.BUTTONS) do
				if v:GetPos() == butt.pos then
					//print("Found a button with pos (" .. tostring(butt.pos) .. ")  and level " .. butt.level)
					v.br_info = butt
					table.ForceInsert(button_ents, v)
				end
			end
		end
	else
		print("[Breach2] No buttons found...")
		return
	end
	
	// TERMINALS
	BR2_TERMINALS = table.Copy(MAPCONFIG.TERMINALS)
	for k,v in pairs(BR2_TERMINALS) do
		v.Info = {
			tab_set = "TERMINAL_INFO_GENERIC",
			software = {
				scom_cameras = false
			}
		}
		if math.random(1,2) == 1 then
			v.Info.software.scom_cameras = true
			v.Authorization = {
				login = "admin",
				password = "admin",
				currentlyLogged = false,
			}
		end
	end
	
	// CAMERAS
	if istable(MAPCONFIG.CAMERAS) then
		for k,v in pairs(MAPCONFIG.CAMERAS) do
			local camera = ents.Create("br2_camera")
			if IsValid(camera) then
				camera:SetModel("models/props/cs_assault/camera.mdl")
				camera:SetPos(v.pos)
				camera:SetAngles(v.ang)
				camera:Spawn()
				camera.CameraInfo = table.Copy(v)
				camera.CameraName = v.name
				camera:SetNWString("CameraName", v.name)
			end
		end
	else
		print("[Breach2] No cameras found...")
		return
	end
	
	// BUTTON CODES
	for k,v in pairs(button_ents) do
		if v.br_info.code != nil then
			local oldcode = v.br_info.code
			v.br_info.code = (math.random(1,9) * 1000) + (math.random(1,9) * 100) + (math.random(1,9) * 10) + math.random(1,9)
			print("Found a code button ("..oldcode..") changing to a random one ("..v.br_info.code..")")
			v.br_info.code_type = "radio"
		end
	end
end

hook.Add("BR2_RoundStart", "MAPCONFIG_BR2_RoundStart", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "func_button" and v:GetPos() == Vector(-522.000000, 1496.000000, -7909.169922) then
			v:Use(v, v, USE_ON, 1)
			continue
		end
	end
end)

hook.Add("Tick", "BR_SITEGUARD_TICK", function()
	if SERVER and IsValid(br2_914_fix_ent_1) then
		br2_914_fix_ent_1:SetPos(Vector(783.786865, -610.382507, -8192.000000))
	end
end)

print("[Breach2] MAP CONFIGURATION loaded!")