
local ambient_general = {
	"breach2/ambient/general/Ambient1.ogg",
	"breach2/ambient/general/Ambient2.ogg",
	"breach2/ambient/general/Ambient3.ogg",
	"breach2/ambient/general/Ambient4.ogg",
	"breach2/ambient/general/Ambient5.ogg",
	"breach2/ambient/general/Ambient6.ogg",
	"breach2/ambient/general/Ambient7.ogg",
	"breach2/ambient/general/Ambient8.ogg",
	"breach2/ambient/general/Ambient9.ogg",
	"breach2/ambient/general/Ambient10.ogg",
	"breach2/ambient/general/Ambient11.ogg",
	"breach2/ambient/general/Ambient12.ogg",
	"breach2/ambient/general/Ambient13.ogg",
	"breach2/ambient/general/Ambient14.ogg",
	"breach2/ambient/general/Ambient15.ogg",
}

local ambient_lcz = {
	"breach2/ambient/zone1/Ambient1.ogg",
	"breach2/ambient/zone1/Ambient2.ogg",
	"breach2/ambient/zone1/Ambient3.ogg",
	"breach2/ambient/zone1/Ambient4.ogg",
	"breach2/ambient/zone1/Ambient5.ogg",
	"breach2/ambient/zone1/Ambient6.ogg",
	"breach2/ambient/zone1/Ambient7.ogg",
	"breach2/ambient/zone1/Ambient8.ogg",
}

local ambient_hcz = {
	"breach2/ambient/zone2/Ambient1.ogg",
	"breach2/ambient/zone2/Ambient2.ogg",
	"breach2/ambient/zone2/Ambient3.ogg",
	"breach2/ambient/zone2/Ambient4.ogg",
	"breach2/ambient/zone2/Ambient5.ogg",
	"breach2/ambient/zone2/Ambient6.ogg",
	"breach2/ambient/zone2/Ambient7.ogg",
	"breach2/ambient/zone2/Ambient8.ogg",
	"breach2/ambient/zone2/Ambient9.ogg",
	"breach2/ambient/zone2/Ambient10.ogg",
	"breach2/ambient/zone2/Ambient11.ogg",
}

local ambient_ez = {
	"breach2/ambient/zone3/Ambient1.ogg",
	"breach2/ambient/zone3/Ambient2.ogg",
	"breach2/ambient/zone3/Ambient3.ogg",
	"breach2/ambient/zone3/Ambient4.ogg",
	"breach2/ambient/zone3/Ambient5.ogg",
	"breach2/ambient/zone3/Ambient6.ogg",
	"breach2/ambient/zone3/Ambient7.ogg",
	"breach2/ambient/zone3/Ambient8.ogg",
	"breach2/ambient/zone3/Ambient9.ogg",
	"breach2/ambient/zone3/Ambient10.ogg",
	"breach2/ambient/zone3/Ambient11.ogg",
	"breach2/ambient/zone3/Ambient12.ogg",
}

MAPCONFIG.EnableGamemodeMusic = true
MAPCONFIG.EnableAmbientSounds = true
MAPCONFIG.GeneralAmbientSounds = ambient_general
MAPCONFIG.CommotionSounds = {
	"breach2/intro/Commotion/Commotion1.ogg",
	"breach2/intro/Commotion/Commotion2.ogg",
	"breach2/intro/Commotion/Commotion3.ogg",
	"breach2/intro/Commotion/Commotion4.ogg",
	"breach2/intro/Commotion/Commotion5.ogg",
	"breach2/intro/Commotion/Commotion6.ogg",
	"breach2/intro/Commotion/Commotion7.ogg",
	"breach2/intro/Commotion/Commotion8.ogg",
	"breach2/intro/Commotion/Commotion9.ogg",
	"breach2/intro/Commotion/Commotion10.ogg",
	"breach2/intro/Commotion/Commotion11.mp3",
	"breach2/intro/Commotion/Commotion12.ogg",
	"breach2/intro/Commotion/Commotion13.mp3",
	"breach2/intro/Commotion/Commotion14.mp3",
	"breach2/intro/Commotion/Commotion15.mp3",
	"breach2/intro/Commotion/Commotion16.ogg",
	"breach2/intro/Commotion/Commotion17.ogg",
	"breach2/intro/Commotion/Commotion18.ogg",
	"breach2/intro/Commotion/Commotion19.ogg",
	"breach2/intro/Commotion/Commotion20.ogg",
	"breach2/intro/Commotion/Commotion21.ogg",
	"breach2/intro/Commotion/Commotion22.mp3",
	"breach2/intro/Commotion/Commotion23.ogg",
	"breach2/intro/Bang2.ogg",
	"breach2/intro/Bang3.ogg",
}

/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/Alarm2_1.ogg", 6},
	{"breach2/alarm/Alarm2_2.ogg", 5},
	{"breach2/alarm/Alarm2_3.ogg", 7},
	{"breach2/alarm/Alarm2_4.ogg", 10},
	{"breach2/alarm/Alarm2_5.ogg", 6},
	{"breach2/alarm/Alarm2_6.ogg", 8},
	{"breach2/alarm/Alarm2_7.ogg", 7},
	{"breach2/alarm/Alarm2_8.ogg", 4},
	{"breach2/alarm/Alarm2_9.ogg", 4},
	{"breach2/alarm/Alarm2_10.ogg", 15}
}
*/

MAPCONFIG.FirstSounds = {
	{"breach2/alarm/breach_alarm.ogg", 72},
}
MAPCONFIG.FirstSoundsLength = 72 -- length of all of FirstSounds in seconds

MAPCONFIG.CAMERAS = {
	{name = "lcz_corridor_1", pos = Vector(1444,-112,-8020), ang = Angle(0,180,0)},
	{name = "lcz_corridor_2", pos = Vector(1581,-272,-8034), ang = Angle(0,0,0)},
	{name = "lcz_corridor_3", pos = Vector(1148,-1940,-8036), ang = Angle(0,263,0)},
	{name = "lcz_corridor_4", pos = Vector(48,219,-8025), ang = Angle(0,90,0)},
	{name = "lcz_corridor_5", pos = Vector(166,2576,-8026), ang = Angle(0,180,0)},
	{name = "lcz_corridor_6", pos = Vector(-499,-768,-7991), ang = Angle(0,180,0)},
	{name = "lcz_corridor_7", pos = Vector(1446,1168,-8040), ang = Angle(0,180,0)},
	{name = "lcz_office_room_1", pos = Vector(-944,864,-7974), ang = Angle(0,90,0)},
	{name = "lcz_storage_room_1", pos = Vector(912,-585,-7967), ang = Angle(0,-90,0)},
	{name = "lcz_cont_room_scp012", pos = Vector(-1068,224,-8286), ang = Angle(0,180,0)},
	{name = "lcz_cont_room_scp173", pos = Vector(-56,1230,-7924), ang = Angle(0,90,0)},

	{name = "hcz_corridor_1", pos = Vector(-376,5011,-7048), ang = Angle(0,-90,0)},
	{name = "hcz_corridor_2", pos = Vector(-1424,1084,-7016), ang = Angle(0,-90,0)},
	{name = "hcz_corridor_3", pos = Vector(-1265,4224,-7034), ang = Angle(0,180,0)},
	{name = "hcz_corridor_4", pos = Vector(-768,2441,-7055), ang = Angle(0,-90,0)},
	{name = "hcz_water_room", pos = Vector(960,2238,-7014), ang = Angle(0,-90,0)},
	{name = "hcz_cont_room_scp682", pos = Vector(-376,5011,-7048), ang = Angle(0,-90,0)},
	{name = "hcz_cont_room_scp457", pos = Vector(-2680,3083,-7014), ang = Angle(0,-90,0)},
	{name = "hcz_cont_room_scp106", pos = Vector(-2143,6712,-6962), ang = Angle(0,180,0)},
	{name = "hcz_cont_room_scp008", pos = Vector(-1610,4520,-7061), ang = Angle(0,0,0)},
	{name = "hcz_cont_room_scp682", pos = Vector(-1610,4520,-7061), ang = Angle(0,0,0)},

	{name = "ez_corridor_1", pos = Vector(-1648,3756,-5963), ang = Angle(0,-90,0)},
	{name = "ez_corridor_2", pos = Vector(-1114,1616,-5953), ang = Angle(0,0,0)},
	{name = "ez_corridor_3", pos = Vector(-1114,1616,-5953), ang = Angle(0,0,0)},
	{name = "ez_corridor_4", pos = Vector(2304,2132,-5958), ang = Angle(0,90,0)},
	{name = "ez_corridor_5", pos = Vector(2304,2132,-5958), ang = Angle(0,90,0)},
	{name = "ez_corridor_6", pos = Vector(-1956,4272,-6000), ang = Angle(0,180,0)},
	{name = "ez_corridor_7", pos = Vector(-1956,4272,-6000), ang = Angle(0,180,0)},
	{name = "ez_checkpoint_1", pos = Vector(-179,-1500,-5977), ang = Angle(0,-32,0)},
	{name = "ez_cont_room_scp860", pos = Vector(1360,1613,-5999), ang = Angle(0,90,0)},
}

MAPCONFIG.BUTTONS_2D = {}

MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS = {
	on_open = function(button)
		TryToOpenContainer(button)
	end,
	buttons = {
		{pos = Vector(-2525,-579,-8163), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(1088,-576,-8145), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(252,396,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(1499,1326,-8136), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(498,-1103,-8144), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(246,540,-8131), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(2212,-1755,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-915,-633,-8162), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(494,2138,-8145), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(954,1467,-8137), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-290,-1190,-8142), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-673,-639,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-541,-53,-8173), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(847,817,-8177), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(1489,1770,-8142), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(-975,1035,-8139), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(2525,-710,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(1599,-64,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(958,812,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-1046,77,-8413), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-657,1968,-7901), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},
		{pos = Vector(1450,813,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"},

		{pos = Vector(440,-1422,-8135), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},
		{pos = Vector(713,-1683,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECONDARY"},

		{pos = Vector(184,5043,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-4017,4209,-7115), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-2369,4444,-7131), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-2896,4321,-7122), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-1183,1096,-7132), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(376,639,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"},
		{pos = Vector(332,634,-7156), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"},
		{pos = Vector(292,641,-7155), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"},
		{pos = Vector(-1495,3649,-7122), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-1172,1103,-7113), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1691,2824,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1521,544,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-289,3757,-6109), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-289,3757,-6109), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-333,3832,-6092), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(352,4577,-6093), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(560,4577,-6078), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-259,3757,-6109), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(352,4578,-6093), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(664,3104,-6095), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(708,3097,-6117), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-1501,3543,-6430), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-1014,1572,-6045), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-1014,1572,-6045), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(-305,304,-5998), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(371,1315,-6109), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		{pos = Vector(207,1568,-6094), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},

		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
		--{pos = XXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"},
	}
}

MAPCONFIG.BUTTONS_2D.SIMPLE = {
	on_open = function(button)
		SimpleButtonUse(button)
		surface.PlaySound("breach2/pickitem2.ogg")
	end,
	buttons = {
		{name = "SCP-1162", pos = Vector(903,882,-8143), canSee = DefaultItemContainerCanSee, func_sv = function(ply)
			local weps = {}
			for k,v in pairs(ply:GetWeapons()) do
				if v.Pickupable == true or v.droppable == true then
					table.ForceInsert(weps, v)
				end
			end
			if table.Count(weps) == 0 then
				ply:TakeDamage(20, ply, ply)
			else
				local rnd_wep = table.Random(weps)
				local ent = ents.Create(table.Random({"keycard_master", "keycard_playing", "item_battery_9v", "item_pills", "item_radio", "keycard_level1", "item_gasmask"}))
				if IsValid(ent) then
					ent:SetPos(Vector(893,882,-8144))
					ent:SetNWBool("isDropped", true)
					ent:Spawn()
					ply:StripWeapon(rnd_wep:GetClass())
				end
			end
		end},
	}
}

MAPCONFIG.BUTTONS_2D.OUTFITTERS = {
	on_open = function(button)
		if LocalPlayer():GetOutfit().can_change_outfits == false then
			--chat.AddText(Color(255, 255, 255), "You cannot change your outfit")
			chat.AddText(Color(255, 255, 255), "You couldn't find anything useful...")

			return
		end
		net.Start("br_use_outfitter")
			net.WriteVector(button.pos)
		net.SendToServer()
	end,
	-- setpos -789.450562 -652.576416 -8168.468750;setang 11.656787 -83.756401 0.000000
	buttons = {
		{pos = Vector(-777,-707,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(960,-1089,-8156), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(465,256,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-330,-1263,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(959,912,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(504,-1682,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ_ARMORY"},
		{pos = Vector(-3520,5473,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1521,512,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-350,446,-6094), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		{pos = Vector(-229,3757,-6109), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},

	}
}

MAPCONFIG.BUTTONS_2D.TERMINALS = {
	on_open = function(button)
		BR_Access_Terminal(button)
	end,
	buttons = {
	-- LCZ
		-- OFFICES
		{name = "lcz_office_1_1", pos = Vector(-959,908,-8143), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_2", pos = Vector(-1012,1165,-8124), canSee = function() return CanSeeFrom(Vector(-1012,1151,-8125)) end},
		{name = "lcz_office_1_3", pos = Vector(-972,1165,-8124), canSee = function() return CanSeeFrom(Vector(-971,1151,-8125)) end},
		{name = "lcz_office_1_4", pos = Vector(-1034,1224,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_5", pos = Vector(-1034,1375,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_6", pos = Vector(-1213,1373,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_7", pos = Vector(-1214,1220,-8143), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_8", pos = Vector(-1213,1056,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_9", pos = Vector(-1249,1056,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_10", pos = Vector(-1249,1373,-8142), canSee = DefaultTerminalCanSee},
		
		-- STORAGE ROOMS
		{name = "lcz_storage_room_1", pos = Vector(1027,-559,-8141), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_1", pos = Vector(743,2156,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_1", pos = Vector(763,2001,-8139), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_2", pos = Vector(763,1980,-8139), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_3", pos = Vector(744,2051,-8112), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2_2_4", pos = Vector(744,2028,-8112), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_3", pos = Vector(880,-1614,-8142), canSee = DefaultTerminalCanSee},
		
		-- CONTAINMENT ROOMS
		{name = "lcz_cont_room_1_1", pos = Vector(-1980,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1981,-529,-8124)) end},
		{name = "lcz_cont_room_1_2", pos = Vector(-1940,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1940,-528,-8124)) end},
		{name = "lcz_cont_room_2_1", pos = Vector(494,212,-8123), canSee = function() return CanSeeFrom(Vector(478,212,-8124)) end},
		{name = "lcz_cont_room_2_2", pos = Vector(494,172,-8123), canSee = function() return CanSeeFrom(Vector(480,173,-8124)) end},
		{name = "lcz_cont_room_3_1", pos = Vector(1940,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1941,-1504,-8123)) end},
		{name = "lcz_cont_room_3_2", pos = Vector(1900,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1900,-1504,-8123)) end},
		{name = "lcz_cont_room_4", pos = Vector(860,798,-8142), canSee = DefaultTerminalCanSee},

		-- CHECKPOINTS
		{name = "lcz_checkpoint_1_1", pos = Vector(-430,430,-8124), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_1_2", pos = Vector(-430,466,-8124), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_2_1", pos = Vector(-429,430,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_2_2", pos = Vector(-429,466,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_3_1_1", pos = Vector(1890,829,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_3_1_2", pos = Vector(-2666,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_3_2_1", pos = Vector(-2736,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2735,5388,-7357)) end},
		{name = "lcz_checkpoint_3_2_2", pos = Vector(-2697,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2697,5392,-7356)) end},

	--HCZ
		-- CONTAINMENT ROOMS
		{name = "hcz_cont_room_1_1", pos = Vector(605,923,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_1_2", pos = Vector(605,887,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_2_1", pos = Vector(838,2301,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_2_2", pos = Vector(874,2301,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_1_1", pos = Vector(-2526,2724,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_1_2", pos = Vector(-2561,2724,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_2_1", pos = Vector(-2659,3156,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3_2_2", pos = Vector(-2623,3156,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_4_1", pos = Vector(-3004,3722,-7108), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_4_2", pos = Vector(-3004,3686,-7107), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_5_1", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_5_2", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
		
		-- CHECKPOINTS
		{name = "hcz_checkpoint_1_1", pos = Vector(-428,430,-7099), canSee = DefaultTerminalCanSee},
		{name = "hcz_checkpoint_1_2", pos = Vector(-428,466,-7099), canSee = DefaultTerminalCanSee},

	--EZ
		-- CHECKPOINTS
		{name = "ez_checkpoint_1_1_1", pos = Vector(1458,3470,-6076), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_1_1_2", pos = Vector(1458,3506,-6076), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_1_2", pos = Vector(633,3292,-6094), canSee = DefaultTerminalCanSee},
		
		-- OFFICES
		{name = "ez_office_1", pos = Vector(459,4178,-6078), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2", pos = Vector(219,1253,-6094), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_1", pos = Vector(-784,1860,-6029), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_2", pos = Vector(-790,1998,-6030), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_3", pos = Vector(-662,2001,-6030), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3_4", pos = Vector(-664,1531,-6030), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4_1", pos = Vector(705,2800,-6190), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4_2", pos = Vector(751,2671,-6189), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4_3", pos = Vector(619,2571,-6190), canSee = DefaultTerminalCanSee},


		
		-- STORAGE ROOMS
		{name = "ez_storage_room_1", pos = Vector(-410,318,-5998), canSee = DefaultTerminalCanSee},
		{name = "ez_storage_room_2", pos = Vector(-367,3838,-6094), canSee = DefaultTerminalCanSee},
	}
}
-- ulx strip ^ ; give breach_tool_terminalplacer
-- lua_run Entity(1):SetPos(xxxxxxxxxxxxxxxxxxxxxx)

MAPCONFIG.ZONES = {}

MAPCONFIG.SPECIAL_MUSIC_ZONES = {
	{pos1 = Vector(465,-1144,-8222), pos2 = Vector(903,-520,-8065), sound = "breach2/music/914.ogg", length = 29.05, volume = 0.8}, -- 914
	{pos1 = Vector(1592,-901,-8229), pos2 = Vector(2314,-1787,-8026), sound = "breach2/music/205.ogg", length = 40.5, volume = 0.8}, -- 205
	{pos1 = Vector(3400,-7035,-8653), pos2 = Vector(4969,-5453,-8394), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, -- 049 TUNNELS
	{pos1 = Vector(3637,261,-7459), pos2 = Vector(4658,-1082,-6809), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, -- WARHEADS
	{pos1 = Vector(5370,366,-11672), pos2 = Vector(7569,-2400,-11324), sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 0.8}, -- HCZ TUNNELS
	{pos1 = Vector(-912,2139,-16175), pos2 = Vector(2016,-899,-14578), sound = "breach2/music/PD.ogg", length = 27.03, volume = 1}, -- PD
	--{pos1 = Vector(14907,-15883,-2283), pos2 = Vector(10162,-10690,99), sound = "breach2/music/1499.ogg", length = 50, volume = 0.7}, -- 1499
	{pos1 = Vector(-1003,-397,-8475), pos2 = Vector(-1592,235,-8317), sound = "breach2/music/012.ogg", length = 25.5, volume = 0.7}, -- 012
}

MAPCONFIG.ESCAPE_ZONES = {
	{ pos1 = Vector(-6526,3309,-1615), pos2 = Vector(-7232,1660,-667) },
	{ pos1 = Vector(2618,-394,237), pos2 = Vector(2137,-1307,515) },
}

MAPCONFIG.GAS_ZONES = {
	{ pos1 = Vector(28,4964,-7184), pos2 = Vector(-144,4598,-7024) },
	{ pos1 = Vector(5653,-247,-11574), pos2 = Vector(5416,-81,-11405) },
}

--  name                       	First Position          	Second Position         	Color                music       fog     NVGmul		ambient       use general ambient
MAPCONFIG.ZONES.LCZ = {
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(-3999,-2473,-8672),
		pos2 						= Vector(3302,3060,-7732),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(2466,2818,-7720),
		pos2 						= Vector(1830,2170,-6653),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.HCZ = {
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(1786,7123,-7625),
		pos2 						= Vector(-4100,10,-6658),
		--music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(2517,807,-7697),
		pos2 						= Vector(1806,1350,-7015),
		--music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "SCP-049's Tunnels",
		pos1 						= Vector(3400,-7035,-8653),
		pos2 						= Vector(4969,-5453,-8394),
		--music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		music 						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in SCP-049's Tunnels",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "HCZ Tunnels",
		pos1 						= Vector(5370,366,-11672),
		pos2 						= Vector(7569,-2400,-11324),
		music 						= {sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Tunnel system",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "HCZ Warheads",
		pos1 						= Vector(3637,261,-7459),
		pos2 						= Vector(4658,-1082,-6809),
		music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Warhead Control Room",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.ENTRANCEZONE = {
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(3961,5828,-6625),
		pos2 						= Vector(-2735,-2100,-4503),
		--music 						= {sound = "breach2/music/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.POCKETDIMENSION = {
	{
		name 						= "Pocket Dimension",
		pos1 						= Vector(-912,2139,-16175),
		pos2 						= Vector(2016,-899,-14578),
		music 						= {sound = "breach2/music/PD.ogg", length = 27.03, volume = 1},
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(0,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in the Pocket Dimension",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.OUTSIDE = {
	{
		name 						= "Outside",
		pos1 						= Vector(4797,-2801,-1771),
		pos2 						= Vector(-7418,5765,1983),
		--music 						= {sound = "breach2/music/withinsight.ogg", length = 60.44, volume = 0.5},
		music						= nil,
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(255,0,255,50),
		sanity 						= 1,
		examine_info 				= "You are outside of the facility",
		zone_temp 					= ZONE_TEMP_VERYCOLD,
		scp_106_can_tp 				= false,
	},
} 
MAPCONFIG.ZONES.FOREST = {
	{
		name 						= "Forest",
		pos1 						= Vector(12061,-15943,-3792),
		pos2 						= Vector(15048,-13022,-2633),
		music 						= nil,
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(70,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in a forest",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= false,
	},
}
/*
MAPCONFIG.ZONES.SCP_1499 = {
	{
		name 						= "SCP-1499",
		pos1 						= Vector(14907,-15883,-2283),
		pos2 						= Vector(10162,-10690,99),
		music 						= {sound = "breach2/music/1499.ogg", length = 50, volume = 1},
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(150,0,0,50),
		sanity 						= -1,
		examine_info 				= "You are in an unknown world",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= false,
	},
}
*/

-- Spawns in Class D's cells
MAPCONFIG.SPAWNS_CLASSD_CELLS = {
	Vector(-3602.939453125, 832.32720947266, -8046.96875),
	Vector(-3818.6428222656, 836.63403320313, -8046.96875),
	Vector(-3391.6364746094, 826.951171875, -8046.96875),
	Vector(-3187.87109375, 819.77954101563, -8046.96875),
	Vector(-2978.2719726563, 818.99493408203, -8046.96875),
	Vector(-2767.869140625, 823.73364257813, -8046.96875),
	Vector(-2764.4208984375, 300.34832763672, -8046.96875),
	Vector(-2968.7724609375, 301.01162719727, -8046.96875),
	Vector(-3186.3063964844, 296.73794555664, -8046.96875),
	Vector(-3385.3439941406, 298.82928466797, -8046.96875),
	Vector(-3605.9470214844, 293.82122802734, -8046.96875),
	Vector(-3811.1315917969, 294.30609130859, -8046.96875),
	Vector(2881.419921875, 3539.2512207031, -6118.96875),
	Vector(2656.3898925781, 3538.9228515625, -6118.96875),
	Vector(2450.6579589844, 3540.3696289063, -6118.96875),
	Vector(3355.2131347656, 3542.7080078125, -6118.96875),
	Vector(3743.865234375, 3526.2707519531, -6118.96875),
	Vector(3178.3542480469, 3154.4743652344, -6118.96875),
	Vector(3686.7014160156, 3344.9328613281, -6118.96875),
	Vector(3511.1938476563, 3346.1020507813, -6118.96875),
	Vector(1888.8702392578, 3346.3327636719, -6118.96875),
	Vector(2137.8823242188, 3354.8312988281, -6118.96875),
	Vector(2843.0903320313, 3300.5451660156, -6118.96875),
	Vector(2610.8374023438, 3332.7150878906, -6118.96875),
	Vector(-3706.0673828125, 464.80758666992, -8046.96875),
	Vector(-3604.4721679688, 461.24993896484, -8046.96875),
	Vector(-3711.3837890625, 665.58489990234, -8046.96875),
	Vector(-3573.3332519531, 689.86108398438, -8046.96875),
	Vector(-3482.9926757813, 469.52133178711, -8046.96875),
	Vector(-3445.1513671875, 665.87170410156, -8046.96875),
	Vector(-3348.6916503906, 464.94454956055, -8046.96875),
	Vector(-3307.9562988281, 655.20361328125, -8046.96875),
}

-- Spawns in Light Containment Zone
MAPCONFIG.SPAWNS_LCZ = {
	Vector(-1847.2550048828, 694.06427001953, -8294.96875),
	Vector(-2252.6943359375, 1087.2055664063, -8038.96875),
	Vector(-1140.3791503906, 1241.3851318359, -8166.96875),
	Vector(-1192.3406982422, 930.40454101563, -8166.96875),
	Vector(-1362.9724121094, -162.78018188477, -8166.96875),
	Vector(-1429.1767578125, -844.38153076172, -8166.96875),
	Vector(-642.28723144531, -1212.1612548828, -8294.96875),
	Vector(-538.47265625, -830.07446289063, -8166.96875),
	Vector(-34.431125640869, -958.25274658203, -8166.96875),
	Vector(25.617729187012, -114.19427490234, -8166.96875),
	Vector(635.38543701172, -112.50624847412, -8166.96875),
	Vector(1164.5394287109, -279.38793945313, -8166.96875),
	Vector(1234.5776367188, 615.72033691406, -8166.96875),
	Vector(1790.9327392578, 588.81854248047, -8166.96875),
	Vector(497.71002197266, 670.62561035156, -8166.96875),
	Vector(-28.656272888184, 480.24255371094, -8166.96875),
	Vector(1302.3918457031, -1454.5146484375, -8166.96875),
	Vector(2098.9230957031, -1436.2882080078, -8166.96875),
	Vector(2467.4304199219, -115.8934173584, -8166.96875),
	Vector(1240.8343505859, -2214.7170410156, -8166.96875),
	Vector(-25.500885009766, -2156.1408691406, -8166.96875),
	Vector(-64.191612243652, -1528.6021728516, -8166.96875),
	Vector(-2230.0556640625, -607.42901611328, -8166.96875),
	Vector(-2312.0654296875, 642.35620117188, -8294.96875),
	Vector(-106.84334564209, 2610.0305175781, -8166.96875),
	Vector(667.28894042969, 2543.8637695313, -8166.96875),
	Vector(1249.8482666016, 2309.6809082031, -8166.96875),
	Vector(1089.7720947266, 1098.8056640625, -8166.96875),
	Vector(1237.0960693359, -1039.1477050781, -8166.96875),
	Vector(1996.7291259766, -1661.2569580078, -8166.96875),
	Vector(-778.05279541016, 2479.8603515625, -8166.96875),
	Vector(-1313.7080078125, 2505.2956542969, -8166.96875),
	Vector(-1145.7430419922, 1856.6237792969, -8166.96875),
}

-- Spawns in Heavy Containment Zone
MAPCONFIG.SPAWNS_HCZ = {
	Vector(-229.45164489746, 5415.6357421875, -7142.96875),
	Vector(-34.579574584961, 4513.8549804688, -7142.9389648438),
	Vector(-65.567283630371, 3390.0900878906, -7142.96875),
	Vector(-242.3719329834, 2844.0532226563, -7142.96875),
	Vector(-727.64440917969, 2816.0270996094, -7142.96875),
	Vector(-640.83166503906, 2224.185546875, -7142.96875),
	Vector(-201.98260498047, 1564.6809082031, -7142.96875),
	Vector(-1340.513671875, 1556.2530517578, -7142.96875),
	Vector(-1328.5539550781, 300.65124511719, -7142.96875),
	Vector(1450.7679443359, 760.37139892578, -7142.96875),
	Vector(1449.0362548828, 1592.6616210938, -7142.96875),
	Vector(604.404296875, 1570.8133544922, -7142.96875),
	Vector(567.86090087891, 2208.0112304688, -7142.96875),
	Vector(1227.8106689453, 2854.2604980469, -7142.96875),
	Vector(599.8828125, 2835.3422851563, -7142.96875),
	Vector(-1456.8861083984, 2848.2329101563, -7142.96875),
	Vector(-1980.6506347656, 2894.2614746094, -7142.96875),
	Vector(-2005.0480957031, 3544.7360839844, -7142.96875),
	Vector(-1986.2637939453, 3985.7663574219, -7142.96875),
	Vector(-1297.5765380859, 4072.9167480469, -7142.96875),
	Vector(-714.16741943359, 4703.5786132813, -7142.96875),
	Vector(-683.48034667969, 5385.6171875, -7142.96875),
	Vector(-1334.5980224609, 5414.2983398438, -7142.96875),
	Vector(-1839.6965332031, 5403.45703125, -7142.96875),
	Vector(-2198.4543457031, 4964.2260742188, -7142.96875),
	Vector(-1691.0745849609, 4810.9208984375, -7222.9692382813),
	Vector(-2639.7568359375, 5442.1455078125, -7142.96875),
	Vector(-3248.5053710938, 5403.7099609375, -7142.96875),
	Vector(-697.38262939453, 3702.6547851563, -7142.96875),
}

-- Spawns in Entrance Zone
MAPCONFIG.SPAWNS_ENTRANCEZONE = {
	Vector(-1565.7836914063, 4175.3637695313, -6116.96875),
	Vector(-1763.7423095703, 3452.2993164063, -6118.96875),
	Vector(-796.27001953125, 3603.15234375, -6454.96875),
	Vector(-1673.060546875, 2939.4575195313, -6118.96875),
	Vector(-1379.9200439453, 2340.6953125, -6118.96875),
	Vector(-998.01910400391, 1716.4814453125, -6116.96875),
	Vector(-365.74566650391, 2325.5678710938, -6116.96875),
	Vector(-156.95542907715, 1730.7175292969, -6116.96875),
	Vector(-487.99609375, 1119.5129394531, -6116.96875),
	Vector(-941.61828613281, 579.30517578125, -6116.96875),
	Vector(-479.76049804688, -88.985885620117, -6118.96875),
	Vector(345.12316894531, -143.07070922852, -6118.96875),
	Vector(344.85858154297, 1085.8997802734, -6116.96875),
	Vector(884.58813476563, 427.58923339844, -6116.96875),
	Vector(-819.69287109375, 2919.2250976563, -6118.96875),
	Vector(-932.40069580078, 4285.6020507813, -6118.96875),
	Vector(-333.63018798828, 4892.689453125, -6118.96875),
	Vector(335.54641723633, 3543.4794921875, -6116.96875),
	Vector(381.77563476563, 2953.4262695313, -6116.96875),
	Vector(903.72497558594, 2213.0893554688, -6116.96875),
	Vector(1540.0699462891, 2342.8303222656, -6116.96875),
	Vector(1659.8101806641, 2939.5070800781, -6116.96875),
	Vector(898.251953125, 2747.8112792969, -6116.96875),
	Vector(383.72244262695, 2298.6142578125, -6116.96875),
	Vector(381.57489013672, 1717.4852294922, -6116.96875),
	Vector(1501.6190185547, 1228.6151123047, -6118.96875),
}

-- Where Chaos Insurgency spawns at the beginning of the round
MAPCONFIG.SPAWNS_CHAOSINSURGENCY = {
	Vector(-2099.0185546875, -1344.994140625, 537.03125),
	Vector(-2229.0087890625, -1331.1219482422, 537.03125),
	Vector(-2231.9868164063, -1163.3917236328, 537.03125),
	Vector(-2124.3815917969, -1208.7913818359, 537.03125),
	Vector(-2213.6059570313, -1012.6979370117, 537.03125),
	Vector(-2118.2182617188, -1026.197265625, 537.03125),
	Vector(-2206.7045898438, -858.07464599609, 537.03125),
	Vector(-2089.7861328125, -806.54547119141, 537.03125),
	Vector(-2217.3076171875, -686.15570068359, 537.03125),
	Vector(-2103.2646484375, -644.27142333984, 537.03125),
	Vector(-1961.6408691406, -204.6852722168, 529.03125),
	Vector(-1780.8138427734, -214.21249389648, 529.03125),
	Vector(-1751.7730712891, -403.45465087891, 529.03125),
	Vector(-1885.3139648438, -350.78588867188, 529.03125),
	Vector(-1957.9162597656, -438.12219238281, 529.03125),
	Vector(-1851.7183837891, -467.14834594727, 529.03125),
	Vector(-1750.6444091797, -651.08081054688, 529.03125),
	Vector(-1948.6833496094, -657.30352783203, 529.03125),
	Vector(-1610.1857910156, -739.37475585938, 537.03125),
	Vector(-1606.4963378906, -901.81842041016, 537.03125),
	Vector(-1611.0314941406, -1051.2098388672, 537.03125),
}

-- SCP 035's spawns
MAPCONFIG.SPAWNS_SCP_035 = {
	Vector(781.141479, 1025.646362, -7103.968750),
}

-- SCP 173's spawns
MAPCONFIG.SPAWNS_SCP_173 = {
	Vector(-189.662064, 1955.437500, -8063.968750),
}

-- SCP 049's spawns
MAPCONFIG.SPAWNS_SCP_049 = {
	Vector(4180.052734375, -6376.6708984375, -8582.96875),
	Vector(4086.451171875, -6439.6264648438, -8582.96875),
	Vector(4181.0200195313, -6440.6103515625, -8582.96875),
	Vector(4256.5708007813, -6396.4174804688, -8582.96875),
}

-- SCP 106's spawn
MAPCONFIG.SPAWNS_SCP_106 = {
	Vector(-2648.6215820313, 5988.0205078125, -7590.96875),
	Vector(-2725.8474121094, 6045.0874023438, -7590.96875),
	Vector(-2653.0478515625, 6108.3359375, -7590.96875),
	Vector(-2737.5017089844, 6180.2817382813, -7590.96875),
	Vector(-2661.3217773438, 6233.98046875, -7590.96875),
}

-- SCP 457's spawn
MAPCONFIG.SPAWNS_SCP_457 = {
	Vector(-2557.9653320313, 2914.3310546875, -7142.96875),
	Vector(-2605.4235839844, 2929.216796875, -7142.96875),
	Vector(-2541.8579101563, 2977.3583984375, -7142.96875),
	Vector(-2609.3569335938, 3002.3344726563, -7142.96875),
}

-- SCP 966's spawn
MAPCONFIG.SPAWNS_SCP_966 = {
	Vector(-620.36407470703, 4211.275390625, -7142.96875),
	Vector(-621.71295166016, 4155.294921875, -7142.96875),
	Vector(-627.49792480469, 4095.4323730469, -7142.96875),
	Vector(-694.38372802734, 4100.6928710938, -7142.96875),
	Vector(-692.74670410156, 4166.3852539063, -7142.96875),
	Vector(-719.65667724609, 4215.8100585938, -7142.96875),
	Vector(-754.56024169922, 4148.9951171875, -7142.96875),
	Vector(-773.86547851563, 4095.3076171875, -7142.96875),
}

-- SCP 035's spawn
MAPCONFIG.SPAWNS_SCP_035 = {
	Vector(775.32934570313, 1026.5482177734, -7142.96875),
}


-- Spawns for other SCPs
MAPCONFIG.SPAWNS_SCP_OTHERS = {
	Vector(3503.2019042969, 3131.4350585938, 25.03125),
	Vector(3573.8725585938, 3114.5197753906, 25.03125),
	Vector(3423.3481445313, 3131.9501953125, 25.03125),
}

-- Where Mobile Task Force spawns when they arrive in the facility
MAPCONFIG.SPAWNS_MTF = {
	Vector(-674.06732177734, -1674.79296875, -6118.96875),
	Vector(-607.48913574219, -1685.3515625, -6118.96875),
	Vector(-533.96429443359, -1676.9647216797, -6118.96875),
	Vector(-516.22052001953, -1590.3044433594, -6118.96875),
	Vector(-592.92987060547, -1580.0950927734, -6118.96875),
	Vector(-665.51556396484, -1560.2497558594, -6118.96875),
	Vector(-524.51940917969, -1488.7401123047, -6118.96875),
	Vector(-599.81970214844, -1481.2236328125, -6118.96875),
	Vector(-669.45239257813, -1476.2058105469, -6118.96875),
}

-- Where Chaos Insurgency Support spawns when they arrive in the facility
MAPCONFIG.SPAWNS_CI_SUPPORT = {
	{
		Vector(-3757.8835449219, 1944.2198486328, -993.96875),
		Vector(-3711.6059570313, 1950.0505371094, -993.96875),
		Vector(-3753.4326171875, 1877.7825927734, -993.96875),
		Vector(-3700.7150878906, 1887.1597900391, -993.96875),
		Vector(-3693.6279296875, 1837.2171630859, -993.96875),
		Vector(-3747.2951660156, 1820.1141357422, -993.96875),
		Vector(-3789.1911621094, 1991.3436279297, -986),
		Vector(-3843.2177734375, 2046.4963378906, -986),
		Vector(-3738.1215820313, 2042.1231689453, -993.96875),
		Vector(-3800.9094238281, 2072.2543945313, -986),
		Vector(-3692.2644042969, 2001.1401367188, -993.96875),
	},
	{
		Vector(-6997.2368164063, 5052.294921875, -1185.96875),
		Vector(-6938.3720703125, 5052.9506835938, -1185.96875),
		Vector(-6885.9399414063, 5053.7583007813, -1185.96875),
		Vector(-6836.9033203125, 5056.3525390625, -1185.96875),
		Vector(-6789.0537109375, 5053.4443359375, -1185.96875),
		Vector(-6731.525390625, 5052.9291992188, -1185.96875),
		Vector(-6681.4672851563, 5043.8110351563, -1185.96875),
		Vector(-6686.9536132813, 4981.359375, -1185.96875),
		Vector(-6752.5234375, 4985.537109375, -1185.96875),
		Vector(-6793.2104492188, 4986.5297851563, -1185.96875),
		Vector(-6858.6372070313, 4989.9975585938, -1185.96875),
		Vector(-6908.6596679688, 4986.8334960938, -1185.96875),
		Vector(-6958.2875976563, 4978.224609375, -1185.96875),
		Vector(-6985.4887695313, 4930.4345703125, -1185.96875),
		Vector(-6914.9848632813, 4916.3642578125, -1185.96875),
		Vector(-6852.330078125, 4925.095703125, -1185.96875),
		Vector(-6795.1953125, 4926.0063476563, -1185.96875),
		Vector(-6739.9125976563, 4928.724609375, -1185.96875),
		Vector(-6666.0771484375, 4912.9096679688, -1185.96875),
		Vector(-6662.7534179688, 4856.7065429688, -1185.96875),
		Vector(-6741.4838867188, 4869.775390625, -1185.96875),
		Vector(-6804.4106445313, 4871.4243164063, -1185.96875),
		Vector(-6870.8676757813, 4867.0581054688, -1185.96875),
		Vector(-6919.8579101563, 4865.6630859375, -1185.96875),
		Vector(-6969.8852539063, 4850.3842773438, -1185.96875),
	}
}

function BR2_Get_914_1_Pos()
	return Vector(709.000000, -832.000000, -8131.000000)
end

function BR2_Get_914_2_Pos()
	return Vector(710.289978, -832.000000, -8149.000000)
end

print("[Breach2] Shared mapconfig loaded!")
