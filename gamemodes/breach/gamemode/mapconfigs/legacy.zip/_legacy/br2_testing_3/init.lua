
MAPCONFIG = {}

function form_basic_item_info(class)
	return {class = class, ammo = 0, name = weapons.Get(class).PrintName}
end

MAPCONFIG.ITEM_GENERATION_GROUPS = {
	["LCZ"] = {
		{"item_gasmask", 1},
		{"item_medkit", 1},
		{"item_pills", 2},
		{"item_radio", 1},
		{"keycard_level1", 2},
		{"keycard_level2", 3},
		{"keycard_playing", 1},
		{"keycard_master", 1},
		{"item_battery_9v", 4},
	},
	["LCZ_SECONDARY"] = {
		{"keycard_level3", 2},
		{"kanade_tfa_pipe", 1},
		{"kanade_tfa_crowbar", 1},
		{"item_medkit", 1},
		{"item_nvg", 1},
		{"kanade_tfa_m1911", 1},
		{"item_nvg", 1},
	},
	["HCZ"] = {
		{"keycard_level2", 1},
		{"keycard_level3", 2},
		{"keycard_level4", 1},
		{"item_medkit", 1},
		{"item_nvg", 1},
		{"item_radio", 1},
		{"item_gasmask", 1},
		{"item_battery_9v", 2},
		{"item_pills", 1},
		{"item_battery_9v", 1},
	},
	["EZ"] = {
		{"keycard_level4", 1},
		{"keycard_level5", 1},
		{"item_medkit", 1},
		{"item_nvg", 1},
		{"item_pills", 2},
		{"kanade_tfa_axe", 1},
		{"kanade_tfa_stunbaton", 1},
		{"kanade_tfa_m590", 1},
		{"item_battery_9v", 1},
	},
	["HCZ_035"] = {
		{"kanade_tfa_mp5k", 1},
		{"kanade_tfa_beretta", 1},
		{"item_c4", 1},
	}
}

MAPCONFIG.OUTFIT_GENERATION_GROUPS = {
	["LCZ"] = {
		{"class_d", 4},
		{"scientist", 3},
		{"janitor", 2},
		{"medic", 1},
	},
	["LCZ_ARMORY"] = {
		{"guard", 2},
	},
	["HCZ"] = {
		{"guard", 1},
		{"hazmat", 1},
	},
	["EZ"] = {
		{"guard", 3},
		{"scientist", 1},
	},
}

MAPCONFIG.BUTTONS = {
	-- FEMUR BREAKER
	{
		pos = Vector(1596.000000, 7100.500000, -8809.000000),
		level = 0,
		sounds = true,
		customcheck = function()
			print("FEMUR BREAKER")
			br2_next_femur_breaker = br2_next_femur_breaker or 0
			local tr = util.TraceLine({
				start = Vector(-2522,6345,-7616),
				endpos = Vector(-2510,6369,-7499),
			})
			if tr.Hit and br2_round_state_end - CurTime() then
				local scp_106 = ents.FindByClass("npc_cpt_scp_106")
				if table.Count(scp_106) > 0 then
					scp_106 = scp_106[1]
					timer.Simple(8, function()
						if IsValid(scp_106) then
							--scp_106:SetPos(Vector(-2364.876221, 6242.322754, -7514.968750))
							--scp_106.WasContained = true
							--scp_106.IsContained = true
							scp_106:Remove()
						end
					end)
					timer.Simple(28, function()
						--if IsValid(scp_106) then
							--scp_106:Remove()
							BroadcastLua("surface.PlaySound('cpthazama/scp/106Contain.mp3')")
						--end
					end)
					BroadcastLua('surface.PlaySound("breach2/scp/106/FemurBreaker.ogg")')
					br2_next_femur_breaker = CurTime() + 40
				end
			end
			return false
		end,
	},
	-- EZ MEDIC DOORS 2
	{
		pos = Vector(-241.009995, 4040.000000, -6084.000000),
		code = 1234,
		level = 0,
		sounds = true
	},
	-- EZ MEDIC DOORS 1
	{
		pos = Vector(-241.009995, 4040.000000, -6084.000000),
		level = 3,
		sounds = true
	},
	-- 008 1
	{
		pos = Vector(3024.000000, 4012.000000, -8549.000000),
		level = 3,
		sounds = true
	},
	-- 682 1
	{
		pos = Vector(1930.000000, 4958.000000, -8939.250000),
		level = 5,
		sounds = true
	},
	-- 457 2
	{
		pos = Vector(-2407.620117, 3069.000000, -7114.750000),
		level = 4,
		sounds = true
	},
	-- 457 1
	{
		pos = Vector(-2495.620117, 2848.000000, -7114.750000),
		level = 3,
		sounds = true
	},
	-- checkpoint elevator 2
	{
		pos = Vector(-648.000000, 768.000000, -7237.779785),
		level = 2,
		sounds = true
	},
	-- checkpoint elevator
	{
		pos = Vector(896.000000, 5368.000000, -6213.779785),
		level = 2,
		sounds = true
	},
	-- scp-106 doors
	{
		pos = Vector(-2624.120117, 5895.939941, -7114.750000),
		level = 4,
		sounds = true
	},
	-- checkpoint
	{
		pos = Vector(632.000000, 5408.000000, -6096.000000),
		level = 3,
		sounds = true
	},
	-- item room
	{
		pos = Vector(-3407.719971, 5407.799805, -7114.750000),
		level = 2,
		sounds = true
	},
	-- dupa
	{
		pos = Vector(1520.380005, 2847.879883, -7114.750000),
		level = 1,
		sounds = true
	},
	-- skull
	{
		pos = Vector(-343.000000, -1591.000000, -8155.000000),
		level = 2,
		sounds = true
	},
	-- 914
	{
		pos = Vector(384.000000, -958.500000, -8155.000000),
		level = 2,
		sounds = true
	},
	-- 314
	{
		pos = Vector(-1824.000000, -705.500000, -8155.000000),
		level = 2,
		sounds = true
	},
	-- checkpoint
	{
		pos = Vector(-688.000000, 504.000000, -8144.000000),
		level = 3,
		sounds = true
	},
	-- checkpoint
	{
		pos = Vector(1928.000000, 1088.000000, -8144.000000),
		level = 3,
		sounds = true
	},
	-- item room
	{
		pos = Vector(1128.000000, -757.000000, -8126.200195),
		level = 2,
		sounds = true
	},
	-- item room
	{
		pos = Vector(1336.000000, 1931.000000, -8126.200195),
		level = 1,
		sounds = true
	},
	-- item room
	{
		pos = Vector(-409.000000, -104.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	-- item room
	{
		pos = Vector(2427.000000, -648.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	-- armory room
	{
		pos = Vector(752.000000, -1515.000000, -8144.000000),
		level = 1,
		sounds = true
	},
	-- checkpoint doors
	{
		pos = Vector(1835.000000, 696.000000, -8144.000000),
		level = 2,
		sounds = true
	},
	-- 13 room
	{
		pos = Vector(504.000000, 547.000000, -8144.000000),
		level = 1,
		sounds = true
	},
	-- SCP 079
	{
		pos = Vector(-3952.000000, 4328.000000, -7107.500000),
		level = 3,
		sounds = true
	},
	/*
	--near SCP-173 doors
	{
		pos = Vector(-696.000000, 1685.000000, -7888.000000),
		level = 2,
		sounds = false,
		--customcheck = function() return (game_state != GAMESTATE_PREPARING) end,
		
	},
	*/
	--914 1
	{
		pos = Vector(709.000000, -832.000000, -8131.000000),
		level = 0,
		sounds = false,
		customcheck = function()
			return false
		end,
	},
	--914 2
	{
		pos = Vector(710.289978, -832.000000, -8149.000000),
		level = 0,
		sounds = false,
		customcheck = function()
			return false
			--return BR2_Handle914_Start()
		end,
	},
	{
		pos = Vector(2795.000000, -680.000000, -8144.000000),
		level = 1,
		sounds = true
	},
--HCZ

	--CHECKPOINT
	{
		pos = Vector(-688.000000, 504.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	--MELON ROOM
	{
		pos = Vector(3024.000000, 4012.000000, -8549.000000),
		level = 3,
		sounds = true
	},
	--682 code
	{
		pos = Vector(-2208.120117, 4767.939941, -7114.750000),
		level = 0,
		code = 1234,
		sounds = true
	},
	--cont room
	{
		pos = Vector(-3049.120117, 3943.929932, -7114.750000),
		level = 3,
		sounds = true
	},
	--armory
	{
		pos = Vector(-2759.000000, 4250.000000, -7107.500000),
		level = 3,
		sounds = true
	},
	--water room
	{
		pos = Vector(680.000000, 2209.000000, -7114.750000),
		level = 3,
		sounds = true
	},
	--item room
	{
		pos = Vector(1448.000000, 576.000000, -7114.750000),
		level = 3,
		sounds = true
	},


	{
		pos = Vector(408.000000, 704.000000, -7114.750000),
		level = 0,
		code = 1234,
		sounds = false
	},
	{
		pos = Vector(4169.000000, 1704.000000, -8555.000000),
		level = 0,
		code = 1234,
		sounds = false
	},
	{
		pos = Vector(1409.825439, 885.000000, -6083.000000),
		level = 0,
		code = 1234,
		sounds = false
	},
	--armory
	{
		pos = Vector(-1096.010010, 1016.000000, -7114.750000),
		level = 3,
		sounds = true
	},
	--035 main
	{
		pos = Vector(512.000000, 1112.000000, -7114.750000),
		level = 3,
		sounds = true
	},
	--armory
	{
		pos = Vector(-2768.000000, 4248.000000, -7123.500000),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(-2408.000000, 2997.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(811.000000, 1896.000000, -7120.000000),
		level = 4,
		sounds = true
	},
	{
		pos = Vector(1491.000000, 576.000000, -7120.000000),
		level = 1,
		sounds = true
	},
	--682
	{
		pos = Vector(1930.000000, 4956.000000, -8939.250000),
		level = 1,
		sounds = true
	},
	--008
	{
		pos = Vector(3081.000000, 5032.000000, -8555.000000),
		level = 1,
		sounds = true
	},
	--checkpoint
	{
		pos = Vector(1200.000000, 3544.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	--checkpoint
	{
		pos = Vector(1928.000000, 1088.000000, -7120.000000),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(-1139.000000, 1016.000000, -7120.000000),
		level = 2,
		sounds = true
	},
	--checkpoint
	{
		pos = Vector(632.000000, 5408.000000, -7120.000000),
		level = 3,
		sounds = true
	},

--EZ
	--checkpoint
	{
		pos = Vector(1200.000000, 3544.000000, -6096.000000),
		level = 3,
		sounds = true
	},
	--checkpoint elevator
	{
		pos = Vector(1240.000000, 3808.000000, -6213.779785),
		level = 3,
		sounds = true
	},
	{
		pos = Vector(699.000000, 3200.000000, -6096.000000),
		level = 1,
		sounds = true
	},
	{
		pos = Vector(277.000000, 4280.000000, -6080.000000),
		level = 2,
		sounds = true
	},
	{
		pos = Vector(-808.000000, 1515.000000, -6032.000000),
		level = 2,
		sounds = true
	},
	{
		pos = Vector(-357.000000, 4040.000000, -6096.000000),
		level = 1,
		sounds = true
	},
	{
		pos = Vector(-283.510010, 4040.000000, -6096.000000),
		level = 1,
		sounds = true
	},

	-- big doors
	{
		pos = Vector(160.000000, -488.000000, -6099.250000),
		level = 3,
		sounds = true
	},
--OUTSIDE
	{
		pos = Vector(-1749.000000, -2440.000000, 560.000000),
		level = 2,
		sounds = true
	},
}

local pd_spawn_height = -15469
MAPCONFIG.POCKETDIMENSION_SPAWNS = {
	Vector(23.301473617554, -10.723201751709, pd_spawn_height),
	Vector(-18.240295410156, -42.02742767334, pd_spawn_height),
	Vector(-15.765701293945, 1.2051422595978, pd_spawn_height),
	Vector(42.893028259277, -56.13041305542, pd_spawn_height),
	Vector(28.208240509033, 38.836673736572, pd_spawn_height),
	Vector(79.399269104004, -18.306934356689, pd_spawn_height),
	Vector(-14.227056503296, 60.410781860352, pd_spawn_height),
	Vector(-45.420238494873, 35.765735626221, pd_spawn_height),
	Vector(-54.177387237549, -14.005828857422, pd_spawn_height),
	Vector(-54.228298187256, -57.058036804199, pd_spawn_height),
	Vector(3.9432487487793, -88.955764770508, pd_spawn_height),
	Vector(-90.107643127441, -16.603729248047, pd_spawn_height),
	Vector(-80.204605102539, 37.095993041992, pd_spawn_height),
	Vector(-46.530025482178, 85.437194824219, pd_spawn_height),
	Vector(68.469787597656, 35.14973449707, pd_spawn_height),
}

br2_914_on_map = true

include("corpses.lua")
include("functions.lua")
--include("mapconfigs/br2_testing_3/init.lua")

print("[Breach2] Serverside mapconfig loaded!")
