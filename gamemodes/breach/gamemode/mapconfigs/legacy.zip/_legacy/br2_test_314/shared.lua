
local ambient_general = {
	"breach2/ambient/general/Ambient1.ogg",
	"breach2/ambient/general/Ambient2.ogg",
	"breach2/ambient/general/Ambient3.ogg",
	"breach2/ambient/general/Ambient4.ogg",
	"breach2/ambient/general/Ambient5.ogg",
	"breach2/ambient/general/Ambient6.ogg",
	"breach2/ambient/general/Ambient7.ogg",
	"breach2/ambient/general/Ambient8.ogg",
	"breach2/ambient/general/Ambient9.ogg",
	"breach2/ambient/general/Ambient10.ogg",
	"breach2/ambient/general/Ambient11.ogg",
	"breach2/ambient/general/Ambient12.ogg",
	"breach2/ambient/general/Ambient13.ogg",
	"breach2/ambient/general/Ambient14.ogg",
	"breach2/ambient/general/Ambient15.ogg",
}

local ambient_lcz = {
	"breach2/ambient/zone1/Ambient1.ogg",
	"breach2/ambient/zone1/Ambient2.ogg",
	"breach2/ambient/zone1/Ambient3.ogg",
	"breach2/ambient/zone1/Ambient4.ogg",
	"breach2/ambient/zone1/Ambient5.ogg",
	"breach2/ambient/zone1/Ambient6.ogg",
	"breach2/ambient/zone1/Ambient7.ogg",
	"breach2/ambient/zone1/Ambient8.ogg",
}

local ambient_hcz = {
	"breach2/ambient/zone2/Ambient1.ogg",
	"breach2/ambient/zone2/Ambient2.ogg",
	"breach2/ambient/zone2/Ambient3.ogg",
	"breach2/ambient/zone2/Ambient4.ogg",
	"breach2/ambient/zone2/Ambient5.ogg",
	"breach2/ambient/zone2/Ambient6.ogg",
	"breach2/ambient/zone2/Ambient7.ogg",
	"breach2/ambient/zone2/Ambient8.ogg",
	"breach2/ambient/zone2/Ambient9.ogg",
	"breach2/ambient/zone2/Ambient10.ogg",
	"breach2/ambient/zone2/Ambient11.ogg",
}

local ambient_ez = {
	"breach2/ambient/zone3/Ambient1.ogg",
	"breach2/ambient/zone3/Ambient2.ogg",
	"breach2/ambient/zone3/Ambient3.ogg",
	"breach2/ambient/zone3/Ambient4.ogg",
	"breach2/ambient/zone3/Ambient5.ogg",
	"breach2/ambient/zone3/Ambient6.ogg",
	"breach2/ambient/zone3/Ambient7.ogg",
	"breach2/ambient/zone3/Ambient8.ogg",
	"breach2/ambient/zone3/Ambient9.ogg",
	"breach2/ambient/zone3/Ambient10.ogg",
	"breach2/ambient/zone3/Ambient11.ogg",
	"breach2/ambient/zone3/Ambient12.ogg",
}

MAPCONFIG.EnableGamemodeMusic = true
MAPCONFIG.EnableAmbientSounds = true
MAPCONFIG.GeneralAmbientSounds = ambient_general
MAPCONFIG.CommotionSounds = {
	"breach2/intro/Commotion/Commotion1.ogg",
	"breach2/intro/Commotion/Commotion2.ogg",
	"breach2/intro/Commotion/Commotion3.ogg",
	"breach2/intro/Commotion/Commotion4.ogg",
	"breach2/intro/Commotion/Commotion5.ogg",
	"breach2/intro/Commotion/Commotion6.ogg",
	"breach2/intro/Commotion/Commotion7.ogg",
	"breach2/intro/Commotion/Commotion8.ogg",
	"breach2/intro/Commotion/Commotion9.ogg",
	"breach2/intro/Commotion/Commotion10.ogg",
	"breach2/intro/Commotion/Commotion11.mp3",
	"breach2/intro/Commotion/Commotion12.ogg",
	"breach2/intro/Commotion/Commotion13.mp3",
	"breach2/intro/Commotion/Commotion14.mp3",
	"breach2/intro/Commotion/Commotion15.mp3",
	"breach2/intro/Commotion/Commotion16.ogg",
	"breach2/intro/Commotion/Commotion17.ogg",
	"breach2/intro/Commotion/Commotion18.ogg",
	"breach2/intro/Commotion/Commotion19.ogg",
	"breach2/intro/Commotion/Commotion20.ogg",
	"breach2/intro/Commotion/Commotion21.ogg",
	"breach2/intro/Commotion/Commotion22.mp3",
	"breach2/intro/Commotion/Commotion23.ogg",
	"breach2/intro/Bang2.ogg",
	"breach2/intro/Bang3.ogg",
}

/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/Alarm2_1.ogg", 6},
	{"breach2/alarm/Alarm2_2.ogg", 5},
	{"breach2/alarm/Alarm2_3.ogg", 7},
	{"breach2/alarm/Alarm2_4.ogg", 10},
	{"breach2/alarm/Alarm2_5.ogg", 6},
	{"breach2/alarm/Alarm2_6.ogg", 8},
	{"breach2/alarm/Alarm2_7.ogg", 7},
	{"breach2/alarm/Alarm2_8.ogg", 4},
	{"breach2/alarm/Alarm2_9.ogg", 4},
	{"breach2/alarm/Alarm2_10.ogg", 15}
}
*/

MAPCONFIG.FirstSounds = {
	{"breach2/alarm/breach_alarm.ogg", 72},
}
MAPCONFIG.FirstSoundsLength = 72 -- length of all of FirstSounds in seconds


-- give breach_tool_cameraplacer
MAPCONFIG.CAMERAS = {
	{
		name = "Light Containment Zone",
		cameras = {
			{name = "lcz_corridor_1", pos = Vector(1444,-112,-8020), ang = Angle(0,180,0)},
			{name = "lcz_corridor_2", pos = Vector(1581,-272,-8034), ang = Angle(0,0,0)},
			{name = "lcz_corridor_3", pos = Vector(1148,-1940,-8036), ang = Angle(0,263,0)},
			{name = "lcz_corridor_4", pos = Vector(48,219,-8025), ang = Angle(0,90,0)},
			{name = "lcz_corridor_5", pos = Vector(166,2576,-8026), ang = Angle(0,180,0)},
			{name = "lcz_corridor_6", pos = Vector(-499,-768,-7991), ang = Angle(0,180,0)},
			{name = "lcz_corridor_7", pos = Vector(1446,1168,-8040), ang = Angle(0,180,0)},
			{name = "lcz_office_room_1", pos = Vector(-944,864,-7974), ang = Angle(0,90,0)},
			{name = "lcz_storage_room_1", pos = Vector(912,-585,-7967), ang = Angle(0,-90,0)},
			{name = "lcz_cont_room_scp012", pos = Vector(-1068,224,-8286), ang = Angle(0,180,0)},
			{name = "lcz_cont_room_scp173", pos = Vector(-56,1230,-7924), ang = Angle(0,90,0)},
		}
	},
	{
		name = "Heavy Containment Zone",
		cameras = {
			{name = "hcz_corridor_1", pos = Vector(-376,5011,-7048), ang = Angle(0,-90,0)},
			{name = "hcz_corridor_2", pos = Vector(-1424,1084,-7016), ang = Angle(0,-90,0)},
			{name = "hcz_corridor_3", pos = Vector(-1265,4224,-7034), ang = Angle(0,180,0)},
			{name = "hcz_corridor_4", pos = Vector(-768,2441,-7055), ang = Angle(0,-90,0)},
			{name = "hcz_cont_room_2", pos = Vector(960,2238,-7014), ang = Angle(0,-90,0)},
			{name = "hcz_cont_room_scp682", pos = Vector(-376,5011,-7048), ang = Angle(0,-90,0)},
			{name = "hcz_cont_room_scp457", pos = Vector(-2680,3083,-7014), ang = Angle(0,-90,0)},
			{name = "hcz_cont_room_scp106", pos = Vector(-2143,6712,-6962), ang = Angle(0,180,0)},
			{name = "hcz_cont_room_scp008", pos = Vector(-1610,4520,-7061), ang = Angle(0,0,0)},
		}
	},
	{
		name = "Entrance Zone",
		cameras = {
			{name = "ez_checkpoint_1", pos = Vector(1464,5437,-7061), ang = Angle(0,180,0)},
			{name = "ez_checkpoint_2", pos = Vector(1104,4309,-7061), ang = Angle(0,-90,0)},
			{name = "ez_gate_a", pos = Vector(2450,7130,-7061), ang = Angle(0,-90,0)},
			{name = "ez_gate_b", pos = Vector(5750,5113,-7060), ang = Angle(0,0,0)},
			{name = "ez_evac_shelter_1", pos = Vector(3717,5314,-7061), ang = Angle(0,0,0)},
			{name = "ez_security_1", pos = Vector(4158,7000,-7038), ang = Angle(0,-90,0)},
			{name = "ez_security_2", pos = Vector(5786,5537,-7037), ang = Angle(0,0,0)},
			{name = "ez_serverfarm", pos = Vector(4311,3924,-7060), ang = Angle(0,0,0)},
			{name = "ez_corridor_1", pos = Vector(2458,5994,-7060), ang = Angle(0,-90,0)},
			{name = "ez_corridor_2", pos = Vector(3738,5992,-7061), ang = Angle(0,-90,0)},
		}
	},
}

MAPCONFIG.BUTTONS_2D = {}
MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS = {
	on_open = function(button)
		TryToOpenContainer(button)
	end,
	buttons = {
		
		--LCZ
		{pos = Vector(-2210,535,-8293), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_EARLIEST"}, -- EARLY_CLASSD-BOX
		{pos = Vector(-975,1003,-8156), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- FIRST OFFICE-1
		{pos = Vector(-975,1035,-8156), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- FIRST OFFICE-2
		{pos = Vector(-657,1968,-7902), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- FIRST OFFICE-3
		{pos = Vector(-1481,792,-8022), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- SCP_173-1
		{pos = Vector(-657,2000,-7902), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_DOC_173"}, -- SCP_173-2
		{pos = Vector(-1046,108,-8414), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_012_LOOT"}, -- SCP_012
		{pos = Vector(-914,-633,-8162), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- CABINETS-CRATE
		{pos = Vector(-673,-639,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- CABINETS-1
		{pos = Vector(-591,-707,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- CABINETS-2
		{pos = Vector(624,1891,-8139), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- TERMINAL_ITEM_ROOM-1
		{pos = Vector(494,2138,-8146), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- TERMINAL_ITEM_ROOM-CRATE
		{pos = Vector(505,1993,-8139), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- TERMINAL_ITEM_ROOM-BOX
		{pos = Vector(752,2125,-8174), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- TERMINAL_ITEM_ROOM-2
		{pos = Vector(1489,1770,-8158), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- YELLOW_ITEM_ROOM-1
		{pos = Vector(1489,1942,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- YELLOW_ITEM_ROOM-2
		{pos = Vector(259,393,-8166), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- SCARE_ROOM-BOX
		{pos = Vector(244,484,-8135), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- SCARE_ROOM-CRATE
		{pos = Vector(244,484,-8135), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_WEAPON_LOOT"}, -- SCARE_ROOM-BIGCRATE
		{pos = Vector(1129,945,-8143), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- OFFICES-CRATE1
		{pos = Vector(958,812,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- OFFICES_1_1-CRATE
		{pos = Vector(1450,813,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- OFFICES_1_2-1
		{pos = Vector(1009,1499,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- OFFICES-CRATE2
		{pos = Vector(1499,1322,-8138), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- OFFICES-BOX
		{pos = Vector(1016,1321,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- OFFICES_2_1-1
		{pos = Vector(1513,1384,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- OFFICES_2_2-1
		{pos = Vector(1599,-64,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- VENT_ROOM-1
		{pos = Vector(1758,196,-8116), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- VENT_ROOM-CRATE
		{pos = Vector(2059,199,-8173), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ADDITIONAL_LOOT"}, -- VENT_ROOM-2
		{pos = Vector(1088,-575,-8145), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- BIG_YELLOW_ROOM-CRATE
		{pos = Vector(1089,-657,-8156), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- BIG_YELLOW_ROOM-1
		{pos = Vector(496,-1097,-8145), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ADDITIONAL_LOOT"}, -- 914-CRATE
		{pos = Vector(533,-1116,-8158), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ADDITIONAL_LOOT"}, -- SCP_914-1
		--{pos = Vector(2460,-970,-8503), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ADDITIONAL_LOOT"}, -- WATER_ROOM-CRATE
		--{pos = Vector(2394,-1062,-8170), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- WATER_ROOM-1
		{pos = Vector(1674,-1753,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- SCP_205-1
		{pos = Vector(1932,-1491,-8157), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ADDITIONAL_LOOT"}, -- SCP_205-2
		{pos = Vector(-2024,-543,-8158), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- SCP_372-1
		{pos = Vector(-2517,-579,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_THIRD_LOOT"}, -- SCP_372-BOX
		{pos = Vector(2262,492,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- LONG_HALLWAY-BOX
		{pos = Vector(617,-2392,-8170), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- SECURITY_GATEWAY-BOX
		{pos = Vector(441,-1421,-8134), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ARMORY_LOOT"}, -- ARMORY-CRATE1
		{pos = Vector(712,-1684,-8159), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ARMORY_LOOT"}, -- ARMORY-CRATE2
		{pos = Vector(-176,-1202,-8176), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_FIRST_LOOT"}, -- SKULL-1
		{pos = Vector(-553,-42,-8147), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_SECOND_LOOT"}, -- NEAR_CHECKPOINT_STORAGE_ROOM-CRATE
		{pos = Vector(237,97,-8165), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_ADDITIONAL_LOOT"}, -- SCARE_ROOM_HIDING-BOX




		--HCZ
		{pos = Vector(-1179,1096,-7128), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_SECOND"}, -- KINDA_ARMORY-CRATE
		{pos = Vector(-1176,1099,-7111), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_GUNS"}, -- KINDA_ARMORY-BIGCRATE
		{pos = Vector(-2188,3126,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- SCP_457-BOX
		{pos = Vector(-2468,3125,-7152), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- SCP_457-1
		{pos = Vector(1554,1725,-7379), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- TOXIC_ROOM-CRATE
		{pos = Vector(1691,2824,-7134), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- NEAR_EZ_CHECKPOINT-1
		{pos = Vector(1258,538,-7124), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- NEAR_CHECKPOINT-CRATE
		{pos = Vector(368,643,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"}, -- SCP_035-BOX
		{pos = Vector(331,638,-7156), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"}, -- SCP_035-CRATE1
		{pos = Vector(297,647,-7156), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_035"}, -- SCP_035-CRATE2
		{pos = Vector(9,4494,-7269), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- UNDER_GAS-BOX
		{pos = Vector(184,5043,-7134), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- NEAR_GAS-1
		{pos = Vector(-1496,3648,-7121), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- GREEN_ROOM-1
		{pos = Vector(-3038,3340,-7142), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_SECOND"}, -- DEAD_SCIENTIST_ROOM-CRATE
		{pos = Vector(-3811,4209,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- NEAR_SCP_079-BOX
		{pos = Vector(-3843,4603,-7254), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- SCP_079-CRATE
		{pos = Vector(-2563,5380,-7397), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- SCP_682-CRATE
		{pos = Vector(-2701,6795,-7406), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_FIRST"}, -- SCP_106-BOX
		{pos = Vector(-2775,6795,-7379), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_GUNS"}, -- SCP_106-BIGCRATE
		{pos = Vector(-2369,4446,-7128), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_GUNS"}, -- STORAGE_ROOM-BIGCRATE
		{pos = Vector(-2488,4513,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_SECOND"}, -- STORAGE_ROOM-1
		{pos = Vector(-2744,4513,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_SECOND"}, -- STORAGE_ROOM-2
		{pos = Vector(-2895,4320,-7126), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ_SECOND"}, -- STORAGE_ROOM-BOX
		



		--EZ
		{pos = Vector(1861,4113,-7151), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_OFFICES"}, -- OFFICE_1B-1 / CODE
		{pos = Vector(1936,4103,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_OFFICES"}, -- OFFICE_1A-BOX / CODE
		{pos = Vector(2060,3910,-7150), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_OFFICES"}, -- OFFICE_1A-1 / CODE
		{pos = Vector(2837,5272,-7118), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_SPECIAL"}, -- SHARED CONF ROOM-CRATE / KEYCARD
		{pos = Vector(4228,4606,-7272), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- CAFETERIA-BOX
		{pos = Vector(3029,4117,-7215), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- 2LEVEL_OFFICE1-1
		{pos = Vector(3147,4124,-7215), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- 2LEVEL_OFFICE1-2
		{pos = Vector(3343,4118,-7215), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- 2LEVEL_OFFICE1-3
		{pos = Vector(3388,6023,-7214), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- 2LEVEL_OFFICE2-1
		{pos = Vector(4447,6764,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- SECURITY_GATEWAY1-BOX
		{pos = Vector(4403,6765,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- SECURITY_GATEWAY1-1
		{pos = Vector(5344,7271,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-1
		{pos = Vector(5344,7303,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-2
		{pos = Vector(5344,7335,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-3
		{pos = Vector(5344,7367,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-4
		{pos = Vector(5344,7629,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-5
		{pos = Vector(5344,7661,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-6
		{pos = Vector(5344,7693,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-7
		{pos = Vector(5344,7725,-7133), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONFROOM"}, -- CONFERENCE_ROOM-8
		{pos = Vector(5062,7778,-6959), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_SPECIAL"}, -- ELECTRICAL_CENTER-CRATE
		{pos = Vector(5032,7418,-6972), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_SPECIAL"}, -- ELECTRICAL_CENTER-BIGCRATE
		{pos = Vector(2007,5552,-7141), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_OFFICES"},  -- OFFICE_2A-BOX / CODE
		{pos = Vector(1793,5577,-7102), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_2B_BOXES"},  -- OFFICE_2B-BOXES1 / CODE
		{pos = Vector(1805,5586,-7139), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_2B_BOXES"},  -- OFFICE_2B-BOXES2 / CODE
		{pos = Vector(1739,5590,-7127), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_2B_BOXES"},  -- OFFICE_2B-BOXES3 / CODE
		{pos = Vector(1869,5569,-7098), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_2B_BOXES"},  -- OFFICE_2B-BOXES4 / CODE
		{pos = Vector(3138,7022,-7150), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- BASIC_OFFICE_1-1
		{pos = Vector(3087,6735,-7152), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- BASIC_OFFICE_1-2
		{pos = Vector(4445,5924,-7147), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- BASIC_OFFICE_2-1
		{pos = Vector(4447,5823,-7152), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- BASIC_OFFICE_2-2
		{pos = Vector(4276,5903,-7153), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- BASIC_OFFICE_2-3
		{pos = Vector(4163,6170,-7119), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_SPECIAL"}, -- BASIC_OFFICE_2-CRATE
		{pos = Vector(1099,6093,-7249), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_SPECIAL"}, -- 2LEVEL_OFFICE2-CRATE
		{pos = Vector(1328,6040,-7284), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- 2LEVEL_OFFICE2-1
		{pos = Vector(1443,6219,-7273), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- 2LEVEL_OFFICE2-BOX
		{pos = Vector(1917,6158,-7112), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- DARK_ROOM / KEYCARD
		{pos = Vector(5414,5251,-7389), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- SERVER_HUB-1
		{pos = Vector(5812,4740,-7397), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- SERVER_HUB-BOX / KEYCARD / HIDDEN
		{pos = Vector(5818,5750,-7140), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- SECURITY_GATEWAY2-CRATE
		{pos = Vector(5795,6008,-7134), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- SECURITY_GATEWAY2-1
		{pos = Vector(5304,6362,-7082), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_HEADOFFICE"}, -- HEAD_OFFICE-BOX
		{pos = Vector(5190,6288,-7087), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_HEADOFFICE"}, -- HEAD_OFFICE-1
		{pos = Vector(1373,5028,-7111), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- MEDBAY-CRATE
		{pos = Vector(1518,5271,-7115), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_MEDBAY"}, -- MEDBAY-FIRSTAID_STATION
		{pos = Vector(6983,4683,-6992), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- GATEB
		--{pos = XXXXXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"},
	}
}

MAP_SCP_294_Coins = 0

MAPCONFIG.BUTTONS_2D.SIMPLE = {
	on_open = function(button)
		SimpleButtonUse(button)
	end,
	buttons = {
		{name = "SCP-294-Keyboard", pos = Vector(3427,4736,-7242), canSee = DefaultItemContainerCanSee, func_cl = function()
		end, func_sv = function(ply)
			if MAP_SCP_294_Coins == 2 then
				ply:SendLua("OpenSCP_294()")
			elseif MAP_SCP_294_Coins == 1 then
				ply:PrintMessage(HUD_PRINTTALK, "You need to insert one more coin")
			else
				ply:PrintMessage(HUD_PRINTTALK, "You need to insert two coins")
			end
		end},

		{name = "SCP-294-Coiner", pos = Vector(3427,4755,-7239), canSee = DefaultItemContainerCanSee, func_cl = function()
		end, func_sv = function(ply)
			if MAP_SCP_294_Coins == 2 then
				ply:PrintMessage(HUD_PRINTTALK, "Coins are already in")
			else
				for k,v in pairs(ply.br_special_items) do
					if v.class == "coin" then
						ply:PrintMessage(HUD_PRINTTALK, "Inserted a coin in")
						sound.Play("ambient/office/coinslot1.wav", Vector(3427,4755,-7239), 75, 100, 1)
						MAP_SCP_294_Coins = MAP_SCP_294_Coins + 1
						table.RemoveByValue(ply.br_special_items, v)
						return
					end
				end
				ply:PrintMessage(HUD_PRINTTALK, "You don't have any coins!")
			end
		end},

		{name = "SCP-1162", pos = Vector(903,882,-8143), canSee = DefaultItemContainerCanSee, func_cl = function() surface.PlaySound("breach2/pickitem2.ogg") end,  func_sv = function(ply)
			local weps = {}
			for k,v in pairs(ply:GetWeapons()) do
				if v.Pickupable == true or v.droppable == true then
					table.ForceInsert(weps, v)
				end
			end
			if table.Count(weps) == 0 then
				ply:TakeDamage(20, ply, ply)
			else
				local rnd_wep = table.Random(weps)
				local rnd_classes = {"keycard_master", "keycard_playing", "item_battery_9v", "item_pills", "item_radio", "keycard_level1", "keycard_level2", "item_gasmask"}
				--for k,v in pairs(BR2_SPECIAL_ITEMS) do
				--	if v.scp_1162_class then table.ForceInsert(rnd_classes, {v.scp_1162_class, v.scp_1162}) end
				--end
				
				local rnd_class = table.Random(rnd_classes)
				local ent = nil
				if istable(rnd_class) then
					ent = ents.Create(rnd_class[1])
				else
					ent = ents.Create(rnd_class)
				end
				if IsValid(ent) then
					ent:SetPos(Vector(893,882,-8144))
					ent:SetNWBool("isDropped", true)
					ent:Spawn()
					if istable(rnd_class) then
						rnd_class[2](ply, ent)
					end
					ply:StripWeapon(rnd_wep:GetClass())
				end
			end
		end},
	}
}

MAPCONFIG.BUTTONS_2D.SODAMACHINES = {
	on_open = function(button)
		SodaMachineUse(button)
	end,
	buttons = {
		-- 2nd O   8 clicks inside
		{
			pos = Vector(2603,5649,-7120),
			pos_out = Vector(2603.902832, 5670.911621, -7150.751465),
			ang_out = Angle(0.888, -179.828, -89.229),
			pos_inside = Vector(2609,5672,-7124),
			canSee = DefaultItemContainerCanSee,
			mdl = "models/props/cs_office/Water_bottle.mdl",
			class = "bottle_water",
			name = "Water Bottle"
		},
		{
			pos = Vector(-159,-84,-8144),
			pos_out = Vector(-173.84223937988, -97.615051269531, -8174.0278320313),
			ang_out = Angle(-58.825607299805, 134.92375183105, 89.877410888672),
			pos_inside = Vector(-181,-93,-8148),
			canSee = DefaultItemContainerCanSee,
			mdl = "models/props/cs_office/Water_bottle.mdl",
			class = "bottle_water",
			name = "Water Bottle"
		},
		{
			pos = Vector(1844,6858,-7119),
			pos_out = Vector(1822.7325439453, 6858.8002929688, -7150.1079101563),
			ang_out = Angle(-57.745758056641, 90.007453918457, 90.113433837891),
			pos_inside = Vector(1821,6864,-7124),
			canSee = DefaultItemContainerCanSee,
			mdl = "models/props/cs_office/Water_bottle.mdl",
			class = "bottle_water",
			name = "Water Bottle"
		},
		{
			pos = Vector(3425,5015,-7249),
			pos_out = Vector(3424.176270, 4993.185547, -7278.706055),
			ang_out = Angle(-57.571, -0.910, -90.099),
			pos_inside = Vector(3419,4992,-7253),
			canSee = DefaultItemContainerCanSee,
			mdl = "models/props/cs_office/Water_bottle.mdl",
			class = "bottle_water",
			name = "Water Bottle"
		},
		{
			pos = Vector(3868,4927,-7236),
			pos_out = Vector(3841.672119, 4928.115723, -7270.536621),
			ang_out = Angle(-11.846, 94.118, 86.647),
			pos_inside = Vector(3842,4936,-7242),
			canSee = DefaultItemContainerCanSee,
			mdl = "models/props_junk/PopCan01a.mdl",
			class = "popcan",
			name = "Can of Soda"
		},
	}
}

MAPCONFIG.BUTTONS_2D.OUTFITTERS = {
	on_open = function(button)
		if LocalPlayer():GetOutfit().can_change_outfits == false then
			--chat.AddText(Color(255, 255, 255), "You cannot change your outfit")
			chat.AddText(Color(255, 255, 255), "You couldn't find anything useful...")

			return
		end
		net.Start("br_use_outfitter")
			net.WriteVector(button.pos)
		net.SendToServer()
	end,
	buttons = {
		{pos = Vector(-777,-707,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(960,-1089,-8156), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(465,256,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(-330,-1207,-8158), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(959,912,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
		{pos = Vector(504,-1682,-8157), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ_ARMORY"},
		{pos = Vector(-3520,5473,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(1521,512,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-2636,5378,-7389), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(-3960,4894,-7273), canSee = DefaultOutfitterCanSee, item_gen_group = "HCZ"},
		{pos = Vector(5109,6417,-7069), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ_HOFFICE"},
		{pos = Vector(5352,5251,-7389), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		{pos = Vector(2904,6648,-7133), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		{pos = Vector(1104,6608,-7249), canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},
		--{pos = XXXXXXXXXXXXXXXX, canSee = DefaultOutfitterCanSee, item_gen_group = "EZ"},

	}
}

local special_terminal_settings = {
	hcz_storage_room = {
		class = "1",
		name = "Open/Close Storage Room 2b",
		type = "button",
		button_size = 720,
		server = {
			func = function(pl)
				BR2_SPECIAL_BUTTONS["spec_button_hcz_storage_room"]:Use(pl, pl, 3, 1)
			end
		}
	},
	ez_servers = {
		class = "5",
		name = "Restart the servers",
		type = "button",
		button_size = 640,
		server = {
			func = function(pl)
				BR2_SPECIAL_BUTTONS["spec_button_ez_server_room"]:Use(pl, pl, 3, 1)
			end
		}
	},
}

for i=1, 4 do
	special_terminal_settings["hcz_generator_"..i] = {
		class = tostring(i + 1),
		name = "Restart Generator "..i.."",
		type = "button",
		button_size = 600,
		server = {
			func = function(pl)
				BR2_SPECIAL_BUTTONS["spec_button_generator_"..i]:Use(pl, pl, 1, 1)
			end
		}
	}
end

MAPCONFIG.BUTTONS_2D.TERMINALS = {
	on_open = function(button)
		BR_Access_Terminal(button)
	end,
	buttons = {
	-- LCZ

		--CAFETERIA
		{name = "lcz_storage_area_3c-1a", pos = Vector(-2195,987,-8253), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_area_3c-1b", pos = Vector(-2195,950,-8253), canSee = DefaultTerminalCanSee},

		-- OFFICES
		{name = "lcz_office_1-1", pos = Vector(-959,908,-8143), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-2a", pos = Vector(-1012,1165,-8124), canSee = function() return CanSeeFrom(Vector(-1012,1151,-8125)) end},
		{name = "lcz_office_1-2b", pos = Vector(-972,1165,-8124), canSee = function() return CanSeeFrom(Vector(-971,1151,-8125)) end},
		{name = "lcz_office_1-3", pos = Vector(-1034,1224,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-4", pos = Vector(-1034,1375,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-5", pos = Vector(-1213,1373,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_6", pos = Vector(-1213,1220,-8143), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1_7", pos = Vector(-1213,1056,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-8", pos = Vector(-1249,1056,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-9", pos = Vector(-1249,1373,-8142), canSee = DefaultTerminalCanSee},
		
		-- STORAGE ROOMS
		{name = "lcz_storage_room_1-1", pos = Vector(1027,-559,-8141), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2-1", pos = Vector(743,2156,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2-2a", pos = Vector(763,2001,-8139), canSee = DefaultTerminalCanSee, special_functions = {special_terminal_settings.hcz_generator_4}},
		{name = "lcz_storage_room_2-2b", pos = Vector(763,1980,-8139), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2-2c", pos = Vector(744,2051,-8112), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_2-2d", pos = Vector(744,2028,-8112), canSee = DefaultTerminalCanSee},
		{name = "lcz_storage_room_3-1", pos = Vector(880,-1614,-8142), canSee = DefaultTerminalCanSee},
		
		-- CONTAINMENT ROOMS
		{name = "lcz_cont_room_1-1a", pos = Vector(-1980,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1981,-529,-8124)) end},
		{name = "lcz_cont_room_1_1b", pos = Vector(-1940,-513,-8124), canSee = function() return CanSeeFrom(Vector(-1940,-528,-8124)) end},
		{name = "lcz_cont_room_2_1a", pos = Vector(494,212,-8123), canSee = function() return CanSeeFrom(Vector(478,212,-8124)) end},
		{name = "lcz_cont_room_2_1b", pos = Vector(494,172,-8123), canSee = function() return CanSeeFrom(Vector(480,173,-8124)) end},
		{name = "lcz_cont_room_3_1a", pos = Vector(1886,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1941,-1504,-8123)) end},
		{name = "lcz_cont_room_3_1b", pos = Vector(1846,-1517,-8123), canSee = function() return CanSeeFrom(Vector(1900,-1504,-8123)) end},
		{name = "lcz_cont_room_4-1", pos = Vector(860,798,-8142), canSee = DefaultTerminalCanSee},
		{name = "lcz_cont_room_5-1a", pos = Vector(1890,829,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_cont_room_5-1b", pos = Vector(-2666,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "lcz_cont_room_5-2a", pos = Vector(-2720,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2735,5388,-7357)) end},
		{name = "lcz_cont_room_5-2b", pos = Vector(-2681,5405,-7356), canSee = function() return CanSeeFrom(Vector(-2697,5392,-7356)) end},

		-- CHECKPOINTS
		{name = "lcz_checkpoint_1-1a", pos = Vector(-430,430,-8124), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_1-1b", pos = Vector(-430,466,-8124), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_2-1a", pos = Vector(-429,430,-8123), canSee = DefaultTerminalCanSee},
		{name = "lcz_checkpoint_2-1b", pos = Vector(-429,466,-8123), canSee = DefaultTerminalCanSee},

	--HCZ
		-- OFFICES
		{name = "hcz_office_4-1", pos = Vector(-226,4969,-7243), canSee = DefaultTerminalCanSee, special_functions = {special_terminal_settings.hcz_generator_2}},


		-- STORAGE ROOMS
		{name = "hcz_storage_room_1-1a", pos = Vector(-1189,3442,-7100), canSee = function() return CanSeeFrom(Vector(-1233,3464,-7105)) end},
		{name = "hcz_storage_room_1-1b", pos = Vector(-1229,3442,-7100), canSee = function() return CanSeeFrom(Vector(-1233,3464,-7105)) end},
		{name = "hcz_storage_room_1-2a", pos = Vector(-1458,3442,-7100), canSee = function() return CanSeeFrom(Vector(-1454,3458,-7101)) end},
		{name = "hcz_storage_room_1-2b", pos = Vector(-1498,3442,-7100), canSee = function() return CanSeeFrom(Vector(-1454,3458,-7101)) end},
		{name = "hcz_storage_room_2-1a", pos = Vector(838,2296,-7099), canSee = DefaultTerminalCanSee},
		{name = "hcz_storage_room_2-1b", pos = Vector(874,2296,-7099), canSee = DefaultTerminalCanSee},

		{name = "hcz_electrical_room_1-1a", pos = Vector(5087,7500,-6947), canSee = DefaultTerminalCanSee},
		{name = "hcz_electrical_room_1-1b", pos = Vector(5087,7464,-6947), canSee = DefaultTerminalCanSee},


		-- CONTAINMENT ROOMS
		{name = "hcz_cont_room_1-1a", pos = Vector(605,923,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_1-1b", pos = Vector(605,887,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_2-1a", pos = Vector(838,2301,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_2-1b", pos = Vector(874,2301,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3-1a", pos = Vector(-2526,2724,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3-1b", pos = Vector(-2561,2724,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3-2a", pos = Vector(-2659,3156,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_3-2b", pos = Vector(-2623,3156,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_4-1a", pos = Vector(-3004,3722,-7108), canSee = DefaultTerminalCanSee, special_functions = {special_terminal_settings.hcz_storage_room}},
		{name = "hcz_cont_room_4-1b", pos = Vector(-3004,3686,-7108), canSee = DefaultTerminalCanSee, special_functions = {special_terminal_settings.hcz_generator_1}},
		{name = "hcz_cont_room_5-1a", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_5-1b", pos = Vector(-2629,5155,-7355), canSee = DefaultTerminalCanSee},
		{name = "hcz_cont_room_6-1", pos = Vector(-4070,4760,-7261), canSee = DefaultTerminalCanSee}, -- SCP_079_MAIN
		{name = "hcz_cont_room_6-2a", pos = Vector(-3586,4903,-7243), canSee = DefaultTerminalCanSee}, -- SCP_079
		{name = "hcz_cont_room_6-2b", pos = Vector(-3586,4867,-7243), canSee = DefaultTerminalCanSee}, -- SCP_079
		{name = "hcz_cont_room_6-3a", pos = Vector(-3623,4782,-7244), canSee = DefaultTerminalCanSee}, -- SCP_079
		{name = "hcz_cont_room_6-3b", pos = Vector(-3623,4759,-7244), canSee = DefaultTerminalCanSee}, -- SCP_079
		{name = "hcz_cont_room_7-1", pos = Vector(-2572,6849,-7374), canSee = DefaultTerminalCanSee}, -- SCP_106
		{name = "hcz_cont_room_8-1a", pos = Vector(-1323,4669,-7100), canSee = DefaultTerminalCanSee}, -- SCP_035_1
		{name = "hcz_cont_room_8-1b", pos = Vector(-1286,4669,-7100), canSee = DefaultTerminalCanSee}, -- SCP_035_1
		{name = "hcz_cont_room_9-1", pos = Vector(433,3875,-7094), canSee = DefaultTerminalCanSee}, -- SCP_035_1

		-- CHECKPOINTS
		{name = "hcz_checkpoint_1-1a", pos = Vector(1854,829,-7100), canSee = DefaultTerminalCanSee},
		{name = "hcz_checkpoint_1-1b", pos = Vector(1890,829,-7100), canSee = DefaultTerminalCanSee},


	--EZ
		-- CHECKPOINTS
		{name = "ez_checkpoint_1-1", pos = Vector(641,5119,-7115), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_1-2a", pos = Vector(682,4905,-7099), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_1-2a", pos = Vector(647,4905,-7099), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_2-1", pos = Vector(1481,3545,-7115), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_2-2a", pos = Vector(1645,3586,-7100), canSee = DefaultTerminalCanSee},
		{name = "ez_checkpoint_2-2a", pos = Vector(1645,3550,-7100), canSee = DefaultTerminalCanSee},


		{name = "ez_office_1B-1", pos = Vector(1888,4034,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1B-2", pos = Vector(1675,4005,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1A-1", pos = Vector(2179,4120,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1A-2", pos = Vector(2103,4005,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_shared_conf_room-1", pos = Vector(2864,4711,-7116), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3-1", pos = Vector(2987,4076,-7181), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3-2", pos = Vector(3168,4142,-7181), canSee = DefaultTerminalCanSee},
		{name = "ez_office_3-3", pos = Vector(3386,4078,-7182), canSee = DefaultTerminalCanSee},
		{name = "ez_cafeteria-1", pos = Vector(4314,4653,-7244), canSee = DefaultTerminalCanSee},
		{name = "ez_evac_shelter_1-1", pos = Vector(4741,5370,-7116), canSee = DefaultTerminalCanSee},
		{name = "ez_head_office-2", pos = Vector(5320,6433,-7056), canSee = DefaultTerminalCanSee},
		{name = "ez_head_office-1", pos = Vector(5149,6315,-7053), canSee = DefaultTerminalCanSee},
		{name = "ez_security_gateway_1-1", pos = Vector(4520,6915,-7120), canSee = DefaultTerminalCanSee},
		{name = "ez_security_gateway_2-1", pos = Vector(5945,5891,-7120), canSee = DefaultTerminalCanSee},
		{name = "ez_conf_room_1-1", pos = Vector(5437,7517,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_conf_room_1-2", pos = Vector(5433,7437,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_electrical_center-1a", pos = Vector(5119,8189,-6844), canSee = DefaultTerminalCanSee},
		{name = "ez_electrical_center-1b", pos = Vector(5119,8153,-6844), canSee = DefaultTerminalCanSee},
		{name = "ez_medical_bay_1-1", pos = Vector(1364,5119,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_medical_bay_1-2", pos = Vector(1580,5280,-7099), canSee = function() return CanSeeFrom(Vector(1584,5259,-7111)) end},
		{name = "ez_medical_bay_1-2", pos = Vector(1620,5280,-7099), canSee = function() return CanSeeFrom(Vector(1584,5259,-7111)) end},
		{name = "ez_office_4-1", pos = Vector(4743,6160,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4-2", pos = Vector(4462,6045,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4-3", pos = Vector(4462,5854,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4-4", pos = Vector(4295,5918,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4-5", pos = Vector(4295,6119,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_4-6", pos = Vector(4317,5745,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2B-1", pos = Vector(1701,5774,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2A-1", pos = Vector(2017,5675,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2A-2", pos = Vector(2245,5679,-7117), canSee = DefaultTerminalCanSee},
		{name = "ez_office_5-1", pos = Vector(3006,6674,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_office_5-2", pos = Vector(3047,6682,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_office_5-3", pos = Vector(3196,7016,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_office_5-4a", pos = Vector(2878,7058,-7100), canSee = function() return CanSeeFrom(Vector(2894,7074,-7101)) end},
		{name = "ez_office_5-4b", pos = Vector(2878,7099,-7100), canSee = function() return CanSeeFrom(Vector(2894,7074,-7101)) end, special_functions = {special_terminal_settings.hcz_generator_3}},
		{name = "ez_office_5-5", pos = Vector(3151,7098,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_server_hub-1", pos = Vector(5374,4857,-7374), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-1", pos = Vector(1427,6021,-7250), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-2", pos = Vector(1344,6021,-7250), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-3", pos = Vector(1263,6021,-7250), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-4", pos = Vector(1353,6233,-7249), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-5", pos = Vector(1401,6704,-7249), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-6", pos = Vector(1427,6490,-7250), canSee = DefaultTerminalCanSee},
		{name = "ez_office_6-7_1", pos = Vector(1077,6652,-7232), canSee = function() return CanSeeFrom(Vector(1095,6661,-7237)) end},
		{name = "ez_office_6-7_2", pos = Vector(1077,6692,-7232), canSee = function() return CanSeeFrom(Vector(1095,6661,-7237)) end},
		{name = "ez_office_7-1", pos = Vector(3404,5997,-7182), canSee = DefaultTerminalCanSee},
		{name = "ez_office_7-2", pos = Vector(3226,5996,-7181), canSee = DefaultTerminalCanSee},
		{name = "ez_office_7-3", pos = Vector(3102,5996,-7182), canSee = DefaultTerminalCanSee},
		{name = "ez_storage_room_1-1", pos = Vector(2231,6234,-7118), canSee = DefaultTerminalCanSee},
		{name = "ez_serverfarm-server_main", pos = Vector(4693,4253,-7263), canSee = DefaultTerminalCanSee, special_functions = {special_terminal_settings.ez_servers}},


		--{name = "ez_office_7-XXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},
		--{name = "ez_office_7-XXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},
		--{name = "ez_office_7-XXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},




		--{name = "ez_office_1_1", pos = XXXXXXXXXXXXXXXXXXX, canSee = DefaultTerminalCanSee},
		--{name = "ez_office_1_1", pos = XXXXXXXXXXXXXXXXXXX, canSee = DefaultTerminalCanSee},
		--{name = "ez_office_1_1", pos = XXXXXXXXXXXXXXXXXXX, canSee = DefaultTerminalCanSee},
		--{name = "ez_office_1_1", pos = XXXXXXXXXXXXXXXXXXX, canSee = DefaultTerminalCanSee},

	}
}
-- ulx strip ^ ; give breach_tool_terminalplacer
-- lua_run Entity(1):SetPos(xxxxxxxxxxxxxxxxxxxxxx)

MAPCONFIG.ZONES = {}

MAPCONFIG.SPECIAL_MUSIC_ZONES = {
	{pos1 = Vector(465,-1144,-8222), pos2 = Vector(903,-520,-8065), sound = "breach2/music/914.ogg", length = 29.05, volume = 0.8}, -- 914
	{pos1 = Vector(1592,-901,-8229), pos2 = Vector(2314,-1787,-8026), sound = "breach2/music/205.ogg", length = 40.5, volume = 0.8}, -- 205
	{pos1 = Vector(3400,-7035,-8653), pos2 = Vector(4969,-5453,-8394), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, -- 049 TUNNELS
	{pos1 = Vector(3637,261,-7459), pos2 = Vector(4658,-1082,-6809), sound = "breach2/music/Room049.ogg", length = 39.6, volume = 0.5}, -- WARHEADS
	{pos1 = Vector(5370,366,-11672), pos2 = Vector(7569,-2400,-11324), sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 0.8}, -- HCZ TUNNELS
	{pos1 = Vector(-912,2139,-16175), pos2 = Vector(2016,-899,-14578), sound = "breach2/music/PD.ogg", length = 27.03, volume = 1}, -- PD
	--{pos1 = Vector(14907,-15883,-2283), pos2 = Vector(10162,-10690,99), sound = "breach2/music/1499.ogg", length = 50, volume = 0.7}, -- 1499
	{pos1 = Vector(-1003,-397,-8475), pos2 = Vector(-1592,235,-8317), sound = "breach2/music/012.ogg", length = 25.5, volume = 0.7}, -- 012
	{pos1 = Vector(5220,5307,-7424), pos2 = Vector(6099,4679,-7206), sound = "breach2/895.ogg", length = 20.75, volume = 0.5}, -- 895

}

MAPCONFIG.ESCAPE_ZONES = {
	{pos1 = Vector(-6526,3309,-1615), pos2 = Vector(-7232,1660,-667)},
	{pos1 = Vector(2618,-394,237), pos2 = Vector(2137,-1307,515)},
}

--  name                       	First Position          	Second Position         	Color                music       fog     NVGmul		ambient       use general ambient
MAPCONFIG.ZONES.LCZ = {
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(-3999,-2473,-8672),
		pos2 						= Vector(3302,3060,-7732),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}

MAPCONFIG.ZONES.HCZ = {
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(2588,35,-7692),
		pos2 						= Vector(-2679,3159,-6960),
		--music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(259,3171,-7902),
		pos2 						= Vector(-4141,7105,-6824),
		--music 						= {sound = "breach2/music/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "SCP-049's Tunnels",
		pos1 						= Vector(3400,-7035,-8653),
		pos2 						= Vector(4969,-5453,-8394),
		--music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		music 						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in SCP-049's Tunnels",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "HCZ Tunnels",
		pos1 						= Vector(5370,366,-11672),
		pos2 						= Vector(7569,-2400,-11324),
		music 						= {sound = "breach2/music/Room3Storage.ogg", length = 16, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Tunnel system",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "HCZ Warheads",
		pos1 						= Vector(3637,261,-7459),
		pos2 						= Vector(4658,-1082,-6809),
		music 						= {sound = "breach2/music/Room049.ogg", length = 39.6, volume = 1},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Heavy Containment Zone Warhead Control Room",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}

MAPCONFIG.ZONES.ENTRANCEZONE = {
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(304,3222,-7365),
		pos2 						= Vector(7605,8873,-6812),
		--music 						= {sound = "breach2/music/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}

MAPCONFIG.ZONES.POCKETDIMENSION = {
	{
		name 						= "Pocket Dimension",
		pos1 						= Vector(-912,2139,-16175),
		pos2 						= Vector(2016,-899,-14578),
		music 						= {sound = "breach2/music/PD.ogg", length = 27.03, volume = 1},
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(0,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in the Pocket Dimension",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}
MAPCONFIG.ZONES.OUTSIDE = {
	{
		name 						= "Outside",
		pos1 						= Vector(4797,-2801,-1771),
		pos2 						= Vector(-7418,5765,1983),
		--music 						= {sound = "breach2/music/withinsight.ogg", length = 60.44, volume = 0.5},
		music						= nil,
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(255,0,255,50),
		sanity 						= 1,
		examine_info 				= "You are outside of the facility",
		zone_temp 					= ZONE_TEMP_VERYCOLD,
		scp_106_can_tp 				= false,
	},
} 
MAPCONFIG.ZONES.FOREST = {
	{
		name 						= "Forest",
		pos1 						= Vector(12061,-15943,-3792),
		pos2 						= Vector(15048,-13022,-2633),
		music 						= nil,
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(70,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in a forest",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= false,
	},
}
/*
MAPCONFIG.ZONES.SCP_1499 = {
	{
		name 						= "SCP-1499",
		pos1 						= Vector(14907,-15883,-2283),
		pos2 						= Vector(10162,-10690,99),
		music 						= {sound = "breach2/music/1499.ogg", length = 50, volume = 1},
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(150,0,0,50),
		sanity 						= -1,
		examine_info 				= "You are in an unknown world",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= false,
	},
}
*/

-- Spawns in Class D's cells
MAPCONFIG.SPAWNS_CLASSD_CELLS = {
	Vector(-3602.939453125, 832.32720947266, -8046.96875),
	Vector(-3818.6428222656, 836.63403320313, -8046.96875),
	Vector(-3391.6364746094, 826.951171875, -8046.96875),
	Vector(-3187.87109375, 819.77954101563, -8046.96875),
	Vector(-2978.2719726563, 818.99493408203, -8046.96875),
	Vector(-2767.869140625, 823.73364257813, -8046.96875),
	Vector(-2764.4208984375, 300.34832763672, -8046.96875),
	Vector(-2968.7724609375, 301.01162719727, -8046.96875),
	Vector(-3186.3063964844, 296.73794555664, -8046.96875),
	Vector(-3385.3439941406, 298.82928466797, -8046.96875),
	Vector(-3605.9470214844, 293.82122802734, -8046.96875),
	Vector(-3811.1315917969, 294.30609130859, -8046.96875),
	Vector(-3706.0673828125, 464.80758666992, -8046.96875),
	Vector(-3604.4721679688, 461.24993896484, -8046.96875),
	Vector(-3711.3837890625, 665.58489990234, -8046.96875),
	Vector(-3573.3332519531, 689.86108398438, -8046.96875),
	Vector(-3482.9926757813, 469.52133178711, -8046.96875),
	Vector(-3445.1513671875, 665.87170410156, -8046.96875),
	Vector(-3348.6916503906, 464.94454956055, -8046.96875),
	Vector(-3307.9562988281, 655.20361328125, -8046.96875),
}

-- Spawns in Light Containment Zone
MAPCONFIG.SPAWNS_LCZ = {
	Vector(-533.94122314453, 1869.1693115234, -7905.96875),
	Vector(-1341.4820556641, 2493.8188476563, -8161.96875),
	Vector(587.75256347656, 2363.97265625, -8161.96875),
	Vector(1232.884765625, 1661.8000488281, -8161.96875),
	Vector(-1857.3309326172, 1092.9927978516, -8033.96875),
	Vector(-1162.1278076172, 917.470703125, -8161.96875),
	Vector(-1321.6896972656, -856.57196044922, -8161.96875),
	Vector(-44.114860534668, -663.82232666016, -8161.96875),
	Vector(-657.43664550781, -145.09915161133, -8161.96875),
	Vector(0.71955490112305, 630.56677246094, -8161.96875),
	Vector(601.30651855469, 19.127395629883, -8161.96875),
	Vector(1221.8041992188, -1493.4887695313, -8161.96875),
	Vector(2514.998046875, -66.075012207031, -8161.96875),
	Vector(1787.1489257813, -187.2525177002, -8161.96875),
	Vector(-275.55505371094, -1479.5308837891, -8161.96875),
	Vector(627.23950195313, -2319.5812988281, -8161.96875),	
}

-- Spawns in Heavy Containment Zone
MAPCONFIG.SPAWNS_HCZ = {
	Vector(583.91583251953, 2192.056640625, -7137.96875),
	Vector(-672.67742919922, 1585.462890625, -7137.96875),
	Vector(-52.506637573242, 2867.2775878906, -7137.96875),
	Vector(-696.39196777344, 3640.2463378906, -7137.96875),
	Vector(-2203.0905761719, 4525.5053710938, -7137.96875),
	Vector(-718.07312011719, 4795.6030273438, -7137.96875),
	Vector(-1989.7225341797, 5278.11328125, -7137.96875),
	Vector(-3240.7717285156, 5407.3735351563, -7137.96875),
	Vector(-3296.470703125, 4111.7993164063, -7137.96875),
	Vector(-1407.0133056641, 4064.7700195313, -7137.96875),
	Vector(1648.1843261719, 2895.0822753906, -7137.96875),
	Vector(-65.262420654297, 5334.828125, -7137.96875),	
}

-- Spawns in Entrance Zone
MAPCONFIG.SPAWNS_ENTRANCEZONE = {
	Vector(1790.5290527344, 4263.55859375, -7137.96875),
	Vector(1204.6691894531, 4398.087890625, -7137.96875),
	Vector(577.63647460938, 4801.080078125, -7137.96875),
	Vector(3209.4875488281, 4250.0961914063, -7137.96875),
	Vector(2561.0180664063, 5077.4575195313, -7137.96875),
	Vector(1732.5205078125, 5231.57421875, -7137.96875),
	Vector(1205.2709960938, 5123.599609375, -7137.96875),
	Vector(3830.884765625, 4389.4912109375, -7137.96875),
	Vector(4283.1147460938, 4791.533203125, -7265.96875),
	Vector(4242.3310546875, 5446.0283203125, -7137.96875),
	Vector(3076.1342773438, 5386.8486328125, -7137.96875),
}

MAPCONFIG.SPAWNS_ENTRANCEZONE_EARLY = {
	Vector(1430.60546875, 4243.0922851563, -7142.96875),
	Vector(2566.9353027344, 4467.3071289063, -7142.96875),
	Vector(1225.8942871094, 5107.3139648438, -7142.96875),
	Vector(1552.7170410156, 5710.8798828125, -7142.96875),
	Vector(2549.4265136719, 5469.078125, -7142.96875),
	Vector(578.45501708984, 4786.04296875, -7142.96875),
	Vector(839.27166748047, 5539.6708984375, -7142.96875),
	Vector(1173.7788085938, 3774.0461425781, -7142.96875),
	Vector(2048.986328125, 4269.3798828125, -7142.96875),
	Vector(1838.2746582031, 5392.9155273438, -7142.96875),
	Vector(2159.0952148438, 5042.1791992188, -7142.96875),	
}

MAPCONFIG.SPAWNS_ENTRANCEZONE_LATE = {
	Vector(2522.6052246094, 7854.08984375, -7137.96875),
	Vector(2685.439453125, 7798.673828125, -7137.96875),
	Vector(2568.2150878906, 7706.0610351563, -7137.96875),
	Vector(2431.9326171875, 7660.4897460938, -7137.96875),
	Vector(2464.5893554688, 7547.900390625, -7137.96875),
	Vector(2598.1091308594, 7569.9682617188, -7137.96875),

	Vector(6913.294921875, 5231.9653320313, -7137.96875),
	Vector(6910.4458007813, 5099.150390625, -7137.96875),
	Vector(6906.1025390625, 4955.39453125, -7137.96875),
	Vector(6694.1342773438, 4870.3662109375, -7137.96875),
	Vector(6695.5122070313, 5032.0366210938, -7137.96875),
	Vector(6743.4887695313, 5206.8090820313, -7137.96875),
	Vector(6585.6704101563, 5178.7290039063, -7137.96875),
	Vector(6989.125, 5340.41015625, -7137.96875),
	Vector(7092.05859375, 4863.5317382813, -7137.96875),

	Vector(4379.166015625, 5907.3515625, -7137.96875),
	Vector(4379.0166015625, 6021.5693359375, -7137.96875),
	Vector(4393.7329101563, 6150.0166015625, -7137.96875),
	Vector(4550.5541992188, 6138.7387695313, -7137.96875),
	Vector(4553.208984375, 5877.4926757813, -7137.96875),
	Vector(4208.1850585938, 5997.0493164063, -7137.96875),
	Vector(4241.4770507813, 5823.6787109375, -7137.96875),
	Vector(4407.0356445313, 5773.7036132813, -7137.96875),
	Vector(4547.32421875, 6005.8852539063, -7137.96875),
}

-- Where Chaos Insurgency spawns at the beginning of the round
MAPCONFIG.SPAWNS_CHAOSINSURGENCY = {
	{
		name = "Gate A",
		spawns = {
			Vector(2522.6052246094, 7854.08984375, -7137.96875),
			Vector(2685.439453125, 7798.673828125, -7137.96875),
			Vector(2568.2150878906, 7706.0610351563, -7137.96875),
			Vector(2431.9326171875, 7660.4897460938, -7137.96875),
			Vector(2464.5893554688, 7547.900390625, -7137.96875),
			Vector(2598.1091308594, 7569.9682617188, -7137.96875),
		}
	},
	{
		name = "Gate B",
		spawns = {
			Vector(6913.294921875, 5231.9653320313, -7137.96875),
			Vector(6910.4458007813, 5099.150390625, -7137.96875),
			Vector(6906.1025390625, 4955.39453125, -7137.96875),
			Vector(6694.1342773438, 4870.3662109375, -7137.96875),
			Vector(6695.5122070313, 5032.0366210938, -7137.96875),
			Vector(6743.4887695313, 5206.8090820313, -7137.96875),
			Vector(6585.6704101563, 5178.7290039063, -7137.96875),
			Vector(6989.125, 5340.41015625, -7137.96875),
			Vector(7092.05859375, 4863.5317382813, -7137.96875),
		}
	},
	{
		name = "Office",
		spawns = {
			Vector(4379.166015625, 5907.3515625, -7137.96875),
			Vector(4379.0166015625, 6021.5693359375, -7137.96875),
			Vector(4393.7329101563, 6150.0166015625, -7137.96875),
			Vector(4550.5541992188, 6138.7387695313, -7137.96875),
			Vector(4553.208984375, 5877.4926757813, -7137.96875),
			Vector(4208.1850585938, 5997.0493164063, -7137.96875),
			Vector(4241.4770507813, 5823.6787109375, -7137.96875),
			Vector(4407.0356445313, 5773.7036132813, -7137.96875),
			Vector(4547.32421875, 6005.8852539063, -7137.96875),
		}
	}
}

-- SCP 035's spawns
MAPCONFIG.SPAWNS_SCP_035 = {
	Vector(765.39086914063, 1020.7515258789, -7137.96875)
}

-- SCP 173's spawns
MAPCONFIG.SPAWNS_SCP_173 = {
	Vector(-189.662064, 1955.437500, -8063.968750)
}

-- SCP 049's spawns
MAPCONFIG.SPAWNS_SCP_049 = {
	Vector(4180.052734375, -6376.6708984375, -8582.96875),
	Vector(4086.451171875, -6439.6264648438, -8582.96875),
	Vector(4181.0200195313, -6440.6103515625, -8582.96875),
	Vector(4256.5708007813, -6396.4174804688, -8582.96875)
}

-- SCP 106's spawn
MAPCONFIG.SPAWNS_SCP_106 = {
	Vector(-263.70867919922, 1420.8409423828, -8033.96875),
	Vector(-152.89517211914, 1459.5327148438, -8033.96875),
	Vector(-141.37690734863, 1299.3089599609, -8033.96875),
	Vector(-258.21087646484, 1247.1650390625, -8033.96875),
	Vector(-333.30120849609, 1307.2036132813, -8033.96875)
}

-- SCP 457's spawn
MAPCONFIG.SPAWNS_SCP_457 = {
	Vector(-2557.9653320313, 2914.3310546875, -7142.96875),
	Vector(-2605.4235839844, 2929.216796875, -7142.96875),
	Vector(-2541.8579101563, 2977.3583984375, -7142.96875),
	Vector(-2609.3569335938, 3002.3344726563, -7142.96875)
}

-- SCP 966's spawn
MAPCONFIG.SPAWNS_SCP_966 = {
	Vector(-641.97521972656, 4187.5517578125, -7137.96875),
	Vector(-649.57940673828, 4098.4736328125, -7137.96875),
	Vector(-777.77038574219, 4117.9116210938, -7137.96875),
	Vector(-733.60302734375, 4192.3076171875, -7137.96875)	
}

-- Where Mobile Task Force spawns when they arrive in the facility
MAPCONFIG.SPAWNS_MTF = {
	{
		name = "Gate A",
		spawns = {
			Vector(2730.416015625, 7862.8862304688, -7137.96875),
			Vector(2740.3139648438, 7750.8129882813, -7137.96875),
			Vector(2488.8137207031, 7869.9287109375, -7137.96875),
			Vector(2348.0471191406, 7735.3061523438, -7137.96875),
			Vector(2404.8051757813, 7679.7036132813, -7137.96875),
			Vector(2380.7648925781, 7573.5913085938, -7137.96875),
			Vector(2673.6123046875, 7802.0688476563, -7137.96875),
			Vector(2664.3566894531, 7518.4125976563, -7137.96875),
			Vector(2591.5432128906, 7870.9462890625, -7137.96875),
		},
		available = function()
			local pos1 = Vector(3001,7166,-7205)
			local pos2 = Vector(2212,7990,-6680)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "Gate B",
		spawns = {
			Vector(6529.130859375, 4920.9926757813, -7137.96875),
			Vector(6527.5874023438, 5003.4536132813, -7137.96875),
			Vector(6613.9057617188, 4848.7416992188, -7137.96875),
			Vector(6608.0512695313, 4961.4155273438, -7137.96875),
			Vector(6708.1938476563, 4840.4189453125, -7137.96875),
			Vector(6685.6499023438, 4921.6499023438, -7137.96875),
			Vector(6903.8999023438, 5410.58984375, -7137.96875),
			Vector(6535.7124023438, 5413.1123046875, -7137.96875),
			Vector(6630.0131835938, 5412.7358398438, -7137.96875),
		},
		available = function()
			local pos1 = Vector(6210,5521,-7203)
			local pos2 = Vector(7515,4601,-6915)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "Gate C",
		spawns = {
			Vector(1434.0267333984, 7431.97265625, -7269.96875),
			Vector(1413.7924804688, 7346.2729492188, -7269.96875),
			Vector(1372.0592041016, 7400.08203125, -7269.96875),
			Vector(1093.5893554688, 7374.0913085938, -7269.96875),
			Vector(1162.5906982422, 7392.7475585938, -7269.96875),
			Vector(1038.8153076172, 7444.4252929688, -7269.96875),
			Vector(1424.8541259766, 7145.6098632813, -7269.96875),
			Vector(1049.4576416016, 7161.4428710938, -7269.96875),
			Vector(1118.4812011719, 7449.1137695313, -7269.96875),
		},
		available = function()
			local pos1 = Vector(1509,6738,-7368)
			local pos2 = Vector(940,7533,-7175)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "Evacuation Shelter",
		spawns = {
			Vector(4767.8813476563, 5605.5122070313, -7137.96875),
			Vector(4810.5913085938, 5565.3549804688, -7137.96875),
			Vector(4734.400390625, 5521.2973632813, -7137.96875),
			Vector(4851.3388671875, 5491.0551757813, -7137.96875),
			Vector(4791.626953125, 5505.1416015625, -7137.96875),
			Vector(4810.5341796875, 5350.126953125, -7137.96875),
			Vector(4766.8427734375, 5434.111328125, -7137.96875),
			Vector(4832.2900390625, 5418.2563476563, -7137.96875),
			Vector(4754.4052734375, 5185.4721679688, -7137.96875),
		},
		available = function()
			local pos1 = Vector(4407,4936,-7166)
			local pos2 = Vector(4934,5671,-6620)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
	{
		name = "LCZ Entrance",
		spawns = {
			Vector(4767.8813476563, 5605.5122070313, -7137.96875),
			Vector(4810.5913085938, 5565.3549804688, -7137.96875),
			Vector(4734.400390625, 5521.2973632813, -7137.96875),
			Vector(4851.3388671875, 5491.0551757813, -7137.96875),
			Vector(4791.626953125, 5505.1416015625, -7137.96875),
			Vector(4810.5341796875, 5350.126953125, -7137.96875),
			Vector(4766.8427734375, 5434.111328125, -7137.96875),
			Vector(4832.2900390625, 5418.2563476563, -7137.96875),
			Vector(4754.4052734375, 5185.4721679688, -7137.96875),					
		},
		available = function()
			local pos1 = Vector(-992,-590,-8355)
			local pos2 = Vector(-383,-1863,-7908)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:GetPos():WithinAABox(pos1, pos2) then
					return false
				end
			end
			return true
		end
	},
}

function BR2_Get_914_1_Pos()
	return Vector(709.000000, -832.000000, -8131.000000)
end

function BR2_Get_914_2_Pos()
	return Vector(710.281250, -832.000000, -8149.000000)
end

print("[Breach2] Shared mapconfig loaded!")
