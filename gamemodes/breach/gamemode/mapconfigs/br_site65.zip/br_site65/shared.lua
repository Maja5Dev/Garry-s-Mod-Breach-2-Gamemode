
local ambient_general = {
	"breach2/ambient/general/Ambient1.ogg",
	"breach2/ambient/general/Ambient2.ogg",
	"breach2/ambient/general/Ambient3.ogg",
	"breach2/ambient/general/Ambient4.ogg",
	"breach2/ambient/general/Ambient5.ogg",
	"breach2/ambient/general/Ambient6.ogg",
	"breach2/ambient/general/Ambient7.ogg",
	"breach2/ambient/general/Ambient8.ogg",
	"breach2/ambient/general/Ambient9.ogg",
	"breach2/ambient/general/Ambient10.ogg",
	"breach2/ambient/general/Ambient11.ogg",
	"breach2/ambient/general/Ambient12.ogg",
	"breach2/ambient/general/Ambient13.ogg",
	"breach2/ambient/general/Ambient14.ogg",
	"breach2/ambient/general/Ambient15.ogg",
}

local ambient_lcz = {
	"breach2/ambient/zone1/Ambient1.ogg",
	"breach2/ambient/zone1/Ambient2.ogg",
	"breach2/ambient/zone1/Ambient3.ogg",
	"breach2/ambient/zone1/Ambient4.ogg",
	"breach2/ambient/zone1/Ambient5.ogg",
	"breach2/ambient/zone1/Ambient6.ogg",
	"breach2/ambient/zone1/Ambient7.ogg",
	"breach2/ambient/zone1/Ambient8.ogg",
}

local ambient_hcz = {
	"breach2/ambient/zone2/Ambient1.ogg",
	"breach2/ambient/zone2/Ambient2.ogg",
	"breach2/ambient/zone2/Ambient3.ogg",
	"breach2/ambient/zone2/Ambient4.ogg",
	"breach2/ambient/zone2/Ambient5.ogg",
	"breach2/ambient/zone2/Ambient6.ogg",
	"breach2/ambient/zone2/Ambient7.ogg",
	"breach2/ambient/zone2/Ambient8.ogg",
	"breach2/ambient/zone2/Ambient9.ogg",
	"breach2/ambient/zone2/Ambient10.ogg",
	"breach2/ambient/zone2/Ambient11.ogg",
}

local ambient_ez = {
	"breach2/ambient/zone3/Ambient1.ogg",
	"breach2/ambient/zone3/Ambient2.ogg",
	"breach2/ambient/zone3/Ambient3.ogg",
	"breach2/ambient/zone3/Ambient4.ogg",
	"breach2/ambient/zone3/Ambient5.ogg",
	"breach2/ambient/zone3/Ambient6.ogg",
	"breach2/ambient/zone3/Ambient7.ogg",
	"breach2/ambient/zone3/Ambient8.ogg",
	"breach2/ambient/zone3/Ambient9.ogg",
	"breach2/ambient/zone3/Ambient10.ogg",
	"breach2/ambient/zone3/Ambient11.ogg",
	"breach2/ambient/zone3/Ambient12.ogg",
}

MAPCONFIG.EnableGamemodeMusic = true
MAPCONFIG.EnableAmbientSounds = true
MAPCONFIG.GeneralAmbientSounds = ambient_general
MAPCONFIG.CommotionSounds = {
	"breach2/intro/Commotion/Commotion1.ogg",
	"breach2/intro/Commotion/Commotion2.ogg",
	"breach2/intro/Commotion/Commotion3.ogg",
	"breach2/intro/Commotion/Commotion4.ogg",
	"breach2/intro/Commotion/Commotion5.ogg",
	"breach2/intro/Commotion/Commotion6.ogg",
	"breach2/intro/Commotion/Commotion7.ogg",
	"breach2/intro/Commotion/Commotion8.ogg",
	"breach2/intro/Commotion/Commotion9.ogg",
	"breach2/intro/Commotion/Commotion10.ogg",
	"breach2/intro/Commotion/Commotion11.mp3",
	"breach2/intro/Commotion/Commotion12.ogg",
	"breach2/intro/Commotion/Commotion13.mp3",
	"breach2/intro/Commotion/Commotion14.mp3",
	"breach2/intro/Commotion/Commotion15.mp3",
	"breach2/intro/Commotion/Commotion16.ogg",
	"breach2/intro/Commotion/Commotion17.ogg",
	"breach2/intro/Commotion/Commotion18.ogg",
	"breach2/intro/Commotion/Commotion19.ogg",
	"breach2/intro/Commotion/Commotion20.ogg",
	"breach2/intro/Commotion/Commotion21.ogg",
	"breach2/intro/Commotion/Commotion22.mp3",
	"breach2/intro/Commotion/Commotion23.ogg",
	"breach2/intro/Bang2.ogg",
	"breach2/intro/Bang3.ogg",
}

/*
MAPCONFIG.FirstSounds = {
	{"breach2/alarm/Alarm2_1.ogg", 6},
	{"breach2/alarm/Alarm2_2.ogg", 5},
	{"breach2/alarm/Alarm2_3.ogg", 7},
	{"breach2/alarm/Alarm2_4.ogg", 10},
	{"breach2/alarm/Alarm2_5.ogg", 6},
	{"breach2/alarm/Alarm2_6.ogg", 8},
	{"breach2/alarm/Alarm2_7.ogg", 7},
	{"breach2/alarm/Alarm2_8.ogg", 4},
	{"breach2/alarm/Alarm2_9.ogg", 4},
	{"breach2/alarm/Alarm2_10.ogg", 15}
}
*/

MAPCONFIG.FirstSounds = {
	{"breach2/alarm/breach_alarm.ogg", 72},
}
MAPCONFIG.FirstSoundsLength = 72 -- length of all of FirstSounds in seconds


-- give breach_tool_cameraplacer
MAPCONFIG.CAMERAS = {
	{
		name = "Light Containment Zone",
		cameras = {
			{name = "LCZ_CELLS", pos = Vector(11935,-2825,-10719), ang = Angle(0,0,0)},
			{name = "LCZ_CHECKPOINT_C", pos = Vector(10785,-2467,-10879), ang = Angle(0,180,0)},
			{name = "LCZ_OFFICE", pos = Vector(8552,-2974,-10905), ang = Angle(0,0,0)},
			{name = "LCZ_SECURITY_AREA", pos = Vector(7734,-2858,-10426), ang = Angle(0,90,0)},
			{name = "LCZ_CONNECTOR", pos = Vector(5712,-924,-10879), ang = Angle(0,90,0)},
		}
	},
	{
		name = "Heavy Containment Zone",
		cameras = {
			{name = "HCZ_CONNECTOR_1", pos = Vector(3943,-1770,-10932), ang = Angle(0,-90,0)},
			{name = "HCZ_CONNECTOR_2", pos = Vector(2455,-1486,-10905), ang = Angle(0,-90,0)},
			{name = "HCZ_CONNECTOR_3", pos = Vector(3905,-4215,-10918), ang = Angle(0,0,0)},
			{name = "HCZ_TESLAGATE", pos = Vector(2455,-1486,-10905), ang = Angle(0,-90,0)},
			{name = "HCZ_SCP_106", pos = Vector(5628,-4659,-10842), ang = Angle(0,180,0)},
		}
	},
	{
		name = "Entrance Zone",
		cameras = {
			{name = "EZ_CONNECTOR_1", pos = Vector(-2490,3129,-10928), ang = Angle(0,-90,0)},
			{name = "EZ_CAFETERIA", pos = Vector(-2075,1486,-10810), ang = Angle(0,0,0)},
			{name = "EZ_MEDBAY", pos = Vector(-3891,3256,-10925), ang = Angle(0,180,0)},
			{name = "EZ_OFFICE_A", pos = Vector(-3881,2319,-10919), ang = Angle(0,-90,0)},
			{name = "EZ_OFFICE_B", pos = Vector(-2684,-637,-10925), ang = Angle(0,-90,0)},
			{name = "EZ_GATE_A", pos = Vector(-3881,2319,-10919), ang = Angle(0,-90,0)},
			{name = "EZ_SERVERS", pos = Vector(-1916,-2587,-10933), ang = Angle(0,-90,0)},
		}
	},
}

function Buttons_Containers_TestPos(pos)
	for i,v in ipairs(MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS.buttons) do
		local dist = v.pos:Distance(pos)
		if dist < 25 then
			print(i, dist, v.pos)
		end
	end
end

XXXXXXXXXXXXXXXXXXXXXXX = Vector(0,0,0)
YYYYYYYYYYYYYYYYYYYYYYYY = Vector(0,0,0)


-- lua_run Buttons_Containers_TestPos(Vector(1915,6156,-7112))
MAPCONFIG.BUTTONS_2D = {}
MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS = {
	on_open = function(button)
		TryToOpenContainer(button)
	end,
	buttons = {
		--{pos = XXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "YYYYYYYYYYYYYYYYYYY"}, -- ZZZZZZZZZZZZZZ
		{pos = Vector(8448,-2846,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_1-DRAWER_1
		{pos = Vector(8448,-2877,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_1-DRAWER_2
		{pos = Vector(8524,-2516,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_1-DRAWER_3
		{pos = Vector(9019,-2634,-11004), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_1-BOX_1
		{pos = Vector(9106,-2636,-11004), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_1-BOX_2
		{pos = Vector(6888,-3370,-11058), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_STR_1"}, -- LCZ_STORAGEROOM_1-BOX_1
		{pos = Vector(6888,-3350,-11080), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_STR_1"}, -- LCZ_STORAGEROOM_1-BOX_2
		{pos = Vector(6890,-3396,-11078), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_STR_1"}, -- LCZ_STORAGEROOM_1-BOX_3
		{pos = Vector(7504,-2716,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_2-DRAWER_1
		{pos = Vector(7552,-2726,-11001), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_OFFICE_2-DRAWER_2
		{pos = Vector(10321,-1765,-11012), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_173-CRATE_1
		{pos = Vector(10357,-1755,-11008), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_173-CRATE_2
		{pos = Vector(10685,-1917,-10849), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_173-SMALL_DRAWER_1
		{pos = Vector(10719,-1940,-10848), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_173-CRATE_1
		{pos = Vector(10716,-1858,-10847), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_173-CRATE_2
		{pos = Vector(10871,-3236,-10838), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-DRAWER_1
		{pos = Vector(10785,-3319,-10838), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-DRAWER_2
		{pos = Vector(10755,-3319,-10838), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-DRAWER_3
		{pos = Vector(10945,-3102,-10808), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-CRATE_1
		{pos = Vector(10683,-3079,-10862), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-CRATE_2
		{pos = Vector(10738,-3081,-10861), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-CRATE_3
		{pos = Vector(10683,-3080,-10773), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-CRATE_4
		{pos = Vector(10817,-3174,-10846), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-BOX_1
		{pos = Vector(10776,-3169,-10846), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-BOX_2
		{pos = Vector(10718,-3078,-10817), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_GUNS"}, -- LCZ_SCP_914-BIG_CRATE_1
		{pos = Vector(7532,-2043,-10519), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_BARRACKS"}, -- LCZ_BARRACKS-YBOX_1
		{pos = Vector(7654,-2041,-10519), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_BARRACKS"}, -- LCZ_BARRACKS-YBOX_2
		{pos = Vector(7655,-1785,-10519), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_BARRACKS"}, -- LCZ_BARRACKS-YBOX_3
		{pos = Vector(7532,-1786,-10519), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ_BARRACKS"}, -- LCZ_BARRACKS-YBOX_4
		{pos = Vector(8219,-3136,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_1162-DRAWER_1

		{pos = Vector(4852,-4155,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_STORAGEROOM_1-BOX_1
		{pos = Vector(4852,-4136,-11014), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_STORAGEROOM_1-BOX_2
		{pos = Vector(4848,-4176,-11014), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_STORAGEROOM_1-BOX_3

		{pos = Vector(-2185,-1036,-11080), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_1-SMALL_DRAWER_1
		{pos = Vector(-2192,-1231,-11081), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_1-SMALL_DRAWER_2
		{pos = Vector(-2438,-1127,-11081), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_1-SMALL_DRAWER_3
		{pos = Vector(-2156,-1519,-11070), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_1-BOX_1
		{pos = Vector(-2194,-1543,-11070), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_1-BOX_2
		{pos = Vector(-3737,2291,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_1
		{pos = Vector(-3811,2291,-11018), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_2
		{pos = Vector(-3853,2203,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_3
		{pos = Vector(-3779,2203,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_4
		{pos = Vector(-3737,2026,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_5
		{pos = Vector(-3811,2026,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_6
		{pos = Vector(-3853,1938,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_7
		{pos = Vector(-3779,1938,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_8
		{pos = Vector(-3574,1680,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_9
		{pos = Vector(-3574,1606,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_10
		{pos = Vector(-3486,1564,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_11
		{pos = Vector(-3486,1638,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-SMALL_DRAWER_12
		{pos = Vector(-3738,1765,-10990), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-BOX_1
		{pos = Vector(-3739,1762,-11011), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-BOX_2
		{pos = Vector(-3858,1791,-11006), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_OFFICE_2-BOX_3
		{pos = Vector(-3221,-1462,-10958), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_HEAD_OFFICE_1"}, -- EZ_HEAD_OFFICE-DRAWER_1
		{pos = Vector(-3221,-1430,-10958), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_HEAD_OFFICE_1"}, -- EZ_HEAD_OFFICE-DRAWER_2
		{pos = Vector(-3115,-1337,-10977), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_HEAD_OFFICE_2"}, -- EZ_HEAD_OFFICE-SMALL_DRAWER_1
		{pos = Vector(-1699,2657,-11017), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_SHARED_CONF_ROOM-SMALL_DRAWER_1
		{pos = Vector(-2665,-2361,-11008), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_BARRACKS-YBOX_1
		{pos = Vector(-2542,-2359,-11008), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_BARRACKS-YBOX_2
		{pos = Vector(-2665,-2615,-11008), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_BARRACKS-YBOX_3
		{pos = Vector(-2543,-2615,-11008), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_BARRACKS-YBOX_4
		{pos = Vector(-3812,-2241,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONF_ROOM"}, -- EZ_CONF_ROOM-DRAWER_1
		{pos = Vector(-3782,-2241,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONF_ROOM"}, -- EZ_CONF_ROOM-DRAWER_2
		{pos = Vector(-3553,-2241,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONF_ROOM"}, -- EZ_CONF_ROOM-DRAWER_3
		{pos = Vector(-3523,-2241,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONF_ROOM"}, -- EZ_CONF_ROOM-DRAWER_4
		{pos = Vector(-3493,-2241,-10998), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ_CONF_ROOM"}, -- EZ_CONF_ROOM-DRAWER_5
		{pos = Vector(2023,-4234,-11006), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_STORAGEROOM_1-BOX_1
		{pos = Vector(2023,-4185,-11006), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_STORAGEROOM_1-BOX_2
		{pos = Vector(2029,-3993,-11009), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_STORAGEROOM_1-CRATE_1
		{pos = Vector(2027,-4024,-11019), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_STORAGEROOM_1-CRATE_2
		{pos = Vector(2041,-3966,-11021), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_STORAGEROOM_1-CRATE_3
		{pos = Vector(-5376,-1510,-11071), canSee = DefaultItemContainerCanSee, item_gen_group = "MILITARY_CRATES"}, -- EZ_GATE_B-MCRATE_1
		{pos = Vector(-5425,-1507,-11071), canSee = DefaultItemContainerCanSee, item_gen_group = "MILITARY_CRATES"}, -- EZ_GATE_B-MCRATE_2
		{pos = Vector(-5462,-1487,-11071), canSee = DefaultItemContainerCanSee, item_gen_group = "MILITARY_CRATES"}, -- EZ_GATE_B-MCRATE_3
		{pos = Vector(-5372,-1485,-11071), canSee = DefaultItemContainerCanSee, item_gen_group = "MILITARY_CRATES"}, -- EZ_GATE_B-MCRATE_4

 
		{pos = Vector(-3966,5933,-5807), canSee = DefaultItemContainerCanSee, item_gen_group = "MILITARY_CRATES"}, -- OUTSIDE-MCRATE_1
		{pos = Vector(-4071,5938,-5807), canSee = DefaultItemContainerCanSee, item_gen_group = "MILITARY_CRATES"}, -- OUTSIDE-MCRATE_2


		{pos = XXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "YYYYYYYYYYYYYYYYYYY"}, -- ZZZZZZZZZZZZZZ
		{pos = XXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "YYYYYYYYYYYYYYYYYYY"}, -- ZZZZZZZZZZZZZZ
		{pos = XXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "YYYYYYYYYYYYYYYYYYY"}, -- ZZZZZZZZZZZZZZ
	}
}
MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS_CRATES = {
	on_open = function(button)
		TryToOpenCrate(button)
	end,
	buttons = {
		{pos = Vector(6538,-3146,-11062), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_STORAGEROOM_1-1
		{pos = Vector(6494,-3194,-11061), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_STORAGEROOM_1-2
		{pos = Vector(6480,-3138,-11062), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_STORAGEROOM_1-3
		{pos = Vector(10711,-3928,-10991), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-1
		{pos = Vector(10690,-3989,-10992), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-2
		{pos = Vector(10598,-3922,-10992), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-3
		{pos = Vector(10641,-4004,-10991), canSee = DefaultItemContainerCanSee, item_gen_group = "LCZ"}, -- LCZ_SCP_914-4
		{pos = Vector(3091,-91,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_SCP_096-1
		{pos = Vector(3147,-150,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_SCP_096-2
		{pos = Vector(3098,-143,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_SCP_096-3
		{pos = Vector(-895,-3454,-11078), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_SERVER_ROOM-1
		{pos = Vector(-944,-3476,-11079), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_SERVER_ROOM-2
		{pos = Vector(-914,-3470,-11062), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_SERVER_ROOM-3
		{pos = Vector(-2498,3047,-10992), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_CORRIDOR-1
		{pos = Vector(-2550,3044,-10992), canSee = DefaultItemContainerCanSee, item_gen_group = "EZ"}, -- EZ_CORRIDOR-2
		{pos = Vector(717,3004,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_SCP_035-1
		{pos = Vector(761,3021,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_SCP_035-2
		{pos = Vector(758,2974,-10993), canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- HCZ_SCP_035-3
		{pos = XXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- ZZZZZZZZZZZZZZ
		{pos = XXXXXXXXXXXXXXXXXXXXXXX, canSee = DefaultItemContainerCanSee, item_gen_group = "HCZ"}, -- ZZZZZZZZZZZZZZ
	}
}



MAP_SCP_294_Coins = 0

MAPCONFIG.BUTTONS_2D.SIMPLE = {
	on_open = function(button)
		SimpleButtonUse(button)
	end,
	buttons = {
	}
}

MAPCONFIG.BUTTONS_2D.SODAMACHINES = {
	on_open = function(button)
		SodaMachineUse(button)
	end,
	buttons = {
		/*
		-- 2nd O   8 clicks inside
		{
			pos = Vector(7140,-2903,-10979),
			pos_out = Vector(2603.902832, 5670.911621, -7150.751465),
			ang_out = Angle(0.888, -179.828, -89.229),
			pos_inside = Vector(7120,-2917,-10981),
			canSee = DefaultItemContainerCanSee,
			mdl = "models/props/cs_office/Water_bottle.mdl",
			class = "bottle_water",
			name = "Water Bottle"
		},
		*/
	}
}

MAPCONFIG.BUTTONS_2D.OUTFITTERS = {
	on_open = function(button)
		if button == nil or LocalPlayer():GetOutfit().can_change_outfits == false then
			--chat.AddText(Color(255, 255, 255), "You cannot change your outfit")
			chat.AddText(Color(255, 255, 255), "You couldn't find anything useful...")
			return
		end
		net.Start("br_use_outfitter")
			net.WriteVector(button.pos)
		net.SendToServer()
	end,
	buttons = {
		--{pos = Vector(-777,-707,-8142), canSee = DefaultOutfitterCanSee, item_gen_group = "LCZ"},
	}
}

local evac_shelter_delay = 0

local special_terminal_settings = {
	hcz_storage_room = {
		class = "1",
		name = "Open/Close Storage Room 2b",
		type = "button",
		button_size = 720,
		server = {
			func = function(pl)
				BR2_SPECIAL_BUTTONS["spec_button_hcz_storage_room"]:Use(pl, pl, 3, 1)
			end
		}
	},
	ez_servers = {
		class = "5",
		name = "Restart the servers",
		type = "button",
		button_size = 640,
		server = {
			func = function(pl)
				BR2_SPECIAL_BUTTONS["spec_button_ez_server_room"]:Use(pl, pl, 3, 1)
			end
		}
	},
	evac_shelter = {
		class = "6",
		name = "Send the elevator",
		type = "button",
		button_size = 600,
		server = {
			func = function(pl)
				if evac_shelter_delay < CurTime() then
					BR2_SPECIAL_BUTTONS["spec_button_ez_evac_shelter_1"]:Use(pl, pl, 3, 1)
					evac_shelter_delay = CurTime() + 12.5
				end
			end
		}
	},
}

for i=1, 4 do
	special_terminal_settings["hcz_generator_"..i] = {
		class = tostring(i + 1),
		name = "Restart Generator "..i.."",
		type = "button",
		button_size = 600,
		server = {
			func = function(pl)
				BR2_SPECIAL_BUTTONS["spec_button_generator_"..i]:Use(pl, pl, 1, 1)
			end
		}
	}
end

function Buttons_Terminals_TestPos(pos)
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.TERMINALS.buttons) do
		local dist = v.pos:Distance(pos)
		if dist < 25 then
			print(v, dist)
		end
	end
end


-- lua_run Buttons_Terminals_TestPos(Vector(1915,6156,-7112))
MAPCONFIG.BUTTONS_2D.TERMINALS = {
	on_open = function(button)
		BR_Access_Terminal(button)
	end,
	buttons = {
		--{name = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-d1", pos = Vector(8634,-2839,-10983), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-d2", pos = Vector(8918,-2765,-10983), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-d3", pos = Vector(8919,-2841,-10982), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-d4", pos = Vector(8952,-2844,-10982), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_1-m1_1", pos = Vector(8509,-2987,-10966), canSee = function() return CanSeeFrom(Vector(8508,-2967,-10973)) end},
		{name = "lcz_office_1-m1_2", pos = Vector(8470,-2987,-10966), canSee = function() return CanSeeFrom(Vector(8508,-2967,-10973)) end},
		{name = "lcz_office_2-d1", pos = Vector(7411,-2939,-10980), canSee = DefaultTerminalCanSee},
		{name = "lcz_office_2-m1_1", pos = Vector(7590,-2848,-10965), canSee = function() return CanSeeFrom(Vector(7564,-2851,-10978)) end},
		{name = "lcz_office_2-m1_2", pos = Vector(7590,-2889,-10965), canSee = function() return CanSeeFrom(Vector(7564,-2851,-10978)) end},
		{name = "lcz_contchamber_scp173-d1", pos = Vector(10446,-1656,-10825), canSee = DefaultTerminalCanSee},
		{name = "lcz_contchamber_scp457-m1_1", pos = Vector(6218,-3358,-10965), canSee = DefaultTerminalCanSee},
		{name = "lcz_contchamber_scp457-m1_2", pos = Vector(6254,-3358,-10965), canSee = DefaultTerminalCanSee},
		{name = "hcz_storageroom_1-d1", pos = Vector(4781,-4301,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_head_office-d1", pos = Vector(-3069,-1359,-10942), canSee = function() return CanSeeFrom(Vector(-3084,-1363,-10943)) end},
		{name = "ez_shared_conf_room-d1", pos = Vector(-1734,2631,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d1", pos = Vector(-3757,2262,-10981), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d2", pos = Vector(-3833,2262,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d3", pos = Vector(-3832,2232,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d4", pos = Vector(-3759,2232,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d5", pos = Vector(-3758,1997,-10981), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d6", pos = Vector(-3831,1997,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d7", pos = Vector(-3832,1967,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d8", pos = Vector(-3759,1967,-10981), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d9", pos = Vector(-3545,1660,-10982), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d10", pos = Vector(-3545,1587,-10981), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d11", pos = Vector(-3515,1585,-10981), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-d12", pos = Vector(-3515,1659,-10981), canSee = DefaultTerminalCanSee},
		{name = "ez_office_2-m1_1", pos = Vector(-3731,1543,-10965), canSee = function() return CanSeeFrom(Vector(-3739,1571,-10972)) end},
		{name = "ez_office_2-m1_2", pos = Vector(-3771,1543,-10965), canSee = function() return CanSeeFrom(Vector(-3739,1571,-10972)) end},
		{name = "ez_storage_room_1-m1_1", pos = Vector(2206,-3927,-10966), canSee = function() return CanSeeFrom(Vector(2217,-3952,-10975)) end},
		{name = "ez_storage_room_1-m1_2", pos = Vector(2246,-3927,-10966), canSee = function() return CanSeeFrom(Vector(2217,-3952,-10975)) end},
		{name = "ez_server_room_2-m1_1", pos = Vector(2306,-3556,-11101), canSee = function() return CanSeeFrom(Vector(2299,-3533,-11111)) end},
		{name = "ez_server_room_2-m1_2", pos = Vector(2266,-3556,-11101), canSee = function() return CanSeeFrom(Vector(2299,-3533,-11111)) end},
		{name = "ez_contchamber_scp106-m1_1", pos = Vector(4904,-5942,-10980), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp106-m1_2", pos = Vector(4883,-5942,-10980), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp106-m2_1", pos = Vector(5065,-5959,-10965), canSee = function() return CanSeeFrom(Vector(5045,-5939,-10975)) end},
		{name = "ez_contchamber_scp106-m2_2", pos = Vector(5025,-5959,-10965), canSee = function() return CanSeeFrom(Vector(5045,-5939,-10975)) end},
		{name = "ez_contchamber_scp076-m1_1", pos = Vector(3373,-2671,-10964), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp076-m1_2", pos = Vector(3409,-2671,-10964), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp035-m2_1", pos = Vector(276,3886,-10804), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp035-m2_2", pos = Vector(277,3850,-10804), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp035-m1_1", pos = Vector(781,3184,-10965), canSee = function() return CanSeeFrom(Vector(761,3170,-10970)) end},
		{name = "ez_contchamber_scp035-m1_2", pos = Vector(781,3145,-10965), canSee = function() return CanSeeFrom(Vector(761,3170,-10970)) end},
		{name = "ez_contchamber_scp682-m1_1", pos = Vector(3268,-3784,-9772), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp682-m1_2", pos = Vector(3304,-3784,-9772), canSee = DefaultTerminalCanSee},
		{name = "ez_contchamber_scp079-m1_1", pos = Vector(1924,-1570,-11113), canSee = function() return CanSeeFrom(Vector(1902,-1575,-11122)) end},
		{name = "ez_contchamber_scp079-m1_2", pos = Vector(1924,-1610,-11113), canSee = function() return CanSeeFrom(Vector(1902,-1575,-11122)) end},
		{name = "ez_contchamber_scp966-m1_1", pos = Vector(908,-368,-11114), canSee = function() return CanSeeFrom(Vector(926,-390,-11122)) end},
		{name = "ez_contchamber_scp966-m1_2", pos = Vector(947,-368,-11114), canSee = function() return CanSeeFrom(Vector(926,-390,-11122)) end},
		{name = "ez_office_1-d1", pos = Vector(-2461,-1189,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d2", pos = Vector(-2459,-1156,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d3", pos = Vector(-2384,-1155,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d4", pos = Vector(-2245,-939,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d5", pos = Vector(-2244,-1015,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d6", pos = Vector(-2210,-1017,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d7", pos = Vector(-2133,-1212,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d8", pos = Vector(-2186,-1266,-11046), canSee = DefaultTerminalCanSee},
		{name = "ez_office_1-d9", pos = Vector(-2164,-1293,-11046), canSee = DefaultTerminalCanSee},
		{name = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},
		{name = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},
		{name = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", pos = YYYYYYYYYYYYYYYYYYYYYYYY, canSee = DefaultTerminalCanSee},
	}
}
-- ulx strip ^ ; give breach_tool_terminalplacer
-- lua_run Entity(1):SetPos(xxxxxxxxxxxxxxxxxxxxxx)


MAPCONFIG.BUTTONS_2D.BROKEN_TERMINALS = {
	on_open = function(button)
		BR_Access_BrokenTerminal(button)
	end,
	buttons = {
		{pos = Vector(9181,-2759,-10982), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = Vector(9182,-2759,-10980), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = Vector(9160,-2754,-10981), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = Vector(8941,-2759,-10980), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = Vector(-2113,-1225,-11045), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = Vector(-2376,-1178,-11045), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = Vector(-2220,-933,-11045), spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = YYYYYYYYYYYYYYYYYYYYYYYY, spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = YYYYYYYYYYYYYYYYYYYYYYYY, spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = YYYYYYYYYYYYYYYYYYYYYYYY, spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
		{pos = YYYYYYYYYYYYYYYYYYYYYYYY, spraks = true, sounds = 1, canSee = DefaultTerminalCanSee},
	}
}

MAPCONFIG.ZONES = {}

MAPCONFIG.SPECIAL_MUSIC_ZONES = {
	{pos1 = Vector(6625,1346,-11249), pos2 = Vector(5814,1820,-10931), sound = "map_sounds/914.ogg", length = 29.05, volume = 0.5}, -- 079
	{pos1 = Vector(10347,-3041,-11060), pos2 = Vector(11249,-4064,-10628), sound = "map_sounds/914.ogg", length = 29.05, volume = 0.7}, -- 914
	{pos1 = Vector(1280,-4224,-11206), pos2 = Vector(-86,-5927,-10828), sound = "map_sounds/m_server_room.wav", length = 3.44, volume = 0.5}, -- SERVERS
}


MAPCONFIG.ESCAPE_ZONES = {
	--{pos1 = Vector(-6526,3309,-1615), pos2 = Vector(-7232,1660,-667)},
}

--  name                       	First Position          	Second Position         	Color                music       fog     NVGmul		ambient       use general ambient
MAPCONFIG.ZONES.LCZ = {
	{
		name 						= "Light Containment Zone",
		pos1 						= Vector(13565,-4036,-11158),
		pos2 						= Vector(4890,1025,-10203),
		music 						= nil,
		ambients 					= ambient_lcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,255,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Light Containment Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
}


MAPCONFIG.ZONES.HCZ = {
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(-669,-1240,-11609),
		pos2 						= Vector(4861,4328,-10589),
		--music 						= {sound = "map_sounds/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(5811,-7590,-11545),
		pos2 						= Vector(1534,-3607,-10474),
		--music 						= {sound = "map_sounds/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Heavy Containment Zone",
		pos1 						= Vector(1475,-1246,-11480),
		pos2 						= Vector(4887,-3625,-10373),
		--music 						= {sound = "map_sounds/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "SCP-682's Chamber",
		pos1 						= Vector(3695,-2511,-10087),
		pos2 						= Vector(2614,-4556,-9625),
		--music 						= {sound = "map_sounds/HeavyContainment.ogg", length = 47.2, volume = 0.5},
		music						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= 0,
		examine_info 				= "You are in the Heavy Containment Zone",
		zone_temp 					= ZONE_TEMP_WARM,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Maintenance Tunnels",
		pos1 						= Vector(9467,3364,-12262),
		pos2 						= Vector(11398,5112,-12020),
		music 						= {sound = "map_sounds/Room049.ogg", length = 39.6, volume = 0.5},
		music 						= nil,
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Maintenance Tunnels",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Storage Area 6",
		pos1 						= Vector(13015,2933,-12001),
		pos2 						= Vector(14607,5511,-11730),
		music 						= {sound = "map_sounds/Room3Storage.ogg", length = 16, volume = 0.5},
		ambients 					= ambient_hcz,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(0,0,255,50),
		sanity 						= -1,
		examine_info 				= "You are in the Storage Area 6",
		zone_temp 					= ZONE_TEMP_HOT,
		scp_106_can_tp 				= true,
	}
}

MAPCONFIG.ZONES.ENTRANCEZONE = {
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(-680,5485,-11509),
		pos2 						= Vector(-6297,-3957,-10381),
		--music 						= {sound = "map_sounds/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(1461,-3742,-11387),
		pos2 						= Vector(-698,-1252,-10906),
		--music 						= {sound = "map_sounds/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
	/*
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(-685,1089,-11227),
		pos2 						= Vector(-6277,5464,-10468),
		--music 						= {sound = "map_sounds/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
	{
		name 						= "Entrance Zone",
		pos1 						= Vector(-686,1091,-11250),
		pos2 						= Vector(-6163,-3818,-10621),
		--music 						= {sound = "map_sounds/suspended.ogg", length = 81.60, volume = 1},
		music						= nil,
		ambients 					= ambient_ez,
		fog_enabled 				= true,
		use_general_ambients 		= true,
		color 						= Color(200,200,0,50),
		sanity 						= 1,
		examine_info 				= "You are in the Entrance Zone",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= true,
	},
	*/
}


MAPCONFIG.ZONES.POCKETDIMENSION = {
	{
		name 						= "Pocket Dimension",
		pos1 						= Vector(10309,-8732,-11767),
		pos2 						= Vector(12912,-11674,-10584),
		music 						= {sound = "map_sounds/PD.ogg", length = 27.03, volume = 1},
		ambients 					= {},
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(0,150,0,50),
		sanity 						= -1,
		examine_info 				= "You are in the Pocket Dimension",
		zone_temp 					= ZONE_TEMP_COLD,
		scp_106_can_tp 				= true,
	},
}

MAPCONFIG.ZONES.OUTSIDE = {
	{
		name 						= "Outside",
		pos1 						= Vector(1306,11308,-5934),
		pos2 						= Vector(-10586,691,-4508),
		music 						= {sound = "map_sounds/m_ambience_night_battle.wav", length = 38.32, volume = 0.2},
		music						= nil,
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(255,0,255,50),
		sanity 						= 1,
		examine_info 				= "You are outside of the facility",
		zone_temp 					= ZONE_TEMP_VERYCOLD,
		scp_106_can_tp 				= false,
	},
} 

MAPCONFIG.MINOR_ZONES = {
	{
		name 						= "SCP-008",
		pos1 						= Vector(6118,3935,-11108),
		pos2 						= Vector(5548,3303,-10787),
		music 						= nil,
		ambients 					= nil,
		fog_enabled 				= true,
		use_general_ambients 		= false,
		color 						= Color(220,0,0,50),
		sanity 						= -1,
		examine_info 				= "You are in an unknown world",
		zone_temp 					= ZONE_TEMP_NORMAL,
		scp_106_can_tp 				= false,
	},
}

-- Spawns in Class D's cells
MAPCONFIG.SPAWNS_CLASSD_CELLS = {
	Vector(13216.286132813, -2882.7272949219, -10864.96875),
	Vector(13098.926757813, -2881.1105957031, -10864.96875),
	Vector(12976.107421875, -2878.0297851563, -10864.96875),
	Vector(12865.723632813, -2879.8234863281, -10864.96875),
	Vector(12747.258789063, -2879.5710449219, -10864.96875),
	Vector(12635.126953125, -2882.9025878906, -10864.96875),
	Vector(12520.436523438, -2875.6105957031, -10864.96875),
	Vector(12398.870117188, -2879.5759277344, -10864.96875),
	Vector(12284.581054688, -2879.5668945313, -10864.96875),
	Vector(12167.038085938, -2881.6784667969, -10864.96875),
	Vector(13218.508789063, -2875.6379394531, -11007.96875),
	Vector(13099.616210938, -2880.0463867188, -11007.96875),
	Vector(12981.259765625, -2881.0593261719, -11007.96875),
	Vector(12870.545898438, -2881.0122070313, -11007.96875),
	Vector(12750.88671875, -2881.2421875, -11007.96875),
	Vector(12632.526367188, -2878.4262695313, -11007.96875),
	Vector(12520.916015625, -2883.7780761719, -11007.96875),
	Vector(12403.609375, -2883.7802734375, -11007.96875),
	Vector(12287.163085938, -2883.5974121094, -11007.96875),
	Vector(12172.9453125, -2883.810546875, -11007.96875),		
}

-- Spawns in Light Containment Zone
MAPCONFIG.SPAWNS_LCZ = {
	Vector(10969.458007813, -2618.2993164063, -11007.96875),
	Vector(10066.688476563, -2599.2548828125, -11007.96875),
	Vector(10054.997070313, -3598.9150390625, -11007.96875),
	Vector(9375.666015625, -3702.0124511719, -11007.96875),
	Vector(8779.6181640625, -3576.8959960938, -11007.96875),
	Vector(9213.9833984375, -2666.8479003906, -11007.96875),
	Vector(8530.4599609375, -2722.5703125, -11007.96875),
	Vector(8505.3955078125, -1824.5747070313, -11007.96875),
	Vector(8011.4497070313, -1409.9489746094, -11007.96875),
	Vector(7856.7177734375, -829.31408691406, -11007.96875),
	Vector(7991.2607421875, -2380.78515625, -11007.96875),
	Vector(7752.0869140625, -3031.2104492188, -11007.96875),
	Vector(6810.958984375, -840.69592285156, -11007.96875),
	Vector(6728.802734375, 275.0537109375, -11007.96875),
	Vector(5659.1787109375, 270.60470581055, -11007.96875),
	Vector(5713.4780273438, -1382.1600341797, -11007.96875),
	Vector(6796.4194335938, -1465.0827636719, -11007.96875),
	Vector(10503.696289063, -2672.1862792969, -11007.96875),
	Vector(9994.9248046875, -3126.6027832031, -11007.96875),	
}

-- Spawns in Heavy Containment Zone
MAPCONFIG.SPAWNS_HCZ = {
	Vector(4093.6809082031, -3058.1877441406, -11007.96875),
	Vector(3828.6296386719, -4083.9150390625, -11007.96875),
	Vector(3943.4584960938, -5059.0190429688, -11007.96875),
	Vector(2619.6279296875, -5233.72265625, -11007.96875),
	Vector(2802.6669921875, -4101.056640625, -11007.96875),
	Vector(2527.8718261719, -3166.8103027344, -11007.96875),
	Vector(2626.8662109375, -2434.3811035156, -11007.96875),
	Vector(2560.8854980469, -785.67864990234, -11007.96875),
	Vector(2660.451171875, 315.93859863281, -11007.96875),
	Vector(1802.83203125, 181.89094543457, -11155.96875),
	Vector(618.29425048828, 368.84930419922, -11007.96875),
	Vector(596.25, 1833.5416259766, -11007.96875),
	Vector(1405.4055175781, -530.99792480469, -11155.96875),
	Vector(4121.75390625, -694.64263916016, -11007.96875),
	Vector(4351.4794921875, 318.91464233398, -11007.96875),
	Vector(3835.9873046875, 1363.0443115234, -11007.96875),		
}

-- Spawns in Entrance Zone
MAPCONFIG.SPAWNS_ENTRANCEZONE = {
	Vector(604.849609375, -3430.6850585938, -11007.96875),
	Vector(-410.59155273438, -3057.9809570313, -11007.96875),
	Vector(46.768898010254, -1898.9454345703, -11007.96875),
	Vector(-746.80480957031, -1332.8857421875, -11007.96875),
	Vector(-1275.4210205078, -1847.3405761719, -11007.96875),
	Vector(-1304.208984375, -822.34478759766, -11007.96875),
	Vector(-1944.0776367188, -1090.7785644531, -11071.96875),
	Vector(-2610.3818359375, -466.51013183594, -11007.96875),
	Vector(-3651.0029296875, -1441.7298583984, -11007.96875),
	Vector(-3046.1352539063, -1946.9820556641, -11007.96875),
	Vector(-3796.1806640625, -1951.7912597656, -11007.96875),
	Vector(-2611.0634765625, -2067.2834472656, -11007.96875),

	Vector(-1401.4118652344, 2546.0329589844, -11007.96875),
	Vector(-1784.5322265625, 1795.1351318359, -11007.96875),
	Vector(-2291.3203125, 1171.2570800781, -11007.96875),
	Vector(-2418.6645507813, 1931.8485107422, -11007.96875),
	Vector(-2107.0529785156, 2998.1135253906, -11007.96875),
	Vector(-2407.1291503906, 3842.2856445313, -11007.96875),
	Vector(-3637.8227539063, 3619.3813476563, -11007.96875),
	Vector(-3312.724609375, 2984.9719238281, -11007.96875),
	Vector(-2414.6506347656, 3158.9052734375, -11007.96875),
	Vector(-3626.4067382813, 2147.7026367188, -11007.96875),
	Vector(-2877.8366699219, 1372.2808837891, -11007.96875),
	Vector(-3926.0266113281, 2972.0908203125, -11007.96875),
	Vector(-4628.2587890625, 2817.8217773438, -11007.96875),	
}

-- Where Security spawns
MAPCONFIG.SPAWNS_ENTRANCEZONE_EARLY = {
	Vector(604.849609375, -3430.6850585938, -11007.96875),
	Vector(-410.59155273438, -3057.9809570313, -11007.96875),
	Vector(46.768898010254, -1898.9454345703, -11007.96875),
	Vector(-746.80480957031, -1332.8857421875, -11007.96875),
	Vector(-1275.4210205078, -1847.3405761719, -11007.96875),
	Vector(-1304.208984375, -822.34478759766, -11007.96875),
	Vector(-1944.0776367188, -1090.7785644531, -11071.96875),
	Vector(-2610.3818359375, -466.51013183594, -11007.96875),
	Vector(-3651.0029296875, -1441.7298583984, -11007.96875),
	Vector(-3046.1352539063, -1946.9820556641, -11007.96875),
	Vector(-3796.1806640625, -1951.7912597656, -11007.96875),
	Vector(-2611.0634765625, -2067.2834472656, -11007.96875),	
}

-- Where Chaos Insurgency spawns at the beginning of the round
MAPCONFIG.SPAWNS_ENTRANCEZONE_LATE = {
	Vector(-1401.4118652344, 2546.0329589844, -11007.96875),
	Vector(-1784.5322265625, 1795.1351318359, -11007.96875),
	Vector(-2291.3203125, 1171.2570800781, -11007.96875),
	Vector(-2418.6645507813, 1931.8485107422, -11007.96875),
	Vector(-2107.0529785156, 2998.1135253906, -11007.96875),
	Vector(-2407.1291503906, 3842.2856445313, -11007.96875),
	Vector(-3637.8227539063, 3619.3813476563, -11007.96875),
	Vector(-3312.724609375, 2984.9719238281, -11007.96875),
	Vector(-2414.6506347656, 3158.9052734375, -11007.96875),
	Vector(-3626.4067382813, 2147.7026367188, -11007.96875),
	Vector(-2877.8366699219, 1372.2808837891, -11007.96875),
	Vector(-3926.0266113281, 2972.0908203125, -11007.96875),
	Vector(-4628.2587890625, 2817.8217773438, -11007.96875),		
}

MAPCONFIG.SPAWNS_ENTRANCEZONE_NEAR_GATES = table.Copy(MAPCONFIG.SPAWNS_ENTRANCEZONE_LATE)

MAPCONFIG.SPAWNS_ENTRANCEZONE_GATEB = table.Copy(MAPCONFIG.SPAWNS_ENTRANCEZONE_LATE)

-- Where Chaos Insurgency spawns later
MAPCONFIG.SPAWNS_CHAOSINSURGENCY = {
	{
		name = "Near Gate B",
		spawns = table.Copy(MAPCONFIG.SPAWNS_ENTRANCEZONE_LATE)
	}
}

-- SCP 035's spawns
MAPCONFIG.SPAWNS_SCP_035 = {
	Vector(1382.0225830078, 2316.314453125, -11007.96875),
	Vector(1458.8468017578, 2425.0766601563, -11007.96875),
	Vector(1377.3577880859, 2534.3117675781, -11007.96875),	
}

-- SCP 939's spawns
MAPCONFIG.SPAWNS_SCP_939 = {
	/* TUNNELS
	Vector(10377.458984375, -3034.5812988281, -11926.96875),
	Vector(10177.947265625, -3068.7216796875, -11926.96875),
	Vector(10436.907226563, -2514.0278320313, -11926.96875),
	Vector(9562.6865234375, -3100.2783203125, -11926.96875),
	Vector(10424.693359375, -2212.7465820313, -11926.96875),
	*/
	Vector(2110.0849609375, -7001.09765625, -11177.252929688),
	Vector(2066.5224609375, -6760.5961914063, -11177.954101563),
	Vector(2075.2351074219, -6503.4467773438, -11177.142578125),
	Vector(2135.0642089844, -6201.791015625, -11176.469726563),
	Vector(2168.2055664063, -5907.087890625, -11170.450195313),
	Vector(3105.6281738281, -6029.443359375, -11176.442382813),
	Vector(3195.0280761719, -6414.5893554688, -11172.379882813),
	Vector(3213.6066894531, -6728.0366210938, -11179.385742188),
	Vector(3186.83203125, -6983.7607421875, -11177.963867188),
	Vector(2481.6774902344, -7112.7700195313, -11179.475585938),
	Vector(3037.4125976563, -7129.06640625, -11172.30859375),
	Vector(2891.4426269531, -6010.423828125, -11181.708984375),
}

-- SCP 049's spawns
MAPCONFIG.SPAWNS_SCP_049 = {
	Vector(3464.2023925781, 1413.6104736328, -11007.96875),
	Vector(3326.5207519531, 1422.7512207031, -11007.96875),
	Vector(3216.8940429688, 1422.0228271484, -11007.96875),	
}

-- SCP 106's spawn
MAPCONFIG.SPAWNS_SCP_106 = {
	Vector(5328.8369140625, -5519.0073242188, -11394.96875),
	Vector(5520.34765625, -5442.6923828125, -11394.96875),
	Vector(4966.19140625, -5513.9951171875, -11394.96875),
	Vector(5438.8159179688, -5814.7495117188, -11394.96875),
	Vector(5322.736328125, -5745.3330078125, -11394.96875),
	Vector(5424.5112304688, -5412.7729492188, -11394.96875),
	Vector(5185.9306640625, -5498.9497070313, -11394.96875),
	Vector(5439.2700195313, -5553.1494140625, -11394.96875),
	Vector(5394.94921875, -5277.6596679688, -11394.96875),
	Vector(5588.8442382813, -5551.5512695313, -11394.96875),
	Vector(5337.826171875, -5646.5024414063, -11394.96875),
	Vector(5198.0112304688, -5587.59375, -11394.96875),
	Vector(5330.033203125, -5825.6420898438, -11394.96875),	
}

-- SCP 457's spawn
MAPCONFIG.SPAWNS_SCP_457 = {
	Vector(6232.0166015625, -3645.3176269531, -11007.96875),
	Vector(6113.7055664063, -3652.3842773438, -11007.96875),
	Vector(6006.1752929688, -3639.0158691406, -11007.96875),	
}

-- SCP 966's spawn
MAPCONFIG.SPAWNS_SCP_966 = {
	Vector(5044.267578125, 2458.5949707031, -11155.96875),
	Vector(4900.2397460938, 2452.8295898438, -11155.96875),
	Vector(4903.857421875, 2570.9621582031, -11155.96875),
	Vector(4991.0380859375, 2528.4387207031, -11155.96875),
	Vector(5058.5546875, 2580.4226074219, -11155.96875),		
}


-- Where Mobile Task Force spawns when they arrive in the facility
MAPCONFIG.SPAWNS_MTF = {
	/*
	{
		name = "Gate A Right Elevator",
		spawns = {
			Vector(-5697.4545898438, 2249.0529785156, -10879.96875),
			Vector(-5763.13671875, 2252.7673339844, -10879.96875),
			Vector(-5699.3833007813, 2323.4848632813, -10879.96875),
			Vector(-5760.7915039063, 2327.2204589844, -10879.96875),
		},
		available = function()
			local pos1 = Vector(-5627,2162,-10950)
			local pos2 = Vector(-5838,2363,-10762)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and !v:IsSpectator() and v.br_team != TEAM_MTF and v:GetPos():WithinAABox(pos1, pos2) then
					print("someone is in the right elev")
					return false
				end
			end

			local trace = util.TraceLine({
				start = Vector(-5765,2370,-10789),
				endpos = Vector(-5765,2359,-10789),
				mask = MASK_SOLID,
			})

			local pos3 = Vector(-5003,4127,-11066)
			local pos4 = Vector(-6296,2139,-10608)
			OrderVectors(pos3, pos4)
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and !v:IsSpectator() and v.br_team != TEAM_MTF and v:GetPos():WithinAABox(pos3, pos4) then
					if trace.Hit then
						print("someone is in the room, elev doors are closed so we can spawn")
					else
						print("someone is in the room, elev doors are open so we cant spawn")
					end
					return trace.Hit
				end
			end

			print("noone in room or elev, we can spawn")
			return true
		end,
		func = function()
			for k,v in pairs(ents.GetAll()) do
				if v:GetClass() == "func_button" and v:GetPos():Distance(Vector(-5784.000000, 2371.000000, -10853.000000)) < 10 then
					v:Use(Entity(1), Entity(1), 1, 1)
					return
				end
			end
		end
	},
	{
		name = "Gate A Left Elevator",
		spawns = {
			Vector(-5477.3051757813, 2240.80859375, -10879.96875),
			Vector(-5549.4111328125, 2247.5432128906, -10879.96875),
			Vector(-5481.6025390625, 2315.7724609375, -10879.96875),
			Vector(-5549.4350585938, 2314.2114257813, -10879.96875),			
		},
		available = function()
			local pos1 = Vector(-5416,2363,-10934)
			local pos2 = Vector(-5622,2163,-10754)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and !v:IsSpectator() and v.br_team != TEAM_MTF and v:GetPos():WithinAABox(pos1, pos2) then
					print("someone is in the right elev")
					return false
				end
			end

			local trace = util.TraceLine({
				start = Vector(-5554,2370,-10792),
				endpos = Vector(-5554,2361,-10792),
				mask = MASK_SOLID,
			})

			local pos3 = Vector(-5003,4127,-11066)
			local pos4 = Vector(-6296,2139,-10608)
			OrderVectors(pos3, pos4)
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and !v:IsSpectator() and v.br_team != TEAM_MTF and v:GetPos():WithinAABox(pos3, pos4) then
					if trace.Hit then
						print("someone is in the room, elev doors are closed so we can spawn")
					else
						print("someone is in the room, elev doors are open so we cant spawn")
					end
					return trace.Hit
				end
			end

			print("noone in room or elev, we can spawn")
			return true
		end,
		func = function()
			for k,v in pairs(ents.GetAll()) do
				if v:GetClass() == "func_button" and v:GetPos():Distance(Vector(-5576, 2371, -10853)) < 10 then
					v:Use(Entity(1), Entity(1), 1, 1)
					return
				end
			end
		end
	},
	*/
	{
		name = "Gate B Elevator",
		spawns = {
			Vector(-5762.970703125, -1341.9357910156, -11063.96875),
			Vector(-5688.9516601563, -1356.6821289063, -11063.96875),
			Vector(-5757.1372070313, -1420.1674804688, -11063.96875),
			Vector(-5696.4633789063, -1423.8503417969, -11063.96875),						
		},
		available = function()
			local pos1 = Vector(-5829,-1460,-11115)
			local pos2 = Vector(-5625,-1258,-10936)
			OrderVectors(pos1, pos2)
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and !v:IsSpectator() and v.br_team != TEAM_MTF and v:GetPos():WithinAABox(pos1, pos2) then
					print("someone is in the elev")
					return false
				end
			end


			local trace = util.TraceLine({
				start = Vector(-5762,-1467,-10975),
				endpos = Vector(-5762,-1459,-10975),
				mask = MASK_SOLID,
			})

			local pos3 = Vector(-4844,-2479,-11148)
			local pos4 = Vector(-6093,-1252,-10785)
			OrderVectors(pos3, pos4)
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and !v:IsSpectator() and v.br_team != TEAM_MTF and v:GetPos():WithinAABox(pos3, pos4) then
					if trace.Hit then
						print("someone is in the room, elev doors are closed so we can spawn")
					else
						print("someone is in the room, elev doors are open so we cant spawn")
					end
					return trace.Hit
				end
			end

			print("noone in room or elev, we can spawn")
			return true
		end,
		func = function()
			for k,v in pairs(ents.GetAll()) do
				if v:GetClass() == "func_button" and v:GetPos():Distance(Vector(-5667, -1468, -11037)) < 10 then
					v:Use(Entity(1), Entity(1), 1, 1)
					return
				end
			end
		end
	},
}

function BR2_Get_914_1_Pos()
	return Vector(10979.000000, -3697.000000, -10957.000000)
end

function BR2_Get_914_2_Pos()
	return Vector(10979.000000, -3697.000000, -10976.500000)
end

print("[Breach2] Shared mapconfig loaded!")
