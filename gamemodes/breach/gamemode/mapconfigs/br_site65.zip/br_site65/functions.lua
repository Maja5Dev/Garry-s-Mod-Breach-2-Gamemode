
function MAP_ResetGasZones()
	MAPCONFIG.GAS_ZONES = {
		{pos1 = Vector(28,4964,-7184), pos2 = Vector(-144,4598,-7024)},
		{pos1 = Vector(5653,-247,-11574), pos2 = Vector(5416,-81,-11405)},
		{pos1 = Vector(681,195,-8204), pos2 = Vector(514,384,-8056)},
		{pos1 = Vector(-3165,5083,-7491), pos2 = Vector(-3262,5299,-7325)},
	}
end
MAP_ResetGasZones()

function MAP_EvacShelter1()
	local evac_shelter_1 = {pos1 = Vector(4859,5126,-7190), pos2 = Vector(4687,4947,-7033)}

	local evac_items = nil
	local evac_weapons = nil
	local evac_ammo = nil
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS.buttons) do
		if v.item_gen_group == "EZ_EVAC_SHELTER_ITEMS" then
			evac_items = v
		elseif v.item_gen_group == "EZ_EVAC_SHELTER_WEAPONS" then
			evac_weapons = v
		elseif v.item_gen_group == "EZ_EVAC_SHELTER_AMMO" then
			evac_ammo = v
		end
	end

	for k,v in pairs(player.GetAll()) do
		if v.canEscape == true and v:IsInZone(evac_shelter_1) and v:Alive() and !v:IsSpectator() then
			if evac_weapons then
				for k2,wep in pairs(v:GetWeapons()) do
					if wep.Pickupable == true then
						table.ForceInsert(evac_weapons.items, form_basic_item_info(wep:GetClass(), 0))
					end
				end
			end
			if evac_items then
				for k2,v2 in pairs(v.br_special_items) do
					for k3,v3 in pairs(BR2_SPECIAL_ITEMS) do
						if v3.class == v2.class then
							v2.ammo = 0
							table.ForceInsert(evac_items.items, v2)
						end
					end
				end
			end
			if evac_ammo then
				for k2,v2 in pairs(v:GetAmmoItems()) do
					table.ForceInsert(evac_ammo.items, v2)
				end
			end
			v:SetSpectator()
			print(v:Nick(), "escaped through the evac shelter")
			net.Start("cl_playerescaped")
				net.WriteInt(CurTime() - v.aliveTime, 16)
			net.Send(v)
		end
	end
end

function MAP_GasLeak1()
	table.ForceInsert(MAPCONFIG.GAS_ZONES, {name = "gasleak1", pos1 = Vector(432,-2032,-8199), pos2 = Vector(752,-2192,-8055)})
	timer.Remove("GasLeak1")
	timer.Create("GasLeak1", 5, 1, function()
		for k,v in pairs(MAPCONFIG.GAS_ZONES) do
			if v.name == "gasleak1" then
				table.RemoveByValue(MAPCONFIG.GAS_ZONES, v)
			end
		end
	end)
end

function MAP_GasLeak2()
	table.ForceInsert(MAPCONFIG.GAS_ZONES, {name = "gasleak2", pos1 = Vector(4355,7019,-7189), pos2 = Vector(4680,6935,-7000)})
	timer.Remove("GasLeak2")
	timer.Create("GasLeak2", 5, 1, function()
		for k,v in pairs(MAPCONFIG.GAS_ZONES) do
			if v.name == "gasleak2" then
				table.RemoveByValue(MAPCONFIG.GAS_ZONES, v)
			end
		end
	end)
end

function MAP_GasLeak3()
	table.ForceInsert(MAPCONFIG.GAS_ZONES, {name = "gasleak2", pos1 = Vector(6052,6062,-7181), pos2 = Vector(5963,5732,-7019)})
	timer.Remove("GasLeak3")
	timer.Create("GasLeak3", 5, 1, function()
		for k,v in pairs(MAPCONFIG.GAS_ZONES) do
			if v.name == "gasleak3" then
				table.RemoveByValue(MAPCONFIG.GAS_ZONES, v)
			end
		end
	end)
end

function MAP_ResetGenerators()
	MAP_GENERATOR_1_ON = false
	MAP_GENERATOR_2_ON = false
	MAP_GENERATOR_3_ON = false
	MAP_GENERATOR_4_ON = false
end

MAP_ResetGenerators()

function Map_GeneratorOn()
	if MAP_GENERATOR_1_ON and MAP_GENERATOR_2_ON and MAP_GENERATOR_3_ON and MAP_GENERATOR_4_ON then
		print("ALL GENERATORS ON")
		net.Start("br_all_generators_on")
		net.Broadcast()
	end
end

function MAP_Generator_1()
	MAP_GENERATOR_1_ON = true
	print("Generator 1 started")
end

function MAP_Generator_2()
	MAP_GENERATOR_2_ON = true
	print("Generator 2 started")
end

function MAP_Generator_3()
	MAP_GENERATOR_3_ON = true
	print("Generator 3 started")
end

function MAP_Generator_4()
	MAP_GENERATOR_4_ON = true
	print("Generator 4 started")
end

function MAP_PrimaryLights_Enable()
	if MAP_GENERATOR_1_ON and MAP_GENERATOR_2_ON and MAP_GENERATOR_3_ON and MAP_GENERATOR_4_ON then
		print("ALL GENERATORS ON")
		net.Start("br_all_generators_on")
		net.Broadcast()
	end
end

function MAP_PrimaryLights_Disable()
end

function BR2_Get914Status()
	local skip_ents = {}
	
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "func_button" and v:GetPos():Distance(Vector(10979, -3697, -10957)) < 5 then
			print(v)
			table.ForceInsert(skip_ents, v)
		end
	end
	
	local pos_tab = {
		{
			st = Vector(10980.968750, -3688.924072, -10957.142578),
			en = Vector(10980.968750, -3691.739502, -10957.219727)
		},
		{
			st = Vector(10980.968750, -3690.754395, -10951.054688),
			en = Vector(10980.968750, -3693.096924, -10953.384766)
		},
		{
			st = Vector(10980.968750, -3697.023926, -10948.039063),
			en = Vector(10980.968750, -3696.967285, -10951.536133)
		},
		{
			st = Vector(10980.968750, -3703.054688, -10951.053711),
			en = Vector(10980.968750, -3701.015625, -10953.105469)
		},
		{
			st = Vector(10980.968750, -3706.023682, -10956.677734),
			en = Vector(10980.968750, -3702.247559, -10956.570313)
		},
	}
	
	for i,v in ipairs(pos_tab) do
		local tr = util.TraceLine({
			start = v.st,
			endpos = v.en,
			mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE,
			filter = skip_ents
		})
		if tr.Hit == true then
			return i
		end
	end
	return 0
end


function BR2_Get_914_Enter_Entities()
	local pos1 = Vector(11027,-3399,-11036)
	local pos2 = Vector(11101,-3546,-10878)
	OrderVectors(pos1, pos2)
	local ents_found = {}
	for k,v in pairs(ents.FindInBox(pos1, pos2)) do
		if v.GetBetterOne or v:IsPlayer() then
			table.ForceInsert(ents_found, v)
		end
	end
	return ents_found
end

function BR2_914_End_Stage()
	timer.Create("BR2_914_NextStage", 11, 1, function()
		br2_914_disabled = false
	end)
end

br2_914_disabled = false
function BR2_Handle914_Start()
	if br2_914_disabled == true then
		return false
	else
		br2_914_disabled = true
		timer.Create("BR2_914_NextStage", 4, 1, function()
			br_914status = BR2_Get914Status()
			for k,v in pairs(BR2_Get_914_Enter_Entities()) do
				v:SetPos(Vector(11062,-3921,-10993))
				if v:IsPlayer() then
					v:Kill()
				elseif isfunction(v.GetBetterOne) then
					local better_one = v:GetBetterOne()
					if isstring(better_one) then
						local ent = ents.Create(better_one)
						if IsValid(ent) then
							ent:SetPos(v:GetPos() + Vector(0,0,10))

							ent:SetVelocity(Vector(0,0,0))
							ent:Spawn()
							ent:SetNWBool("isDropped", true)
						end
						if isnumber(ent.BatteryLevel) then
							ent.BatteryLevel = 100
						end
						if ent:GetClass() == "item_radio2" then
							for _,bt in pairs(MAPCONFIG.BUTTONS) do
								if ent.Code == nil and isnumber(bt.code) and bt.code_type == "radio" then
									ent.Code = bt.code
								end
							end
						end
					end
					v:Remove()
				end
			end
			BR2_914_End_Stage()
		end)
		return true
	end
end

function BR_SpawnMapNPC(npc, zone)
	local all_players = {}
	for k,v in pairs(player.GetAll()) do
		if v:Alive() == true and v:IsSpectator() == false then
			table.ForceInsert(all_players, v)
		end
	end

	for k,v in pairs(ents.GetAll()) do
		if string.find(v:GetClass(), "npc_cpt_scp") then
			table.ForceInsert(all_players, v)
		end
	end

	local all_suitable_spawns = {}
	for pos_num,pos in ipairs(zone) do
		local pos_available = true
		local pos_points = 0
		for pl_num,pl in pairs(all_players) do
			local dist = pl:GetPos():Distance(pos)
			local trace = util.TraceLine({
				start = pl:GetPos(),
				endpos = pos,
				mask = MASK_SOLID,
				filter = pl
			})
			if dist < 700 and trace.Hit == false then
				pos_available = false
				break
			else
				pos_points = pos_points + dist
			end
		end
		if pos_available == true then
			table.ForceInsert(all_suitable_spawns, {pos, pos_points})
		end
	end
	/*
	local best_spawn = nil
	for k,v in pairs(all_suitable_spawns) do
		if best_spawn == nil or best_spawn[2] > v[2] then
			best_spawn = v
		end
	end
	*/
	local best_spawn = table.Random(all_suitable_spawns)

	if best_spawn != nil then
		local npc = ents.Create(npc)
		if IsValid(npc) then
			npc:SetPos(best_spawn[1])
			npc:Spawn()
			npc:Activate()
			return true
		end
	end
	return false
end

function SpawnMapNPCs()
	if GetConVar("br2_enable_npcs"):GetBool() == false then return end
	if round_system.current_scenario.disable_npc_spawning == true then return end

	local npc_tab = {
		--{"npc_cpt_scp_173", Vector(-183.948669, 1345.252441, -8063.968750)},
		--{"npc_cpt_scp_966", Vector(-650.879883, 4119.376953, -7167.968750)},
		--{"npc_cpt_scp_966", Vector(-474.215820, 4124.738281, -7167.968750)},
		--{"npc_cpt_scp_966", Vector(-752.841125, 4201.270020, -7167.968750)},
		--{"npc_cpt_scp_939_b", Vector(6699.372070, -1848.375977, -11551.968750)},
		--{"npc_cpt_scp_939_c", Vector(6929.901367, -885.706116, -11551.968750)},
		--{"npc_cpt_scp_178specs", Vector(658.442383, 1594.945190, -8145.907227)},

		/*
		{"npc_cpt_scp_106", Vector(-2730.027832, 5804.986328, -7166.968750)},
		{"npc_cpt_scp_457", Vector(-2567.378174, 2985.477783, -7167.968750)},
		{"npc_cpt_scp_575", Vector(1232.431885, 1351.772705, -8191.968750)},
		{"npc_cpt_scp_650", Vector(-952.335449, 2317.005615, -6143.968750)},
		*/
		{"npc_cpt_scp_939_a", Vector(10382.291992188, -3043.9111328125, -11916.96875)},
		{"npc_cpt_scp_012", Vector(-1122.385742, -195.140732, -8447.968750)},
		--{"npc_cpt_scp_1025", Vector(969.080566, 1265.391113, -8191.968750)},
		{"npc_cpt_scp_513", Vector(-812.415161, 5603.627441, -7167.968750)},
		--{"npc_cpt_scp_714", Vector(1518.547607, 1512.050903, -8156.471680)},
	}

	for k,v in pairs(npc_tab) do
		local npc = ents.Create(v[1])
		if IsValid(npc) then
			npc:SetPos(v[2])
			npc:Spawn()
			npc:Activate()
		end
	end
	
	local prep_time = math.Clamp(GetConVar("br2_time_preparing"):GetInt(), 45, 200) * 1.75
	print("prep_time_round", prep_time)

	timer.Remove("NPC_SPAWN_049_TIMER")
	timer.Create("NPC_SPAWN_049_TIMER", math.random(prep_time + 30, prep_time + 60), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_049", MAPCONFIG.SPAWNS_LCZ)
	end)

	timer.Remove("NPC_SPAWN_096_TIMER")
	timer.Create("NPC_SPAWN_096_TIMER", math.random(prep_time + 120, prep_time + 200), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_096", MAPCONFIG.SPAWNS_HCZ)
	end)

	timer.Remove("NPC_SPAWN_106_TIMER")
	timer.Create("NPC_SPAWN_106_TIMER", math.random(prep_time + 45, prep_time + 60), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_106", MAPCONFIG.SPAWNS_HCZ)
	end)

	timer.Remove("NPC_SPAWN_173_TIMER")
	timer.Create("NPC_SPAWN_173_TIMER", math.random(prep_time + 140, prep_time + 200), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_173", MAPCONFIG.SPAWNS_LCZ)
	end)

	timer.Remove("NPC_SPAWN_1048_TIMER")
	timer.Create("NPC_SPAWN_1048_TIMER", math.random(prep_time + 60, prep_time + 90), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_1048", MAPCONFIG.SPAWNS_LCZ)
	end)

	timer.Remove("NPC_SPAWN_457_TIMER")
	timer.Create("NPC_SPAWN_457_TIMER", math.random(prep_time + 45, prep_time + 90), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_457", MAPCONFIG.SPAWNS_HCZ)
	end)

	timer.Remove("NPC_SPAWN_575_TIMER")
	timer.Create("NPC_SPAWN_575_TIMER", math.random(prep_time + 60, prep_time + 90), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_575", MAPCONFIG.SPAWNS_ENTRANCEZONE)
	end)

	timer.Remove("NPC_SPAWN_066_TIMER")
	timer.Create("NPC_SPAWN_066_TIMER", math.random(prep_time + 90, prep_time + 140), 1, function()
		BR_SpawnMapNPC("npc_cpt_scp_066", MAPCONFIG.SPAWNS_ENTRANCEZONE)
	end)
end

function MAP_FemurBreaker()
	print("FEMUR BREAKER")

	timer.Remove("NPC_SPAWN_106_TIMER")
	local scp_106 = ents.FindByClass("npc_cpt_scp_106")
	if table.Count(scp_106) > 0 then
		scp_106 = scp_106[1]
		if IsValid(scp_106) then
			scp_106:Remove()
		end
	end
	BroadcastLua("surface.PlaySound('cpthazama/scp/106Contain.mp3')")

	/*
	local tr = util.TraceLine({
		start = Vector(-2522,6345,-7616),
		endpos = Vector(-2510,6369,-7499),
	})
	if tr.Hit and br2_round_state_end - CurTime() then
		timer.Remove("NPC_SPAWN_106_TIMER")
		local scp_106 = ents.FindByClass("npc_cpt_scp_106")
		if table.Count(scp_106) > 0 then
			scp_106 = scp_106[1]
			if IsValid(scp_106) then
				scp_106:Remove()
				BroadcastLua("surface.PlaySound('cpthazama/scp/106Contain.mp3')")
			end
		end
	end
	*/
	return false
end

BR2_SPECIAL_BUTTONS = {}

function Breach_Map_Organise()
	print("organising the map...")

	MAP_SCP_294_Coins = 0

	BR2_SPECIAL_BUTTONS = {}
	for k,v in pairs(ents.GetAll()) do
		local name = v:GetName():lower()
		if string.find(name, "spec_button") then
			BR2_SPECIAL_BUTTONS[name] = v
		end
	end

	timer.Remove("BR_SCP008")
	timer.Remove("BR_SCP008_2")
	timer.Create("BR_SCP008", 5, 1, function()
		for k,v in pairs(ents.GetAll()) do
			local name = v:GetName():lower()
			if name == "008_containment_door" then
				local rnd_pl = table.Random(player.GetAll())
				v:Use(rnd_pl, rnd_pl, 1, 1)
			end
		end
	end)

	if round_system.current_scenario.scp_008_no_auto_closing == false then
		local scp_008_time = GetConVar("br2_time_008_open"):GetInt()
		timer.Create("BR_SCP008_2", scp_008_time, 1, function()
			for k,v in pairs(ents.GetAll()) do
				local name = v:GetName():lower()
				if name == "008_containment_door" then
					local tr = util.TraceLine({
						start = Vector(-1586,4896,-7088),
						endpos = Vector(-1579,4896,-7088),
					})
					if tr.Hit then
						local rnd_pl = table.Random(player.GetAll())
						v:Use(rnd_pl, rnd_pl, 1, 1)
					end
				end
			end
		end)
	end


	for k,v in pairs(MAPCONFIG.RANDOM_ITEM_SPAWNS) do
		local all_spawns = table.Copy(v.spawns)
		for i=1, #all_spawns - v.num do
			table.RemoveByValue(all_spawns, table.Random(all_spawns))
		end
		local all_ents = {}
		for i,spawn in ipairs(all_spawns) do
			local ent = ents.Create(v.class)
			if IsValid(ent) then
				if v.model then
					ent:SetModel(v.model)
				end
				ent:SetPos(spawn[1])
				ent:SetAngles(spawn[2])
				ent:Spawn()
				if isfunction(v.func) then
					v.func(ent)
				end
				table.ForceInsert(all_ents, ent)
			end
		end
		if isfunction(v.func_all) then
			v.func_all(all_ents)
		end
	end

	br2_914_disabled = false
	br_914status = 1
	
	/*
	br2_914_fix_ent_1 = ents.Create("prop_physics")
	if IsValid(br2_914_fix_ent_1) then
		br2_914_fix_ent_1:SetPos(Vector(783.786865, -610.382507, -8192.000000))
		br2_914_fix_ent_1:SetModel("models/hunter/plates/plate2x3.mdl")
		br2_914_fix_ent_1:SetMaterial("phoenix_storms/metalset_1-2")
		br2_914_fix_ent_1:Spawn()
		local phys = br2_914_fix_ent_1:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
	end
	
	br2_914_fix_ent_2 = ents.Create("prop_physics")
	if IsValid(br2_914_fix_ent_2) then
		br2_914_fix_ent_2:SetPos(Vector(783.786865, -1060.382568, -8192))
		br2_914_fix_ent_2:SetModel("models/hunter/plates/plate2x3.mdl")
		br2_914_fix_ent_2:SetMaterial("phoenix_storms/metalset_1-2")
		br2_914_fix_ent_2:Spawn()
		local phys = br2_914_fix_ent_2:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
	end
	*/
	
	if SafeBoolConVar("br2_testing_mode") == false then
		SpawnMapNPCs()
	end
	
	local button_ents = {}

	--CORPSES
	if istable(MAPCONFIG.STARTING_CORPSES) and round_system.current_scenario.fake_corpses == true then
		local all_corpses = table.Copy(MAPCONFIG.STARTING_CORPSES)
		local corpse_infos = {}

		for i=1, MAPCONFIG.Starting_Corpses_Number() do
			local random_corpse = table.Random(all_corpses)
			table.ForceInsert(corpse_infos, random_corpse)
			table.RemoveByValue(all_corpses, random_corpse)
		end
		
		for k,v in pairs(corpse_infos) do
			local corpse = table.Random(v)
			local rag = ents.Create("prop_ragdoll")
			if IsValid(rag) then
				rag:SetModel(corpse.model)
				rag:SetPos(corpse.ragdoll_pos)
				rag.IsStartingCorpse = true
				rag:Spawn()
				ApplyCorpseInfo(rag, corpse, true)
				rag.CInfo = corpse
				rag.Info = {}
				rag.Info.CorpseID = rag:GetCreationID()
				rag.Info.Victim = NULL
				rag.Info.VictimNick = "Unknown"
				rag.Info.DamageType = DMG_GENERIC
				rag.Info.Time = CurTime() - math.random(20,1400)
				rag:SetNWInt("DeathTime", rag.Info.Time)
				rag:SetNWString("ExamineDmgInfo", " - Cause of death is unknown")
				rag.Info.Loot = {}
				--local random_item = table.Random({"item_radio", "item_medkit", "item_pills", "item_gasmask", "item_nvg", "keycard_level1", "keycard_level2", "kanade_tfa_crowbar"})
				--table.ForceInsert(rag.Info.Loot, form_basic_item_info(random_item))
				rag.RagdollHealth = 0
				rag.nextReviveMove = 0
				
				if isfunction(corpse.setup) then
					corpse.setup(rag)
					if istable(all_fake_corpses) then
						table.ForceInsert(all_fake_corpses, rag)
						rag.Info.notepad = {}
						rag.Info.notepad.people = {
							{
								br_ci_agent = rag.br_ci_agent,
								br_role = rag.br_role,
								br_showname = rag.br_showname,
								health = HEALTH_ALIVE,
								scp = false
							}
						}
					end
				end
			end
		end
	end
	
	timer.Create("BR2_MAPCONFIG_CORPSEINFO", 4, 1, function()
		for k,v in pairs(ents.FindByClass("prop_ragdoll")) do
			if v.CInfo then
				--ApplyCorpseInfo(v, v.CInfo, true)
				for i=0, (v:GetPhysicsObjectCount() - 1) do
					local bone = v:GetPhysicsObjectNum(i)
					if IsValid(bone) then
						bone:EnableMotion(true)
					end
				end
			end
		end
 	end)

	 -- lua_run for k,v in pairs(ents.GetAll()) do if string.find(v:GetName(), "mbutton_") then print(v:GetName()) end end

	-- BUTTONS
	if istable(MAPCONFIG.BUTTONS) then
		for i,butt in ipairs(MAPCONFIG.BUTTONS) do
			local button_found = false
			for k,v in pairs(ents.GetAll()) do
				if (isstring(butt.ent_name) and butt.ent_name == v:GetName()) or (v:GetPos() == butt.pos) or (v:GetPos():Distance(butt.pos) < 3) then
					if butt.ent_name then
						print("Found a button with name (" .. butt.ent_name .. ")")
					end
					--print("Found a button with pos (" .. tostring(butt.pos) .. ")  and level " .. butt.level)
					v.br_info = butt
					table.ForceInsert(button_ents, v)
					butt.ent = v
					button_found = true
					continue
				end
			end
			if button_found == false then
				print("Button not found", i, butt.pos)
			end
		end
	else
		print("[Breach2] No buttons found...")
		return
	end
	
	local function GenerateRandomPassword()
		local str = "1234567890qwertyuiopasdfghjklzxcvbnm"
		local ret = ""
		for i=1, 4 do
			ret = ret .. str[math.random(1,36)]
		end
		print("random pass: " .. ret)
		return ret
	end

	-- TERMINALS
	BR2_TERMINALS = table.Copy(MAPCONFIG.BUTTONS_2D.TERMINALS.buttons)
	for k,v in pairs(BR2_TERMINALS) do
		v.Info = {
			tab_set = "TERMINAL_INFO_GENERIC",
			devices = {
				device_cameras = false
			}
		}
		v.Info.SettingsFunctions = v.special_functions
		if istable(v.auth) then
			v.Authorization = {
				login = "admin",
				password = "admin",
				currentlyLogged = false,
			}
			if v.auth[2] == true then
				v.Authorization.password = GenerateRandomPassword()
			end
			if isstring(v.auth[1]) then
				v.Authorization.login = v.auth[1]
			end
		end
		if math.random(1,7) == 4 then
			v.Info.devices.device_cameras = true
		end

																												v.Info.devices.device_cameras = true

		/*
		v.Authorization = {
			login = "admin",
			password = "admin",
			currentlyLogged = false,
		}
		*/
	end


	-- OUTFITS
	local outfit_groups = {}
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.OUTFITTERS.buttons) do
		outfit_groups[v.item_gen_group] = outfit_groups[v.item_gen_group] or {}
		table.ForceInsert(outfit_groups[v.item_gen_group], v)
		v.items = {}
	end
	
	for k_outfit_group,outfit_group in pairs(outfit_groups) do
		if istable(MAPCONFIG.OUTFIT_GENERATION_GROUPS[k_outfit_group]) then
			local gen_groups = table.Copy(MAPCONFIG.OUTFIT_GENERATION_GROUPS[k_outfit_group])
			local all_outfitters = {}
			for i = 1, table.Count(gen_groups) do
				local rnd_outfitter = table.Random(gen_groups)
				table.ForceInsert(all_outfitters, rnd_outfitter)
				table.RemoveByValue(gen_groups, rnd_outfitter)
			end
			for k_item, item in pairs(all_outfitters) do
				local rnd_outfitter = table.Random(outfit_group)
				if istable(rnd_outfitter) then
					for i = 1, item[2] do
						table.ForceInsert(rnd_outfitter.items, item[1])
					end
					table.RemoveByValue(outfit_group, rnd_outfitter)
				end
			end
		end
	end

	-- ITEMS
	local container_groups = {}
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS.buttons) do
		container_groups[v.item_gen_group] = container_groups[v.item_gen_group] or {}
		table.ForceInsert(container_groups[v.item_gen_group], v)
		v.items = {}
	end
	for k,v in pairs(MAPCONFIG.BUTTONS_2D.ITEM_CONTAINERS_CRATES.buttons) do
		container_groups[v.item_gen_group] = container_groups[v.item_gen_group] or {}
		table.ForceInsert(container_groups[v.item_gen_group], v)
		v.items = {}
		v.locked = true
	end

	for k_cont_group,cont_group in pairs(container_groups) do
		if istable(MAPCONFIG.ITEM_GENERATION_GROUPS[k_cont_group]) then
			local all_items = {}
			for k_item, item in pairs(MAPCONFIG.ITEM_GENERATION_GROUPS[k_cont_group]) do
				for i = 1, item[2] do
					table.ForceInsert(all_items, item[1])
				end
			end
			for k_button,button in pairs(cont_group) do
				if table.Count(button.items) == 0 and table.Count(all_items) > 0 then
					local rnd_item = table.Random(all_items)
					if rnd_item != nil then
						table.ForceInsert(button.items, form_basic_item_info(rnd_item))
						table.RemoveByValue(all_items, rnd_item)
					end
				end
			end
			for k_item,item in pairs(all_items) do
				local rnd_cont = table.Random(cont_group)
				if item != nil then
					table.ForceInsert(rnd_cont.items, form_basic_item_info(item))
				end
			end
		end
	end
	
	-- CAMERAS
	if istable(MAPCONFIG.CAMERAS) then
		for k,v in pairs(MAPCONFIG.CAMERAS) do
			for k2,v2 in pairs(v.cameras) do
				local camera = ents.Create("br2_camera")
				if IsValid(camera) then
					camera:SetModel("models/props/cs_assault/camera.mdl")
					camera:SetPos(v2.pos)
					camera:SetAngles(v2.ang)
					camera:Spawn()
					camera.CameraInfo = table.Copy(v2)
					camera.CameraName = v2.name
					camera:SetNWString("CameraName", v2.name)
				end
			end
			print("Cameras for " .. v.name .. " setup")
		end
	else
		print("[Breach2] No cameras found...")
		return
	end
	
	-- BUTTON CODES
	local numww = 0
	for k,v in pairs(button_ents) do
		if v.br_info.code != nil then
			local oldcode = v.br_info.code
			v.br_info.code = (math.random(1,9) * 1000) + (math.random(1,9) * 100) + (math.random(1,9) * 10) + math.random(1,9)
			print("Found a code button ("..oldcode..") changing to a random one ("..v.br_info.code..")", v.br_info.name)
			v.br_info.code_type = "radio"
			numww = numww + 1
		end
	end
	print("ALL CODE BUTTONS: " .. numww)
end
