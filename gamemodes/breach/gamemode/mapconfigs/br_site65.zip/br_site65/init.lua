
MAPCONFIG = {}

function form_basic_item_info(class, amount)
	for k,v in pairs(BR2_DOCUMENTS) do
		if v.class == class then
			return {class = class, ammo = 0, name = v.name}
		end
	end
	for k,v in pairs(BR2_SPECIAL_ITEMS) do
		if v.class == class then
			return {class = class, ammo = 0, v.name}
		end
	end
	--print("TEST ITEM", class, weapons.Get(class), weapons.Get(class).PrintName)
	return {class = class, ammo = amount or 0, name = weapons.Get(class).PrintName}
end

function Kanade_DebugPrint1()
	local ent = Entity(1):GetEyeTrace().Entity
	local ent_pos = ent:GetPos()
	local ent_ang = ent:GetAngles()
	print("{Vector("..ent_pos.x..", "..ent_pos.y..", "..ent_pos.z..")" .. ", " .. "Angle("..ent_ang.pitch..", "..ent_ang.yaw..", "..ent_ang.roll..")},")
end

MAPCONFIG.RANDOM_ITEM_SPAWNS = {
}



MAPCONFIG.ITEM_GENERATION_GROUPS = {
	["LCZ_FIRST_LOOT"] = {
		{"keycard_level1", 4},
		{"keycard_playing", 1},
		{"keycard_master", 1},
		{"item_battery_9v", 3},
		{"item_radio", 1},

		{"ammo_pistol16", 1},
		{"flashlight", 3},
		{"coin", 4},
		{"doc_scp1048", 1},
	},
}

MAPCONFIG.OUTFIT_GENERATION_GROUPS = {
	["LCZ"] = {
		{"class_d", 4},
		{"scientist", 3},
		{"janitor", 2},
		{"medic", 1},
	},
}

MAPCONFIG.BUTTONS = {
	{
		name = "lcz_yellow_room_small",
		pos = Vector(1336.000000, 1931.000000, -8126.200195),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_contchamber_scp914",
		pos = Vector(10313, -3645, -10981),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_contchamber_scp457",
		pos = Vector(6110, -3347, -10981),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_contchamber_scp173",
		pos = Vector(9995, -2224, -10981),
		level = 2,
		sounds = true
	},
	{
		name = "lcz_contchamber_scps",
		pos = Vector(7836, -1589, -10857),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_office_1",
		pos = Vector(8723, -3326, -10981),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_office_2",
		pos = Vector(8723, -1906, -10981),
		level = 1,
		sounds = true
	},
	{
		name = "lcz_securityzone_armory_1",
		pos = Vector(8042, -2711, -10492.200195313),
		level = 4,
		sounds = true
	},
	{
		name = "lcz_securityzone_barracks_1",
		pos = Vector(7593, -2197, -10492.200195313),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_to_ez_checkpoint_1_1",
		pos = Vector(5144.2001953125, 265, -10981.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_to_ez_checkpoint_1_2",
		pos = Vector(4912.2001953125, 266, -10981.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_to_ez_checkpoint_2_1",
		pos = Vector(5588.2001953125, -3081, -10981.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_to_ez_checkpoint_2_2",
		pos = Vector(5356.2001953125, -3080, -10981.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "lcz_electrical_center",
		pos = Vector(6600, -785, -10981),
		level = 3,
		sounds = true
	},



	--HCZ
	{
		name = "hcz_electrical_center",
		pos = Vector(250, 317, -10980),
		level = 4,
		sounds = true
	},
	{
		name = "hcz_to_ez_checkpoint_1_1",
		pos = Vector(-116.80000305176, 2371, -10981.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_to_ez_checkpoint_1_2",
		pos = Vector(-407, 2372, -10981.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_to_ez_checkpoint_2_1",
		pos = Vector(1998.1999511719, -3485, -11117.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_to_ez_checkpoint_2_2",
		pos = Vector(1708, -3484, -11117.799804688),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_contchamber_scp939",
		pos = Vector(2530, -5666, -10980),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_contchamber_scp106",
		pos = Vector(4558, -5145, -10980),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_contchamber_scp079",
		pos = Vector(1667, -1051, -11128),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_contchamber_scp966",
		pos = Vector(1146, -530, -11128),
		level = 3,
		sounds = true
	},
	{
		name = "hcz_contchamber_scp682",
		pos = Vector(3267, -3973, -9786.75),
		level = 4,
		sounds = true
	},
	{
		name = "hcz_storageroom_1",
		pos = Vector(4574, -4087, -10980),
		level = 0,
		code = 1234,
		code_available_on_start = true,
		code_personal_office = false,
		sounds = true
	},
	{
		name = "hcz_connector_1",
		pos = Vector(4110, -1937.1999511719, -10981.299804688),
		level = 0,
		code = 1234,
		code_available_on_start = true,
		code_personal_office = false,
		sounds = true
	},




	--EZ
	{
		name = "ez_headoffice",
		pos = Vector(-3125, -1527, -10941.299804688),
		level = 5,
		sounds = true
	},
	{
		name = "ez_barracks",
		pos = Vector(-2604, -2204, -10981),
		level = 3,
		sounds = true
	},
	{
		name = "ez_conf_room",
		pos = Vector(-3646, -2204, -10981),
		level = 4,
		sounds = true
	},
	{
		name = "ez_server_room",
		pos = Vector(-1278, -2106, -10981),
		level = 3,
		sounds = true
	},
	{
		name = "ez_electrical_center",
		pos = Vector(-3646, -528, -10981),
		level = 4,
		sounds = true
	},
	{
		name = "ez_connector",
		pos = Vector(-2442, 587.14001464844, -10981),
		level = 3,
		sounds = true
	},




	-- SPECIAL
	{
		name = "914_1",
		pos = Vector(10979.000000, -3697.000000, -10957.000000),
		level = 7,
		sounds = false
	},
	{
		name = "914_2",
		pos = Vector(10979.000000, -3697.000000, -10976.500000),
		level = 7,
		sounds = false
	},
}

MAPCONFIG.POCKETDIMENSION_SPAWNS = {
	Vector(6417.7026367188, -8935.0888671875, -11009.96875),
	Vector(6422.3505859375, -9032.44921875, -11009.96875),
	Vector(6358.8291015625, -9096.5390625, -11009.96875),
	Vector(6269.1713867188, -9086.88671875, -11009.96875),
	Vector(6235.3081054688, -9006.2451171875, -11009.96875),
	Vector(6306.0776367188, -8939.521484375, -11009.96875),
	Vector(6335.7807617188, -9004.6904296875, -11009.96875),	
}

MAPCONFIG.SCP_294_CUP = {pos = Vector(3421.650635, 4728.646484, -7266.223633), ang = Angle(0, 0, 0)}

br2_914_on_map = true

include("corpses.lua")
include("functions.lua")
--include("mapconfigs/br2_testing_3/init.lua")

print("[Breach2] Serverside mapconfig loaded!")
